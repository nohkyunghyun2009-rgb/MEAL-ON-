import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models/body_profile.dart';
import '../models/nutrition.dart';
import '../services/claude_service.dart';
import '../services/kakao_local_service.dart';

/// 앱의 "기억 상자".
/// 여러 화면이 같은 데이터를 보고, 바뀌면 자동으로 화면이 새로 그려져요.
class AppState extends ChangeNotifier {
  static const _kProfile = 'profile';
  static const _kEntries = 'entries';

  BodyProfile? _profile;
  List<MealEntry> _entries = [];
  final List<ChatMessage> chat = []; // AI 대화 (앱을 끄면 사라져요)

  // 식당 찾기 탭이 받아온 "내 주변 1km 식당" (추천할 때 가게 이름을 붙이려고 기억해둬요)
  List<Place> nearbyPlaces = [];
  double? lastLat;
  double? lastLng;

  void setNearbyPlaces(List<Place> places, double lat, double lng) {
    nearbyPlaces = places;
    lastLat = lat;
    lastLng = lng;
    notifyListeners();
  }

  BodyProfile? get profile => _profile;
  bool get hasProfile => _profile != null;

  NutritionTargets? get targets =>
      _profile == null ? null : NutritionTargets.forProfile(_profile!);

  BodyInsight? get insight => _profile == null ? null : BodyInsight.from(_profile!);

  // ───── 폰에서 불러오기 (앱 켤 때 한 번) ─────
  Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();

    final p = prefs.getString(_kProfile);
    if (p != null) {
      _profile = BodyProfile.fromJson(jsonDecode(p) as Map<String, dynamic>);
    }

    final e = prefs.getString(_kEntries);
    if (e != null) {
      final list = jsonDecode(e) as List<dynamic>;
      _entries = list
          .map((x) => MealEntry.fromJson(x as Map<String, dynamic>))
          .toList();
    }
    notifyListeners();
  }

  Future<void> _saveEntries() async {
    final prefs = await SharedPreferences.getInstance();
    // 최근 7일치만 남겨서 저장 공간 아끼기
    final cutoff = DateTime.now().subtract(const Duration(days: 7));
    _entries = _entries.where((e) => e.date.isAfter(cutoff)).toList();
    await prefs.setString(_kEntries, jsonEncode(_entries.map((e) => e.toJson()).toList()));
  }

  // ───── 인바디 정보 ─────
  Future<void> setProfile(BodyProfile p) async {
    _profile = p;
    chat.clear(); // 몸 정보가 바뀌면 AI 대화도 새로 시작
    notifyListeners();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_kProfile, jsonEncode(p.toJson()));
  }

  // ───── 식사 기록 ─────
  List<MealEntry> get todayEntries {
    final now = DateTime.now();
    return _entries.where((e) => e.isSameDay(now)).toList();
  }

  List<MealEntry> entriesFor(MealType meal) =>
      todayEntries.where((e) => e.meal == meal).toList();

  NutritionTotals get todayTotals => NutritionTotals.sum(todayEntries);

  Future<void> addEntry(MealType meal, FoodItem food, double servings) async {
    _entries.add(MealEntry(
      id: DateTime.now().microsecondsSinceEpoch.toString(),
      meal: meal,
      food: food,
      servings: servings,
      date: DateTime.now(),
    ));
    notifyListeners();
    await _saveEntries();
  }

  Future<void> removeEntry(String id) async {
    _entries.removeWhere((e) => e.id == id);
    notifyListeners();
    await _saveEntries();
  }

  // ───── AI 대화 ─────
  void addChat(ChatMessage m) {
    chat.add(m);
    notifyListeners();
  }

  /// Claude에게 보낼 "오늘의 상황 설명서"
  /// 몸 정보 + 오늘 먹은 것 + 남은 양을 글로 정리해요.
  String buildSystemPrompt() {
    final p = _profile;
    final t = targets;
    final total = todayTotals;
    final hour = DateTime.now().hour;
    final nextMeal = hour < 10
        ? '아침'
        : hour < 15
            ? '점심'
            : hour < 21
                ? '저녁'
                : '늦은 저녁/간식';

    final eaten = todayEntries.isEmpty
        ? '아직 아무것도 기록하지 않음'
        : todayEntries
            .map((e) => '${e.meal.label}: ${e.food.name} ${e.servings}인분 (${e.kcal.round()}kcal)')
            .join(', ');

    String remain(double target, double eatenVal, String unit) {
      final r = target - eatenVal;
      return r > 0 ? '${r.round()}$unit 더 채우면 좋음' : '충분히 채움';
    }

    final body = p == null
        ? '몸 정보 없음'
        : '''
- 닉네임: ${p.nickname}, ${p.isMale ? '남' : '여'}, ${p.age}세
- 키 ${p.heightCm}cm, 몸무게 ${p.weightKg}kg, 체지방률 ${p.bodyFatPercent}%, 골격근량 ${p.skeletalMuscleKg}kg
- 활동량: ${p.activity.label}
- 몸 상태 요약: ${insight!.headline}
- 인바디 분석: ${p.analysis.summaryForAi}
- 특히 챙기면 좋은 것: ${insight!.focusNutrients.join(', ')}''';

    final budget = t == null
        ? ''
        : '''
[오늘 남은 양]
- 에너지: ${remain(t.kcal, total.kcal, 'kcal')} (목표 ${t.kcal.round()} / 지금 ${total.kcal.round()})
- 탄수화물: ${remain(t.carbG, total.carbG, 'g')}
- 단백질: ${remain(t.proteinG, total.proteinG, 'g')}
- 지방: ${remain(t.fatG, total.fatG, 'g')}
- 나트륨: 지금 ${total.sodiumMg.round()}mg / 목표 ${t.sodiumMg.round()}mg 이하''';

    final nearby = nearbyPlaces.isEmpty
        ? '(아직 검색 전)'
        : nearbyPlaces
            .take(40)
            .map((p) => '${p.name} (${p.shortCategory}, ${p.distanceText})')
            .join(', ');

    return '''
너는 "MEAL:ON(밀온)"이라는 청소년 건강 식단 앱의 친절한 메뉴 코치야. 고등학생과 대화해.

[근처 1km 안 실제 식당 목록]
$nearby

[학생 정보]
$body

[오늘 먹은 것]
$eaten

$budget

[지금 시간] $hour시, 다음 끼니는 "$nextMeal"

[규칙]
1. 절대 "살 빼라", "굶어라", "칼로리 줄여라" 같은 말을 하지 마. 성장기니까 "무엇을 더 채우면 좋은지"로 말해.
2. 학원가 근처에서 실제로 살 수 있는 메뉴로 추천해 (덮밥, 국수, 분식, 샌드위치, 샐러드, 포케, 편의점 조합 등).
3. 메뉴를 추천할 때는 3가지를 번호로 나열하고, 각각 한 줄 이유를 붙여. 이유에는 "오늘 부족한 것"을 연결해.
   위 [근처 식당 목록]에 어울리는 가게가 있으면 "→ 근처: 가게이름 (거리)" 를 꼭 붙여. 목록에 없는 가게 이름을 지어내지 마.
4. 짧고 친근하게, 존댓말 대신 편한 반말 말투로. 200자 안팎.
5. 의학적 진단은 하지 마. 몸이 아프다고 하면 보건 선생님이나 병원을 권해.
''';
  }
}
