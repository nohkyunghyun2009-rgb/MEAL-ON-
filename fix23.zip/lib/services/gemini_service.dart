import 'dart:convert';

import 'package:http/http.dart' as http;

import '../config/app_keys.dart';
import 'claude_service.dart' show ChatMessage;

/// ═══════════════════════════════════════════════════════════
///  제미나이(Gemini)에게 편지를 보내고 답장을 받아오는 우체부
///  - 키는 lib/config/app_keys.dart 의 geminiApiKey 에서 읽어요
///  - Claude 우체부(claude_service.dart)와 똑같은 모양(ask)이라
///    AI 화면은 둘 중 아무거나 골라 쓸 수 있어요
///  - 웹 브라우저에서도 바로 호출돼요 (Claude와 달리 특별 헤더 불필요)
/// ═══════════════════════════════════════════════════════════
class GeminiService {
  /// 어떤 제미나이 모델을 쓸지. 404가 나면 'gemini-2.0-flash' 로 바꿔봐요.
  static const model = 'gemini-2.5-flash';

  static String get _url => 'https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent';

  /// 키를 넣었는지 확인 (구글 키는 "AIza..." 또는 "AQ." 로 시작해요)
  static bool get ready {
    final k = AppKeys.geminiApiKey.trim();
    return k.isNotEmpty && !k.contains('여기에') && (k.startsWith('AIza') || k.startsWith('AQ.'));
  }

  Future<String> ask({
    required String system,
    required List<ChatMessage> history,
  }) async {
    if (!ready) {
      throw Exception('Gemini API 키가 아직 없어요. lib/config/app_keys.dart 의 geminiApiKey 를 확인하세요.');
    }

    // 제미나이는 role 이름이 달라요: 학생 = 'user', AI = 'model'
    final contents = history
        .map((m) => {
              'role': m.isUser ? 'user' : 'model',
              'parts': [
                {'text': m.text}
              ],
            })
        .toList();

    final response = await http
        .post(
          Uri.parse(_url),
          headers: {
            'content-type': 'application/json',
            'x-goog-api-key': AppKeys.geminiApiKey.trim(),
          },
          body: jsonEncode({
            'system_instruction': {
              'parts': [
                {'text': system}
              ]
            },
            'contents': contents,
            'generationConfig': {
              'maxOutputTokens': 800,
              // 1.0 = 제미나이 기본값. 낮을수록 매번 비슷한 답(같은 가게)이 나와요.
              'temperature': 1.0,
            },
          }),
        )
        .timeout(const Duration(seconds: 60));

    if (response.statusCode != 200) {
      throw Exception('Gemini 응답 오류 (${response.statusCode}): ${utf8.decode(response.bodyBytes)}');
    }

    final data = jsonDecode(utf8.decode(response.bodyBytes)) as Map<String, dynamic>;
    final candidates = (data['candidates'] as List<dynamic>?) ?? const [];
    if (candidates.isEmpty) {
      throw Exception('Gemini가 답을 비워서 보냈어요 (안전 필터에 걸렸을 수 있어요)');
    }
    final parts = ((candidates.first as Map<String, dynamic>)['content']?['parts'] as List<dynamic>?) ?? const [];

    // 답장 중에서 "글자" 부분만 모아서 돌려줘요
    return parts
        .map((p) => (p as Map<String, dynamic>)['text'] as String? ?? '')
        .where((t) => t.isNotEmpty)
        .join('\n')
        .trim();
  }
}
