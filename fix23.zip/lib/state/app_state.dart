import 'dart:convert';
import 'dart:math';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../data/food_database.dart';
import '../data/partner_menus.dart';
import '../models/body_profile.dart';
import '../models/character.dart';
import '../models/nutrition.dart';
import '../services/claude_service.dart';
import '../services/kakao_local_service.dart';
import '../services/recommendation_memory.dart';

/// 앱의 "기억 상자".
/// 여러 화면이 같은 데이터를 보고, 바뀌면 자동으로 화면이 새로 그려져요.
class AppState extends ChangeNotifier {
  static const _kProfile = 'profile';
  static const _kEntries = 'entries';
  static const _kHistory = 'measurements'; // 측정 기록 (한 줄씩 쌓여요)

  BodyProfile? _profile;
  List<MealEntry> _entries = [];
  List<BodyProfile> _history = []; // 지금까지 잰 인바디 전부 (오래된 것부터)
  final List<ChatMessage> chat = []; // AI 대화 (앱을 끄면 사라져요)

  /// 추천 기억 상자: 최근에 어떤 가게·메뉴를 추천했는지 (폰에 저장, 3일 보관)
  /// → 같은 가게만 계속 나오는 걸 막아줘요
  final RecommendationMemory recMemory = RecommendationMemory();

  // 식당 찾기 탭이 받아온 "내 주변 1km 식당" (추천할 때 가게 이름을 붙이려고 기억해둬요)
  List<Place> nearbyPlaces = [];
  double? lastLat;
  double? lastLng;

  void setNearbyPlaces(List<Place> places, double lat, double lng) {
    nearbyPlaces = places;
    lastLat = lat;
    lastLng = lng;
    notifyListeners();
  }

  BodyProfile? get profile => _profile;
  bool get hasProfile => _profile != null;
  List<BodyProfile> get history => List.unmodifiable(_history);

  NutritionTargets? get targets =>
      _profile == null ? null : NutritionTargets.forProfile(_profile!);

  BodyInsight? get insight => _profile == null ? null : BodyInsight.from(_profile!);

  // ───── 폰에서 불러오기 (앱 켤 때 한 번) ─────
  Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    await recMemory.load();

    final p = prefs.getString(_kProfile);
    if (p != null) {
      _profile = BodyProfile.fromJson(jsonDecode(p) as Map<String, dynamic>);
    }

    final h = prefs.getString(_kHistory);
    if (h != null) {
      _history = (jsonDecode(h) as List<dynamic>)
          .map((x) => BodyProfile.fromJson(x as Map<String, dynamic>))
          .toList();
    } else if (_profile != null) {
      _history = [_profile!]; // 옛날 버전에서 저장한 게 있으면 첫 줄로
    }

    final e = prefs.getString(_kEntries);
    if (e != null) {
      final list = jsonDecode(e) as List<dynamic>;
      _entries = list
          .map((x) => MealEntry.fromJson(x as Map<String, dynamic>))
          .toList();
    }
    notifyListeners();
  }

  Future<void> _saveEntries() async {
    final prefs = await SharedPreferences.getInstance();
    // 최근 7일치만 남겨서 저장 공간 아끼기
    final cutoff = DateTime.now().subtract(const Duration(days: 7));
    _entries = _entries.where((e) => e.date.isAfter(cutoff)).toList();
    await prefs.setString(_kEntries, jsonEncode(_entries.map((e) => e.toJson()).toList()));
  }

  // ───── 인바디 정보 ─────
  Future<void> setProfile(BodyProfile p) async {
    _profile = p;
    _history = [..._history, p]; // 기록에 한 줄 추가
    if (_history.length > 60) _history = _history.sublist(_history.length - 60); // 최근 60번만
    chat.clear(); // 몸 정보가 바뀌면 AI 대화도 새로 시작
    notifyListeners();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_kProfile, jsonEncode(p.toJson()));
    await prefs.setString(_kHistory, jsonEncode(_history.map((x) => x.toJson()).toList()));
  }

  // ───── 식사 기록 ─────
  List<MealEntry> get todayEntries {
    final now = DateTime.now();
    return _entries.where((e) => e.isSameDay(now)).toList();
  }

  /// 최근 7일 기록 전부 (추천 엔진이 "이번 주에 자주 먹은 것"을 볼 때 써요)
  List<MealEntry> get weekEntries => List.unmodifiable(_entries);

  List<MealEntry> entriesFor(MealType meal) =>
      todayEntries.where((e) => e.meal == meal).toList();

  NutritionTotals get todayTotals => NutritionTotals.sum(todayEntries);

  // ───── 밀온이 (다마고치) ─────
  bool _justAte = false; // 방금 먹었을 때 잠깐 기뻐하는 표정
  MilonState get milon => MilonState.build(
        allEntries: _entries,
        todayEntries: todayEntries,
        targets: targets,
        todayTotals: todayTotals,
        profile: _profile,
        justAte: _justAte,
      );

  /// 방금 먹은 기쁨 표정을 잠깐 켰다가 끄기 (홈에서 애니메이션용)
  void _flashJustAte() {
    _justAte = true;
    notifyListeners();
    Future.delayed(const Duration(seconds: 4), () {
      _justAte = false;
      notifyListeners();
    });
  }

  Future<void> addEntry(MealType meal, FoodItem food, double servings) async {
    _entries.add(MealEntry(
      id: DateTime.now().microsecondsSinceEpoch.toString(),
      meal: meal,
      food: food,
      servings: servings,
      date: DateTime.now(),
    ));
    _flashJustAte(); // 밀온이가 방금 먹은 걸 기뻐해요
    notifyListeners();
    await _saveEntries();
  }

  Future<void> removeEntry(String id) async {
    _entries.removeWhere((e) => e.id == id);
    notifyListeners();
    await _saveEntries();
  }

  // ───── AI 대화 ─────
  void addChat(ChatMessage m) {
    chat.add(m);
    notifyListeners();
  }

  /// AI(또는 자체 추천)가 답한 글에서 가게·메뉴 이름을 찾아 기억해둬요.
  /// 다음 추천 때 "이건 방금 했으니 빼자"에 쓰여요.
  Future<void> rememberRecommendation(String reply) async {
    final found = await recMemory.remember(
      reply,
      placeNames: nearbyPlaces.map((p) => p.name),
      foodNames: FoodDatabase.all.map((f) => f.name),
    );
    if (found.isNotEmpty) notifyListeners();
  }

  /// 최근에 추천한 가게 이름 (가장 최근 것부터)
  List<String> get recentPlaceNames => recMemory.recentPlaces();

  /// 최근에 추천한 메뉴 이름 (가장 최근 것부터)
  List<String> get recentFoodNames => recMemory.recentFoods();

  /// Claude에게 보낼 "오늘의 상황 설명서"
  /// 몸 정보 + 오늘 먹은 것 + 남은 양을 글로 정리해요.
  String buildSystemPrompt() {
    final p = _profile;
    final t = targets;
    final total = todayTotals;
    final hour = DateTime.now().hour;
    final nextMeal = hour < 10
        ? '아침'
        : hour < 15
            ? '점심'
            : hour < 21
                ? '저녁'
                : '늦은 저녁/간식';

    final eaten = todayEntries.isEmpty
        ? '아직 아무것도 기록하지 않음'
        : todayEntries
            .map((e) => '${e.meal.label}: ${e.food.name} ${e.servings}인분 (${e.kcal.round()}kcal)')
            .join(', ');

    String remain(double target, double eatenVal, String unit) {
      final r = target - eatenVal;
      return r > 0 ? '${r.round()}$unit 더 채우면 좋음' : '충분히 채움';
    }

    final body = p == null
        ? '몸 정보 없음'
        : '''
- 닉네임: ${p.nickname}, ${p.isMale ? '남' : '여'}, ${p.age}세
- 키 ${p.heightCm}cm, 몸무게 ${p.weightKg}kg, 체지방률 ${p.bodyFatPercent}%, 골격근량 ${p.skeletalMuscleKg}kg
- 활동량: ${p.activity.label}
- 몸 상태 요약: ${insight!.headline}
- 인바디 분석: ${p.analysis.summaryForAi}
- 특히 챙기면 좋은 것: ${insight!.focusNutrients.join(', ')}''';

    final budget = t == null
        ? ''
        : '''
[오늘 남은 양]
- 에너지: ${remain(t.kcal, total.kcal, 'kcal')} (목표 ${t.kcal.round()} / 지금 ${total.kcal.round()})
- 탄수화물: ${remain(t.carbG, total.carbG, 'g')}
- 단백질: ${remain(t.proteinG, total.proteinG, 'g')}
- 지방: ${remain(t.fatG, total.fatG, 'g')}
- 나트륨: 지금 ${total.sodiumMg.round()}mg / 목표 ${t.sodiumMg.round()}mg 이하''';

    // ── 근처 식당: 매번 "종류별로 골고루 + 순서 섞어서 + 최근 추천한 곳은 빼고" 보여줘요.
    //    예전엔 늘 "가까운 순 40곳"을 똑같이 보내서 AI가 앞쪽 가게만 골랐어요.
    final recentPlaces = recentPlaceNames;
    final recentFoods = recentFoodNames;
    final nearby = _nearbyForPrompt(recentPlaces);

    final avoidPlaces = recentPlaces.isEmpty ? '(없음)' : recentPlaces.join(', ');
    final avoidFoods = recentFoods.isEmpty ? '(없음)' : recentFoods.join(', ');

    return '''
너는 "MEAL:ON(밀온)"이라는 청소년 건강 식단 앱의 친절한 메뉴 코치야. 고등학생과 대화해.

[근처 1km 안 실제 식당 목록 — 종류별] (★ = 제휴 가게, 앱에서 바로 예약돼)
$nearby

[최근에 이미 추천한 가게 — 학생이 콕 집어 묻지 않는 한 이번엔 추천하지 마]
$avoidPlaces

[최근에 이미 추천한 메뉴 — 이번엔 다른 메뉴로]
$avoidFoods

[학생 정보]
$body

[오늘 먹은 것]
$eaten

$budget

[지금 시간] $hour시, 다음 끼니는 "$nextMeal"

[규칙]
1. 절대 "살 빼라", "굶어라", "칼로리 줄여라" 같은 말을 하지 마. 성장기니까 "무엇을 더 채우면 좋은지"로 말해.
2. 학원가 근처에서 실제로 살 수 있는 메뉴로 추천해 (덮밥, 국수, 분식, 샌드위치, 샐러드, 포케, 편의점 조합 등).
3. 메뉴를 추천할 때는 3가지를 번호로 나열하고, 각각 한 줄 이유를 붙여. 이유에는 "오늘 부족한 것"을 연결해.
   3가지는 서로 다른 종류(예: 밥·면·샐러드)로 고르고, 가게도 3곳 모두 다르게.
   위 [근처 식당 목록]에서 어울리는 가게를 골라 "→ 근처: 가게이름 (거리)" 를 꼭 붙여. 목록에 없는 가게 이름을 지어내지 마.
4. 같은 가게를 연달아 추천하지 마. [최근에 이미 추천한 가게]에 있는 곳은 빼고, 목록의 다른 가게를 골라.
   가까운 순서가 아니라 "오늘 몸에 맞는 메뉴가 있는 가게"를 골라 — 1km 안이면 조금 멀어도 괜찮아.
   목록은 매번 새로 섞여서 오니까, 이번 목록 안에서 골라.
5. 학생이 "다른 거", "말고"라고 하면 직전 답과 가게·메뉴 종류를 모두 다르게.
6. 짧고 친근하게, 존댓말 대신 편한 반말 말투로. 200자 안팎.
7. 의학적 진단은 하지 마. 몸이 아프다고 하면 보건 선생님이나 병원을 권해.
''';
  }

  /// AI에게 보여줄 식당 목록 글 만들기 (종류별로 묶어서)
  String _nearbyForPrompt(List<String> recentPlaces) {
    if (nearbyPlaces.isEmpty) return '(아직 검색 전)';

    final picked = RecommendationMemory.pickForPrompt(
      nearbyPlaces,
      avoid: recentPlaces,
      rng: Random(),
    );

    // 종류별로 묶기 (같은 종류끼리 한 줄에)
    final groups = <String, List<Place>>{};
    for (final p in picked) {
      groups.putIfAbsent(p.shortCategory.isEmpty ? '기타' : p.shortCategory, () => []).add(p);
    }
    final lines = <String>[];
    for (final e in groups.entries) {
      final names = e.value.map((p) => '${MenuCatalog.isPartner(p) ? '★' : ''}${p.name} (${p.distanceText})').join(', ');
      lines.add('- ${e.key}: $names');
    }
    return lines.join('\n');
  }
}
