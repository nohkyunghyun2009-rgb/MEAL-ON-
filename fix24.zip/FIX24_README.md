# fix24 — "저녁 추천해줘"에 야식이 나오던 것 + AI 반복 추천 추가 방지

fix23 위에 덮어쓰는 패치예요. 이 zip의 `lib`, `test` 폴더를 프로젝트 폴더에 덮어쓰면 됩니다.

## 고친 것
1. **끼니를 말하면 시계보다 우선** — 밤 11시에 "저녁 추천해줘"라고 해도 야식이 아니라 저녁 메뉴로.
   (AI 프롬프트와 자체 추천 엔진 둘 다)
2. **AI 반복 방지 강화** — "이 대화에서 이미 말한 가게·메뉴는 다시 추천하지 마, 연속으로 물으면 매번 새로운 3곳" 규칙 추가.
3. **제휴 가게 메뉴 예시** — ★제휴 가게는 실제 메뉴판에서 식사 메뉴 3개를 프롬프트에 같이 보내서, AI가 진짜 메뉴 이름으로 추천.
4. **메뉴 기억 매칭 개선** — AI가 "김치찌개"라고만 써도 "김치찌개 백반"으로 기억해서 다음엔 피함.

## 바뀐 파일
- lib/services/recommendation_memory.dart (MealHint 추가, foodCore 추가)
- lib/state/app_state.dart (프롬프트)
- lib/services/local_coach.dart (끼니 시각 계산)
- test/recommendation_memory_test.dart (테스트 10개)
