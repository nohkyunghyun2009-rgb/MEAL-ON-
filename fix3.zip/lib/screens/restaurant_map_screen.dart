import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:geolocator/geolocator.dart';
import 'package:latlong2/latlong.dart';

import '../config/app_keys.dart';
import '../services/kakao_local_service.dart';
import '../theme/app_theme.dart';
import 'reservation_sheet.dart';

/// "식당 찾기" 탭: 내 위치 반경 1km 안의 식당을 지도 + 목록으로 표시
/// 지도 그림은 OpenStreetMap(무료, 키 필요 없음), 식당 데이터는 카카오에서 받아요.
class RestaurantMapScreen extends StatefulWidget {
  const RestaurantMapScreen({super.key});

  @override
  State<RestaurantMapScreen> createState() => _RestaurantMapScreenState();
}

class _RestaurantMapScreenState extends State<RestaurantMapScreen> {
  final _local = KakaoLocalService();
  final _keyword = TextEditingController();
  final _mapController = MapController();
  bool _mapReady = false;

  // GPS를 못 받으면 여기(백마 학원가 근처)를 기준으로 찾아요
  static const _fallbackLat = 37.6595;
  static const _fallbackLng = 126.7855;
  static const _radiusM = 1000;
  static const _zoom = 14.4; // 1km 원이 화면에 딱 들어오는 정도

  double _lat = _fallbackLat;
  double _lng = _fallbackLng;
  bool _usingFallback = true;

  List<Place> _places = [];
  bool _loading = false;
  String? _error;
  String? _selectedId; // 목록/핀에서 고른 식당

  @override
  void initState() {
    super.initState();
    _locateThenSearch();
  }

  @override
  void dispose() {
    _keyword.dispose();
    _mapController.dispose();
    super.dispose();
  }

  /// 1) 내 위치 알아내기 → 2) 그 주변 식당 검색
  Future<void> _locateThenSearch() async {
    setState(() => _loading = true);
    try {
      var permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
      }
      if (permission == LocationPermission.always || permission == LocationPermission.whileInUse) {
        final pos = await Geolocator.getCurrentPosition().timeout(const Duration(seconds: 10));
        _lat = pos.latitude;
        _lng = pos.longitude;
        _usingFallback = false;
      }
    } catch (_) {
      // 위치를 못 받아도 괜찮아요. 기본 위치로 계속 진행.
    }
    await _search();
  }

  Future<void> _search() async {
    setState(() {
      _loading = true;
      _error = null;
      _selectedId = null;
    });
    try {
      final places = await _local.searchNearby(
        lat: _lat,
        lng: _lng,
        keyword: _keyword.text,
        radiusM: _radiusM,
      );
      setState(() => _places = places);
      _moveMapToCenter();
    } catch (e) {
      setState(() => _error = e.toString());
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  void _moveMapToCenter() {
    if (!_mapReady) return;
    try {
      _mapController.move(LatLng(_lat, _lng), _zoom);
    } catch (_) {}
  }

  void _openReservation(Place place) {
    setState(() => _selectedId = place.id);
    try {
      _mapController.move(LatLng(place.lat, place.lng), 16);
    } catch (_) {}
    showReservationSheet(context, place);
  }

  // ───── 지도 위에 올릴 것들 ─────
  List<Marker> get _markers {
    final list = <Marker>[
      // 내 위치 (또는 기준점)
      Marker(
        point: LatLng(_lat, _lng),
        width: 22,
        height: 22,
        child: Container(
          decoration: BoxDecoration(
            color: AppColors.sky,
            shape: BoxShape.circle,
            border: Border.all(color: Colors.white, width: 3),
          ),
        ),
      ),
    ];
    for (var i = 0; i < _places.length; i++) {
      final p = _places[i];
      final selected = p.id == _selectedId;
      list.add(
        Marker(
          point: LatLng(p.lat, p.lng),
          width: 34,
          height: 34,
          child: GestureDetector(
            onTap: () => _openReservation(p),
            child: Container(
              decoration: BoxDecoration(
                color: selected ? AppColors.coral : AppColors.green,
                shape: BoxShape.circle,
                border: Border.all(color: Colors.white, width: 2),
                boxShadow: const [BoxShadow(color: Colors.black26, blurRadius: 4, offset: Offset(0, 2))],
              ),
              alignment: Alignment.center,
              child: Text(
                '${i + 1}',
                style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 13),
              ),
            ),
          ),
        ),
      );
    }
    return list;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('내 주변 1km 식당')),
      body: Column(
        children: [
          // ───── 검색창 ─────
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 0, 20, 10),
            child: TextField(
              controller: _keyword,
              textInputAction: TextInputAction.search,
              onSubmitted: (_) => _search(),
              decoration: InputDecoration(
                hintText: '덮밥, 국수, 샐러드...',
                prefixIcon: const Icon(Icons.search),
                suffixIcon: IconButton(
                  tooltip: '내 위치로',
                  icon: const Icon(Icons.my_location),
                  onPressed: _locateThenSearch,
                ),
              ),
            ),
          ),

          // ───── 지도 ─────
          SizedBox(
            height: 280,
            child: Stack(
              children: [
                FlutterMap(
                    mapController: _mapController,
                    options: MapOptions(
                      initialCenter: LatLng(_lat, _lng),
                      initialZoom: _zoom,
                      onMapReady: () {
                        _mapReady = true;
                        _moveMapToCenter();
                      },
                    ),
                    children: [
                      TileLayer(
                        urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                        userAgentPackageName: 'com.hankki.hankki',
                      ),
                      CircleLayer(
                        circles: [
                          CircleMarker(
                            point: LatLng(_lat, _lng),
                            radius: _radiusM.toDouble(),
                            useRadiusInMeter: true,
                            color: AppColors.green.withOpacity(0.10),
                            borderColor: AppColors.green,
                            borderStrokeWidth: 2,
                          ),
                        ],
                      ),
                      MarkerLayer(markers: _markers),
                      SimpleAttributionWidget(
                        source: const Text('OpenStreetMap', style: TextStyle(fontSize: 10)),
                      ),
                    ],
                ),
                if (_usingFallback)
                  Positioned(
                    left: 12,
                    top: 12,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(999),
                        border: Border.all(color: AppColors.line),
                      ),
                      child: const Text('기준: 백마 학원가', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700)),
                    ),
                  ),
                if (!AppKeys.kakaoReady)
                  Positioned(
                    left: 12,
                    right: 12,
                    bottom: 12,
                    child: Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(color: AppColors.sun.withOpacity(0.9), borderRadius: BorderRadius.circular(12)),
                      child: const Text('카카오 REST 키를 넣으면 식당이 검색돼요 (lib/config/app_keys.dart)', style: TextStyle(fontSize: 12)),
                    ),
                  ),
              ],
            ),
          ),

          // ───── 목록 ─────
          Expanded(
            child: _loading
                ? const Center(child: CircularProgressIndicator())
                : _error != null
                    ? _Message(icon: Icons.wifi_off, text: _error!)
                    : _places.isEmpty
                        ? const _Message(icon: Icons.search_off, text: '1km 안에서 못 찾았어요.\n다른 말로 검색해봐요.')
                        : ListView.separated(
                            padding: const EdgeInsets.fromLTRB(20, 12, 20, 24),
                            itemCount: _places.length + 1, // 맨 위 한 칸은 "N곳" 안내
                            separatorBuilder: (_, __) => const SizedBox(height: 8),
                            itemBuilder: (_, index) {
                              if (index == 0) {
                                return Padding(
                                  padding: const EdgeInsets.only(bottom: 4),
                                  child: Text(
                                    _keyword.text.trim().isEmpty
                                        ? '1km 안 식당 ${_places.length}곳 · 가까운 순'
                                        : '"${_keyword.text.trim()}" ${_places.length}곳 · 가까운 순',
                                    style: Theme.of(context).textTheme.bodySmall,
                                  ),
                                );
                              }
                              final i = index - 1;
                              final p = _places[i];
                              final selected = p.id == _selectedId;
                              return Card(
                                child: ListTile(
                                  onTap: () => _openReservation(p),
                                  leading: CircleAvatar(
                                    backgroundColor: selected ? AppColors.coral : AppColors.mint,
                                    child: Text(
                                      '${i + 1}',
                                      style: TextStyle(
                                        color: selected ? Colors.white : AppColors.green,
                                        fontWeight: FontWeight.w800,
                                      ),
                                    ),
                                  ),
                                  title: Text(p.name, style: const TextStyle(fontWeight: FontWeight.w700)),
                                  subtitle: Text('${p.shortCategory} · ${p.address}', maxLines: 1, overflow: TextOverflow.ellipsis),
                                  trailing: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    crossAxisAlignment: CrossAxisAlignment.end,
                                    children: [
                                      Text(p.distanceText, style: const TextStyle(fontWeight: FontWeight.w800, color: AppColors.green)),
                                      const Text('예약', style: TextStyle(fontSize: 12, color: AppColors.muted)),
                                    ],
                                  ),
                                ),
                              );
                            },
                          ),
          ),
        ],
      ),
    );
  }
}

class _Message extends StatelessWidget {
  final IconData icon;
  final String text;
  const _Message({required this.icon, required this.text});

  @override
  Widget build(BuildContext context) => Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon, size: 36, color: AppColors.muted),
              const SizedBox(height: 10),
              Text(text, textAlign: TextAlign.center, style: Theme.of(context).textTheme.bodyMedium),
            ],
          ),
        ),
      );
}
