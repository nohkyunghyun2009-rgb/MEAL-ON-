import 'dart:convert';

import 'package:http/http.dart' as http;

import '../config/app_keys.dart';

/// 카카오가 알려주는 "장소 한 곳"
class Place {
  final String id;
  final String name;
  final String category; // 예: 음식점 > 한식 > 덮밥
  final String address;
  final String phone;
  final double lat;
  final double lng;
  final int distanceM; // 나와의 거리(m)
  final String url; // 카카오맵 상세 페이지

  const Place({
    required this.id,
    required this.name,
    required this.category,
    required this.address,
    required this.phone,
    required this.lat,
    required this.lng,
    required this.distanceM,
    required this.url,
  });

  /// "음식점 > 한식 > 덮밥" 에서 마지막 "덮밥"만 꺼내기
  String get shortCategory {
    final parts = category.split('>').map((s) => s.trim()).toList();
    return parts.isEmpty ? '' : parts.last;
  }

  String get distanceText =>
      distanceM >= 1000 ? '${(distanceM / 1000).toStringAsFixed(1)}km' : '${distanceM}m';

  factory Place.fromKakao(Map<String, dynamic> d) => Place(
        id: d['id'] as String,
        name: d['place_name'] as String,
        category: (d['category_name'] ?? '') as String,
        address: ((d['road_address_name'] as String?)?.isNotEmpty ?? false)
            ? d['road_address_name'] as String
            : (d['address_name'] ?? '') as String,
        phone: (d['phone'] ?? '') as String,
        lat: double.parse(d['y'] as String),
        lng: double.parse(d['x'] as String),
        distanceM: int.tryParse((d['distance'] ?? '0') as String) ?? 0,
        url: (d['place_url'] ?? '') as String,
      );
}

/// 카카오 로컬 API로 "내 주변 1km 음식점" 찾기
///
/// 카카오는 한 번에 최대 15개만 알려줘요. 그래서 "다음 페이지도 주세요"를
/// is_end(끝이에요)가 나올 때까지 반복해서 1km 안 식당을 전부 모아요.
class KakaoLocalService {
  Future<List<Place>> searchNearby({
    required double lat,
    required double lng,
    String keyword = '',
    int radiusM = 1000,
    int maxPages = 20, // 15개 × 20페이지 = 최대 300곳
  }) async {
    if (!AppKeys.kakaoReady) {
      throw Exception('카카오 키가 아직 없어요. lib/config/app_keys.dart 를 확인하세요.');
    }

    final q = keyword.trim();
    final all = <Place>[];
    final seen = <String>{}; // 같은 가게가 두 번 들어오지 않게

    for (var page = 1; page <= maxPages; page++) {
      final params = {
        'x': '$lng', // 카카오는 x가 경도(lng), y가 위도(lat)예요
        'y': '$lat',
        'radius': '$radiusM',
        'category_group_code': 'FD6', // FD6 = 음식점
        'sort': 'distance', // 가까운 순서
        'size': '15',
        'page': '$page',
      };

      // 검색어가 없으면 "음식점 전체", 있으면 "그 단어로 검색"
      final uri = q.isEmpty
          ? Uri.https('dapi.kakao.com', '/v2/local/search/category.json', params)
          : Uri.https('dapi.kakao.com', '/v2/local/search/keyword.json', {...params, 'query': q});

      final res = await http.get(uri, headers: {
        'Authorization': 'KakaoAK ${AppKeys.kakaoRestApiKey}',
      }).timeout(const Duration(seconds: 20));

      if (res.statusCode != 200) {
        throw Exception('카카오 검색 오류 (${res.statusCode}): ${utf8.decode(res.bodyBytes)}');
      }

      final data = jsonDecode(utf8.decode(res.bodyBytes)) as Map<String, dynamic>;
      final docs = data['documents'] as List<dynamic>;
      for (final d in docs) {
        final place = Place.fromKakao(d as Map<String, dynamic>);
        if (seen.add(place.id)) all.add(place);
      }

      final meta = data['meta'] as Map<String, dynamic>?;
      final isEnd = meta?['is_end'] == true;
      if (isEnd || docs.isEmpty) break;
    }

    all.sort((a, b) => a.distanceM.compareTo(b.distanceM));
    return all;
  }
}
