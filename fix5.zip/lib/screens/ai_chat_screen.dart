import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../config/app_keys.dart';
import '../services/claude_service.dart';
import '../services/local_coach.dart';
import '../state/app_state.dart';
import '../theme/app_theme.dart';

/// "AI 추천" 탭: Claude에게 직접 물어보는 채팅 화면
class AiChatScreen extends StatefulWidget {
  const AiChatScreen({super.key});

  @override
  State<AiChatScreen> createState() => _AiChatScreenState();
}

class _AiChatScreenState extends State<AiChatScreen> {
  final _claude = ClaudeService();
  final _input = TextEditingController();
  final _scroll = ScrollController();
  bool _loading = false;

  // 학생이 자주 묻는 질문을 버튼으로 미리 준비해요
  static const _quickQuestions = [
    '지금 뭐 먹으면 좋아?',
    '5천 원으로 뭐 먹지?',
    '단백질 많은 메뉴 추천해줘',
    '편의점에서 살 수 있는 걸로!',
  ];

  @override
  void dispose() {
    _input.dispose();
    _scroll.dispose();
    super.dispose();
  }

  Future<void> _send(String text) async {
    final t = text.trim();
    if (t.isEmpty || _loading) return;

    final app = context.read<AppState>();
    app.addChat(ChatMessage('user', t)); // 1) 내 말풍선 먼저 보여주기
    _input.clear();
    setState(() => _loading = true);
    _scrollToEnd();

    try {
      if (!AppKeys.claudeReady) {
        // 2-a) Claude 키가 없으면 앱 자체 추천 엔진이 답해요 (돈·인터넷 필요 없음)
        await Future.delayed(const Duration(milliseconds: 500)); // 잠깐 생각하는 느낌
        app.addChat(ChatMessage('assistant', await LocalCoach.reply(t, app)));
      } else {
        // 2-b) Claude에게 "지금까지 대화 + 오늘 상황 설명서" 보내기
        final reply = await _claude.ask(
          system: app.buildSystemPrompt(),
          history: List.of(app.chat),
        );
        app.addChat(ChatMessage('assistant', reply));
      }
    } catch (e) {
      // Claude가 실패하면(크레딧 부족, 인터넷 끊김 등) 자체 추천으로 대신 답해요
      debugPrint('Claude 실패, 자체 추천으로 대체: $e');
      app.addChat(ChatMessage('assistant', await LocalCoach.reply(t, app)));
    } finally {
      if (mounted) setState(() => _loading = false);
      _scrollToEnd();
    }
  }

  void _scrollToEnd() {
    // 화면이 다시 그려진 "다음" 순간에 맨 아래로 내려요
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scroll.hasClients) {
        _scroll.animateTo(
          _scroll.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final messages = app.chat;

    return Scaffold(
      appBar: AppBar(title: const Text('AI 메뉴 코치')),
      body: Column(
        children: [
          if (!AppKeys.claudeReady)
            Container(
              margin: const EdgeInsets.fromLTRB(20, 0, 20, 8),
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(color: AppColors.sun.withOpacity(0.2), borderRadius: BorderRadius.circular(14)),
              child: const Text('지금은 앱 자체 추천 모드예요. Claude 키와 크레딧을 연결하면 대화형 AI로 바뀌어요.', style: TextStyle(fontSize: 13)),
            ),
          Expanded(
            child: messages.isEmpty
                ? _EmptyState(onTap: _send)
                : ListView.builder(
                    controller: _scroll,
                    padding: const EdgeInsets.fromLTRB(20, 8, 20, 12),
                    itemCount: messages.length + (_loading ? 1 : 0),
                    itemBuilder: (_, i) {
                      if (i == messages.length) return const _TypingBubble();
                      return _Bubble(message: messages[i]);
                    },
                  ),
          ),
          // 빠른 질문 버튼
          if (messages.isNotEmpty)
            SizedBox(
              height: 40,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 20),
                itemCount: _quickQuestions.length,
                separatorBuilder: (_, __) => const SizedBox(width: 8),
                itemBuilder: (_, i) => ActionChip(
                  label: Text(_quickQuestions[i]),
                  onPressed: () => _send(_quickQuestions[i]),
                ),
              ),
            ),
          // 입력창
          SafeArea(
            top: false,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 10, 16, 12),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _input,
                      minLines: 1,
                      maxLines: 4,
                      textInputAction: TextInputAction.send,
                      onSubmitted: _send,
                      decoration: const InputDecoration(hintText: '메뉴 코치에게 물어보기'),
                    ),
                  ),
                  const SizedBox(width: 8),
                  IconButton.filled(
                    onPressed: _loading ? null : () => _send(_input.text),
                    icon: const Icon(Icons.arrow_upward),
                    style: IconButton.styleFrom(backgroundColor: AppColors.green, minimumSize: const Size(50, 50)),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

/// 아직 대화가 없을 때 보이는 안내 + 시작 버튼
class _EmptyState extends StatelessWidget {
  final void Function(String) onTap;
  const _EmptyState({required this.onTap});

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final focus = app.insight?.focusNutrients.join(', ') ?? '골고루';

    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 20),
      children: [
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(color: AppColors.mint, borderRadius: BorderRadius.circular(24)),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Icon(Icons.auto_awesome, color: AppColors.green, size: 32),
              const SizedBox(height: 12),
              Text('오늘 몸 상태와 먹은 걸 보고\n메뉴를 골라줄게', style: Theme.of(context).textTheme.titleLarge),
              const SizedBox(height: 8),
              Text('오늘 특히 챙기면 좋은 것: $focus', style: Theme.of(context).textTheme.bodyMedium),
            ],
          ),
        ),
        const SizedBox(height: 20),
        ..._AiChatScreenState._quickQuestions.map((q) => Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: OutlinedButton(onPressed: () => onTap(q), child: Text(q)),
            )),
      ],
    );
  }
}

/// 말풍선 하나
class _Bubble extends StatelessWidget {
  final ChatMessage message;
  const _Bubble({required this.message});

  @override
  Widget build(BuildContext context) {
    final isUser = message.isUser;
    return Align(
      alignment: isUser ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 6),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.8),
        decoration: BoxDecoration(
          color: isUser ? AppColors.green : Colors.white,
          border: isUser ? null : Border.all(color: AppColors.line),
          borderRadius: BorderRadius.only(
            topLeft: const Radius.circular(20),
            topRight: const Radius.circular(20),
            bottomLeft: Radius.circular(isUser ? 20 : 4),
            bottomRight: Radius.circular(isUser ? 4 : 20),
          ),
        ),
        child: SelectableText(
          message.text,
          style: TextStyle(color: isUser ? Colors.white : AppColors.ink, fontSize: 15, height: 1.5),
        ),
      ),
    );
  }
}

/// "생각 중..." 표시
class _TypingBubble extends StatelessWidget {
  const _TypingBubble();

  @override
  Widget build(BuildContext context) => Align(
        alignment: Alignment.centerLeft,
        child: Container(
          margin: const EdgeInsets.symmetric(vertical: 6),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          decoration: BoxDecoration(
            color: Colors.white,
            border: Border.all(color: AppColors.line),
            borderRadius: BorderRadius.circular(20),
          ),
          child: const Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2)),
              SizedBox(width: 10),
              Text('메뉴 고르는 중...', style: TextStyle(color: AppColors.muted)),
            ],
          ),
        ),
      );
}
