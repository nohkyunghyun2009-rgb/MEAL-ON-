import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../config/app_keys.dart';
import '../services/claude_service.dart';
import '../services/local_coach.dart';
import '../state/app_state.dart';
import '../theme/app_theme.dart';

/// "AI 추천" 탭: Claude에게 직접 물어보는 채팅 화면
class AiChatScreen extends StatefulWidget {
  const AiChatScreen({super.key});

  @override
  State<AiChatScreen> createState() => _AiChatScreenState();
}

class _AiChatScreenState extends State<AiChatScreen> {
  final _claude = ClaudeService();
  final _input = TextEditingController();
  final _scroll = ScrollController();
  bool _loading = false;

  // 학생이 자주 묻는 질문을 버튼으로 미리 준비해요
  static const _quickQuestions = [
    '지금 뭐 먹으면 좋아?',
    '5천 원으로 뭐 먹지?',
    '단백질 많은 메뉴 추천해줘',
    '편의점에서 살 수 있는 걸로!',
  ];

  @override
  void dispose() {
    _input.dispose();
    _scroll.dispose();
    super.dispose();
  }

  Future<void> _send(String text) async {
    final t = text.trim();
    if (t.isEmpty || _loading) return;

    final app = context.read<AppState>();
    app.addChat(ChatMessage('user', t)); // 1) 내 말풍선 먼저 보여주기
    _input.clear();
    setState(() => _loading = true);
    _scrollToEnd();

    try {
      if (!AppKeys.claudeReady) {
        // 2-a) Claude 키가 없으면 앱 자체 추천 엔진이 답해요 (돈·인터넷 필요 없음)
        await Future.delayed(const Duration(milliseconds: 500)); // 잠깐 생각하는 느낌
        app.addChat(ChatMessage('assistant', await LocalCoach.reply(t, app)));
      } else {
        // 2-b) Claude에게 "지금까지 대화 + 오늘 상황 설명서" 보내기
        final reply = await _claude.ask(
          system: app.buildSystemPrompt(),
          history: List.of(app.chat),
        );
        app.addChat(ChatMessage('assistant', reply));
      }
    } catch (e) {
      // Claude가 실패하면(크레딧 부족, 인터넷 끊김 등) 자체 추천으로 대신 답해요
      debugPrint('Claude 실패, 자체 추천으로 대체: $e');
      app.addChat(ChatMessage('assistant', await LocalCoach.reply(t, app)));
    } finally {
      if (mounted) setState(() => _loading = false);
      _scrollToEnd();
    }
  }

  void _scrollToEnd() {
    // 화면이 다시 그려진 "다음" 순간에 맨 아래로 내려요
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scroll.hasClients) {
        _scroll.animateTo(
          _scroll.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final messages = app.chat;

    return Scaffold(
      appBar: AppBar(title: const Text('AI 메뉴 코치')),
      body: Column(
        children: [
          if (!AppKeys.claudeReady)
            Container(
              margin: const EdgeInsets.fromLTRB(20, 0, 20, 8),
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(color: AppColors.mint, borderRadius: BorderRadius.circular(14)),
              child: const Row(
                children: [
                  Text('🧠', style: TextStyle(fontSize: 16)),
                  SizedBox(width: 8),
                  Expanded(child: Text('앱 자체 추천 모드 · Claude를 연결하면 대화형으로 바뀌어요', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700))),
                ],
              ),
            ),
          Expanded(
            child: messages.isEmpty
                ? _EmptyState(onTap: _send)
                : ListView.builder(
                    controller: _scroll,
                    padding: const EdgeInsets.fromLTRB(20, 8, 20, 12),
                    itemCount: messages.length + (_loading ? 1 : 0),
                    itemBuilder: (_, i) {
                      if (i == messages.length) return const _TypingBubble();
                      return _Bubble(message: messages[i]);
                    },
                  ),
          ),
          // 빠른 질문 버튼
          if (messages.isNotEmpty)
            SizedBox(
              height: 40,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 20),
                itemCount: _quickQuestions.length,
                separatorBuilder: (_, __) => const SizedBox(width: 8),
                itemBuilder: (_, i) => ActionChip(
                  label: Text(_quickQuestions[i]),
                  onPressed: () => _send(_quickQuestions[i]),
                ),
              ),
            ),
          // 입력창
          SafeArea(
            top: false,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 10, 16, 12),
              child: Row(
                children: [
                  Expanded(
                    child: Container(
                      decoration: BoxDecoration(borderRadius: BorderRadius.circular(16), boxShadow: AppColors.cardShadow),
                      child: TextField(
                        controller: _input,
                        minLines: 1,
                        maxLines: 4,
                        textInputAction: TextInputAction.send,
                        onSubmitted: _send,
                        decoration: const InputDecoration(hintText: '메뉴 코치에게 물어보기'),
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  IconButton.filled(
                    onPressed: _loading ? null : () => _send(_input.text),
                    icon: const Icon(Icons.arrow_upward_rounded),
                    style: IconButton.styleFrom(backgroundColor: AppColors.primary, minimumSize: const Size(52, 52)),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

/// 아직 대화가 없을 때 보이는 안내 + 시작 버튼
class _EmptyState extends StatelessWidget {
  final void Function(String) onTap;
  const _EmptyState({required this.onTap});

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final focus = app.insight?.focusNutrients.join(', ') ?? '골고루';

    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 20),
      children: [
        Container(
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(
            gradient: const LinearGradient(colors: [Color(0xFFFF6B4A), Color(0xFFFF9A7A)], begin: Alignment.topLeft, end: Alignment.bottomRight),
            borderRadius: BorderRadius.circular(26),
            boxShadow: [BoxShadow(color: AppColors.primary.withOpacity(0.3), blurRadius: 20, offset: const Offset(0, 8))],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('🍱', style: TextStyle(fontSize: 34)),
              const SizedBox(height: 12),
              const Text('오늘 몸 상태와 먹은 걸 보고\n근처 가게까지 골라줄게', style: TextStyle(color: Colors.white, fontSize: 21, fontWeight: FontWeight.w900, height: 1.3, letterSpacing: -0.5)),
              const SizedBox(height: 10),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(color: Colors.white.withOpacity(0.22), borderRadius: BorderRadius.circular(999)),
                child: Text('오늘 챙기면 좋은 것: $focus', style: const TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w700)),
              ),
            ],
          ),
        ),
        const SizedBox(height: 20),
        ..._AiChatScreenState._quickQuestions.map((q) => Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: OutlinedButton(onPressed: () => onTap(q), child: Text(q)),
            )),
      ],
    );
  }
}

/// 말풍선 하나
class _Bubble extends StatelessWidget {
  final ChatMessage message;
  const _Bubble({required this.message});

  @override
  Widget build(BuildContext context) {
    final isUser = message.isUser;
    final bubble = Container(
      margin: const EdgeInsets.symmetric(vertical: 6),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 13),
      constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.78),
      decoration: BoxDecoration(
        color: isUser ? AppColors.primary : Colors.white,
        boxShadow: isUser ? null : AppColors.cardShadow,
        borderRadius: BorderRadius.only(
          topLeft: const Radius.circular(20),
          topRight: const Radius.circular(20),
          bottomLeft: Radius.circular(isUser ? 20 : 6),
          bottomRight: Radius.circular(isUser ? 6 : 20),
        ),
      ),
      child: SelectableText(
        message.text,
        style: TextStyle(color: isUser ? Colors.white : AppColors.ink, fontSize: 15, height: 1.55, fontWeight: isUser ? FontWeight.w700 : FontWeight.w500),
      ),
    );

    if (isUser) return Align(alignment: Alignment.centerRight, child: bubble);

    return Row(
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        Container(
          width: 30,
          height: 30,
          margin: const EdgeInsets.only(right: 8, bottom: 8),
          decoration: const BoxDecoration(color: AppColors.mint, shape: BoxShape.circle),
          alignment: Alignment.center,
          child: const Text('🍚', style: TextStyle(fontSize: 15)),
        ),
        Flexible(child: bubble),
      ],
    );
  }
}

/// "생각 중..." 표시
class _TypingBubble extends StatelessWidget {
  const _TypingBubble();

  @override
  Widget build(BuildContext context) => Align(
        alignment: Alignment.centerLeft,
        child: Container(
          margin: const EdgeInsets.symmetric(vertical: 6),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          decoration: BoxDecoration(
            color: Colors.white,
            boxShadow: AppColors.cardShadow,
            borderRadius: BorderRadius.circular(20),
          ),
          child: const Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2)),
              SizedBox(width: 10),
              Text('메뉴 고르는 중...', style: TextStyle(color: AppColors.muted)),
            ],
          ),
        ),
      );
}
