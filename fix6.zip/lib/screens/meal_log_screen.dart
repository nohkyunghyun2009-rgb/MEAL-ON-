import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/nutrition.dart';
import '../state/app_state.dart';
import '../theme/app_theme.dart';
import '../widgets/body_summary_card.dart';
import '../widgets/nutrient_gauge.dart';
import 'body_input_screen.dart';
import 'food_picker_sheet.dart';

/// "홈" 탭: 인사 + 바로가기 + 오늘의 균형 게이지 + 끼니 기록
class MealLogScreen extends StatelessWidget {
  final void Function(int tabIndex)? onGoToTab;
  const MealLogScreen({super.key, this.onGoToTab});

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final p = app.profile;
    final t = app.targets;
    final total = app.todayTotals;
    final now = DateTime.now();
    const days = ['월', '화', '수', '목', '금', '토', '일'];

    return Scaffold(
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 32),
          children: [
            // ───── 인사 헤더 ─────
            Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('${now.month}월 ${now.day}일 ${days[now.weekday - 1]}요일', style: Theme.of(context).textTheme.bodySmall),
                      const SizedBox(height: 4),
                      Text(
                        p == null ? '오늘 뭐 먹지? 🍚' : '${p.nickname}, 오늘 뭐 먹지? 🍚',
                        style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontSize: 26),
                      ),
                    ],
                  ),
                ),
                InkWell(
                  onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const BodyInputScreen())),
                  borderRadius: BorderRadius.circular(999),
                  child: Container(
                    width: 48,
                    height: 48,
                    decoration: BoxDecoration(color: AppColors.mint, shape: BoxShape.circle),
                    alignment: Alignment.center,
                    child: Text(
                      p == null ? '?' : p.nickname.characters.first,
                      style: const TextStyle(color: AppColors.green, fontWeight: FontWeight.w900, fontSize: 18),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 18),

            // ───── 바로가기 타일 ─────
            Row(
              children: [
                Expanded(child: _QuickTile(emoji: '✨', title: 'AI 추천', sub: '오늘 뭐 먹지', color: AppColors.peach, onTap: () => onGoToTab?.call(1))),
                const SizedBox(width: 10),
                Expanded(child: _QuickTile(emoji: '📍', title: '근처 식당', sub: '1km 안 예약', color: AppColors.mint, onTap: () => onGoToTab?.call(2))),
                const SizedBox(width: 10),
                Expanded(
                  child: _QuickTile(
                    emoji: '⚖️',
                    title: '인바디',
                    sub: '다시 재기',
                    color: const Color(0xFFEDE9FF),
                    onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const BodyInputScreen())),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 18),

            if (p != null) BodySummaryCard(profile: p, compact: true),
            const SizedBox(height: 18),

            // ───── 오늘의 균형 ─────
            _SectionCard(
              title: '오늘의 균형',
              trailing: t == null
                  ? null
                  : _Pill(text: '${total.kcal.round()} / ${t.kcal.round()} kcal', color: AppColors.peach, textColor: AppColors.primaryDark),
              child: t == null
                  ? Text('인바디를 먼저 적으면 목표가 생겨요', style: Theme.of(context).textTheme.bodySmall)
                  : Column(
                      children: [
                        NutrientGauge(label: '에너지', value: total.kcal, target: t.kcal, unit: 'kcal', color: AppColors.primary),
                        NutrientGauge(label: '탄수화물', value: total.carbG, target: t.carbG, unit: 'g', color: AppColors.sun),
                        NutrientGauge(label: '단백질', value: total.proteinG, target: t.proteinG, unit: 'g', color: AppColors.sky),
                        NutrientGauge(label: '지방', value: total.fatG, target: t.fatG, unit: 'g', color: AppColors.green),
                        NutrientGauge(label: '나트륨', value: total.sodiumMg, target: t.sodiumMg, unit: 'mg', color: AppColors.plum, lessIsBetter: true),
                      ],
                    ),
            ),
            const SizedBox(height: 18),

            // ───── 끼니 기록 ─────
            Padding(
              padding: const EdgeInsets.only(left: 4, bottom: 10),
              child: Text('오늘 뭐 먹었어?', style: Theme.of(context).textTheme.titleLarge),
            ),
            ...MealType.values.map((m) => Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: _MealCard(meal: m),
                )),
          ],
        ),
      ),
    );
  }
}

/// 알록달록 바로가기 타일
class _QuickTile extends StatelessWidget {
  final String emoji, title, sub;
  final Color color;
  final VoidCallback onTap;
  const _QuickTile({required this.emoji, required this.title, required this.sub, required this.color, required this.onTap});

  @override
  Widget build(BuildContext context) => InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(20),
        child: Container(
          padding: const EdgeInsets.fromLTRB(14, 14, 14, 12),
          decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(20)),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(emoji, style: const TextStyle(fontSize: 26)),
              const SizedBox(height: 10),
              Text(title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 15, color: AppColors.ink)),
              Text(sub, style: const TextStyle(fontSize: 11, color: AppColors.muted, fontWeight: FontWeight.w600)),
            ],
          ),
        ),
      );
}

/// 흰색 둥근 카드 + 제목
class _SectionCard extends StatelessWidget {
  final String title;
  final Widget? trailing;
  final Widget child;
  const _SectionCard({required this.title, required this.child, this.trailing});

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.fromLTRB(18, 16, 18, 12),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(22), boxShadow: AppColors.cardShadow),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Text(title, style: Theme.of(context).textTheme.titleLarge),
                const Spacer(),
                if (trailing != null) trailing!,
              ],
            ),
            const SizedBox(height: 6),
            child,
          ],
        ),
      );
}

class _Pill extends StatelessWidget {
  final String text;
  final Color color, textColor;
  const _Pill({required this.text, required this.color, required this.textColor});

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
        decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(999)),
        child: Text(text, style: TextStyle(color: textColor, fontWeight: FontWeight.w800, fontSize: 12)),
      );
}

class _MealCard extends StatelessWidget {
  final MealType meal;
  const _MealCard({required this.meal});

  static const _tileColors = {
    MealType.breakfast: Color(0xFFFFF1CC),
    MealType.lunch: Color(0xFFFFE1D6),
    MealType.dinner: Color(0xFFE3EEFF),
    MealType.snack: Color(0xFFEDE9FF),
  };

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final entries = app.entriesFor(meal);
    final kcal = entries.fold<double>(0, (s, e) => s + e.kcal);

    return Container(
      padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(22), boxShadow: AppColors.cardShadow),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(color: _tileColors[meal], borderRadius: BorderRadius.circular(14)),
                alignment: Alignment.center,
                child: Text(meal.emoji, style: const TextStyle(fontSize: 22)),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(meal.label, style: Theme.of(context).textTheme.titleMedium),
                    Text(
                      entries.isEmpty ? '아직 기록이 없어요' : '${entries.length}개 · ${kcal.round()} kcal',
                      style: Theme.of(context).textTheme.bodySmall,
                    ),
                  ],
                ),
              ),
              TextButton.icon(
                onPressed: () async {
                  final picked = await showFoodPicker(context);
                  if (picked != null && context.mounted) {
                    await context.read<AppState>().addEntry(meal, picked.food, picked.servings);
                  }
                },
                style: TextButton.styleFrom(
                  backgroundColor: AppColors.peach,
                  foregroundColor: AppColors.primaryDark,
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(999)),
                  textStyle: const TextStyle(fontWeight: FontWeight.w900, fontSize: 13),
                ),
                icon: const Icon(Icons.add, size: 18),
                label: const Text('추가'),
              ),
            ],
          ),
          if (entries.isNotEmpty) ...[
            const SizedBox(height: 8),
            const Divider(height: 1),
            ...entries.map((e) => Padding(
                  padding: const EdgeInsets.only(top: 10),
                  child: Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(e.food.name, style: const TextStyle(fontWeight: FontWeight.w700)),
                            Text(
                              '${_servingText(e.servings)} · ${e.kcal.round()}kcal · 단백질 ${e.proteinG.round()}g',
                              style: Theme.of(context).textTheme.bodySmall,
                            ),
                          ],
                        ),
                      ),
                      IconButton(
                        icon: const Icon(Icons.close, size: 18, color: AppColors.muted),
                        onPressed: () => context.read<AppState>().removeEntry(e.id),
                      ),
                    ],
                  ),
                )),
          ],
        ],
      ),
    );
  }

  String _servingText(double s) {
    if (s == 0.5) return '반 인분';
    if (s == 1) return '1인분';
    if (s == 1.5) return '1.5인분';
    return '${s.round()}인분';
  }
}
