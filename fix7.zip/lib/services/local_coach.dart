import '../config/app_keys.dart';
import '../data/food_database.dart';
import '../models/nutrition.dart';
import '../state/app_state.dart';
import 'kakao_local_service.dart';

/// 앱 자체 추천 엔진 (돈도, 인터넷도 필요 없음)
///
/// 하는 일: 오늘 "남은 영양소"를 계산하고, 음식 목록 하나하나에
/// "이걸 먹으면 남은 걸 얼마나 잘 채우나" 점수를 매겨서 상위 3개를 골라요.
/// 질문에 "단백질", "편의점", "가볍게" 같은 말이 있으면 그에 맞게 점수를 바꿔요.
class LocalCoach {
  // 백마 학원가 기준점 (식당 탭을 아직 안 열었을 때 씀)
  static const _fallbackLat = 37.6595;
  static const _fallbackLng = 126.7855;

  /// 학생 질문에 대한 답 만들기
  static Future<String> reply(String question, AppState app) async {
    // 근처 식당 목록이 아직 없으면 지금 찾아와요 (식당 탭을 안 열었을 때)
    if (app.nearbyPlaces.isEmpty && AppKeys.kakaoReady) {
      try {
        final lat = app.lastLat ?? _fallbackLat;
        final lng = app.lastLng ?? _fallbackLng;
        final places = await KakaoLocalService().searchNearby(lat: lat, lng: lng);
        app.setNearbyPlaces(places, lat, lng);
      } catch (_) {
        // 못 찾아도 음식 추천은 계속
      }
    }

    final q = question.replaceAll(' ', '');
    final t = app.targets;
    final total = app.todayTotals;

    if (t == null) {
      return '인바디 결과를 먼저 적어주면 몸에 맞춰서 골라줄게. "오늘" 탭 오른쪽 위 체중계 아이콘을 눌러봐.';
    }

    // ───── 1) 오늘 남은 양 ─────
    final remainKcal = (t.kcal - total.kcal).clamp(0, t.kcal);
    final remainProtein = (t.proteinG - total.proteinG).clamp(0, t.proteinG);
    final remainCarb = (t.carbG - total.carbG).clamp(0, t.carbG);
    final remainFat = (t.fatG - total.fatG).clamp(0, t.fatG);
    final sodiumLeft = (t.sodiumMg - total.sodiumMg).clamp(0, t.sodiumMg);

    // ───── 2) 질문에서 힌트 찾기 ─────
    String? category; // 특정 카테고리만 보고 싶을 때
    var proteinWeight = 1.0;
    var lightMode = false; // 가볍게
    var heavyMode = false; // 든든하게
    var wantSnack = false;

    if (q.contains('편의점')) category = '편의점';
    if (q.contains('샐러드') || q.contains('포케')) category = '샐러드';
    if (q.contains('분식') || q.contains('떡볶이')) category = '분식';
    if (q.contains('면') || q.contains('국수') || q.contains('라면')) category = '면';
    if (q.contains('밥') || q.contains('덮밥') || q.contains('한식')) category = '밥';
    if (q.contains('햄버거') || q.contains('피자') || q.contains('치킨') || q.contains('패스트')) category = '패스트푸드';
    if (q.contains('단백질') || q.contains('근육') || q.contains('운동')) proteinWeight = 3.0;
    if (q.contains('가볍') || q.contains('간단') || q.contains('다이어트') || q.contains('살')) lightMode = true;
    if (q.contains('든든') || q.contains('배고') || q.contains('많이')) heavyMode = true;
    if (q.contains('간식') || q.contains('디저트') || q.contains('달달')) wantSnack = true;
    final budgetMode = q.contains('천원') || q.contains('싸') || q.contains('저렴') || q.contains('돈없');

    // 성장기 안전장치: "살 빼기" 질문이어도 굶는 추천은 안 해요
    final growthNote = lightMode
        ? '\n\n참고로 성장기엔 끼니를 빼는 것보다 "튀김·단 음료를 다른 걸로 바꾸는" 게 훨씬 좋아. 그래서 가볍지만 영양은 있는 걸로 골랐어.'
        : '';

    // ───── 3) 음식마다 점수 매기기 ─────
    final scored = <({FoodItem food, double score, String why})>[];

    for (final f in FoodDatabase.all) {
      // 음료·간식은 간식을 원할 때만
      if (!wantSnack && (f.category == '음료' || f.category == '간식')) continue;
      if (wantSnack && !(f.category == '간식' || f.category == '편의점' || f.category == '음료')) continue;
      if (category != null && f.category != category) continue;
      if (budgetMode && !(f.category == '편의점' || f.category == '분식' || f.category == '면')) continue;
      if (f.kcal < 60) continue; // 물, 제로콜라 같은 건 추천 대상에서 제외

      // "남은 양을 얼마나 채우나" (0~1). 남은 것보다 너무 많이 넘치면 감점
      double fill(double foodAmt, double remain, double target) {
        if (target <= 0) return 0;
        final useful = foodAmt < remain ? foodAmt : remain;
        final over = foodAmt - remain;
        final penalty = over > 0 ? (over / target) : 0;
        return (useful / target) - penalty * 0.7;
      }

      var score = 0.0;
      score += fill(f.kcal, remainKcal.toDouble(), t.kcal) * 1.0;
      score += fill(f.proteinG, remainProtein.toDouble(), t.proteinG) * 1.6 * proteinWeight;
      score += fill(f.carbG, remainCarb.toDouble(), t.carbG) * 0.8;
      score += fill(f.fatG, remainFat.toDouble(), t.fatG) * 0.5;

      // 나트륨: 남은 여유보다 많이 짜면 감점
      if (f.sodiumMg > sodiumLeft) score -= (f.sodiumMg - sodiumLeft) / t.sodiumMg * 1.5;

      // 몸 상태에 따른 보정 (인바디 리포트의 "챙기면 좋은 것")
      final focus = app.insight?.focusNutrients ?? const <String>[];
      if (focus.contains('단백질') && f.proteinG >= 20) score += 0.25;
      if (focus.contains('채소·식이섬유') && (f.category == '샐러드' || f.name.contains('비빔'))) score += 0.25;
      if (focus.contains('채소·식이섬유') && (f.category == '패스트푸드' || f.name.contains('튀김'))) score -= 0.2;
      if (focus.contains('에너지(탄수화물)') && f.kcal >= 500) score += 0.2;

      // 가볍게 / 든든하게
      if (lightMode) score += (600 - f.kcal) / 1000; // 칼로리 낮을수록 가산
      if (heavyMode) score += (f.kcal - 400) / 1000;

      scored.add((food: f, score: score, why: _why(f, remainProtein.toDouble(), remainKcal.toDouble(), sodiumLeft.toDouble())));
    }

    if (scored.isEmpty) {
      return '그 조건으로는 목록에서 못 찾았어. "편의점", "단백질", "가볍게" 같은 말로 물어봐줘.';
    }

    scored.sort((a, b) => b.score.compareTo(a.score));
    final top = scored.take(3).toList();

    // ───── 4) 답 문장 만들기 ─────
    final hour = DateTime.now().hour;
    final meal = hour < 10
        ? '아침'
        : hour < 15
            ? '점심'
            : hour < 21
                ? '저녁'
                : '늦은 저녁';

    final status = total.kcal == 0
        ? '아직 오늘 기록이 없어서 하루 목표 기준으로 골랐어.'
        : '오늘 에너지 ${remainKcal.round()}kcal, 단백질 ${remainProtein.round()}g 정도 더 채우면 딱 좋아.';

    final buf = StringBuffer();
    buf.writeln('지금은 $meal 시간이지? $status\n');
    for (var i = 0; i < top.length; i++) {
      final f = top[i].food;
      buf.writeln('${i + 1}. ${f.name} (${f.kcal.round()}kcal · 단백질 ${f.proteinG.round()}g)');
      buf.writeln('   → ${top[i].why}');
      final stores = _nearbyStoresFor(f, app.nearbyPlaces);
      if (stores.isNotEmpty) {
        buf.writeln('   📍 근처: ${stores.join(', ')}');
      }
    }
    buf.write(growthNote);
    if (app.nearbyPlaces.isNotEmpty) {
      buf.write('\n\n가게 이름을 "식당 찾기" 탭 검색창에 넣으면 바로 예약할 수 있어.');
    }
    buf.write('\n· MEAL:ON 자체 추천이에요. "오늘" 탭에 먹은 걸 기록할수록 더 정확해져요.');
    return buf.toString();
  }

  /// 음식 하나에 어울리는 "근처 가게" 최대 2곳 (가까운 순)
  static List<String> _nearbyStoresFor(FoodItem f, List<Place> places) {
    final keys = _placeKeywords(f);
    if (keys.isEmpty || places.isEmpty) return const [];
    final hits = places.where((p) {
      final text = '${p.name} ${p.category}'.toLowerCase();
      return keys.any((k) => text.contains(k));
    }).toList()
      ..sort((a, b) => a.distanceM.compareTo(b.distanceM));
    return hits.take(2).map((p) => '${p.name} (${p.distanceText})').toList();
  }

  /// 음식 이름 → 카카오 가게 분류/이름에서 찾을 단어들
  static List<String> _placeKeywords(FoodItem f) {
    final n = f.name;
    if (n.contains('덮밥') || n.contains('규동')) return ['덮밥', '규동', '일식', '한식'];
    if (n.contains('찌개') || n.contains('백반')) return ['찌개', '백반', '국밥', '한식'];
    if (n.contains('비빔밥')) return ['비빔밥', '한식'];
    if (n.contains('돈까스')) return ['돈까스', '돈가스', '일식'];
    if (n.contains('김밥') || n.contains('삼각김밥')) return ['김밥', '분식'];
    if (n.contains('카레')) return ['카레', '인도', '일식'];
    if (n.contains('볶음밥') || n.contains('짜장') || n.contains('짬뽕')) return ['중식', '중국', '짜장', '짬뽕'];
    if (n.contains('국수') || n.contains('칼국수')) return ['국수', '칼국수', '한식'];
    if (n.contains('냉면')) return ['냉면'];
    if (n.contains('우동')) return ['우동', '일식'];
    if (n.contains('라면') || n.contains('라볶이') || n.contains('떡볶이') || n.contains('순대') || n.contains('튀김') || n.contains('어묵') || n.contains('만두')) {
      return ['분식', '떡볶이', '만두'];
    }
    if (n.contains('파스타')) return ['파스타', '양식', '이탈리'];
    if (n.contains('햄버거') || n.contains('감자튀김')) return ['햄버거', '버거', '패스트푸드'];
    if (n.contains('치킨')) return ['치킨'];
    if (n.contains('피자')) return ['피자'];
    if (n.contains('핫도그')) return ['핫도그', '패스트푸드'];
    if (n.contains('샐러드') || n.contains('포케') || n.contains('요거트')) return ['샐러드', '포케', '샌드위치'];
    if (n.contains('샌드위치')) return ['샌드위치', '카페', '베이커리'];
    if (f.category == '편의점') return const []; // 편의점은 음식점 검색에 안 잡혀요
    return const [];
  }

  /// 한 줄 이유
  static String _why(FoodItem f, double remainProtein, double remainKcal, double sodiumLeft) {
    final reasons = <String>[];
    if (f.proteinG >= 25) {
      reasons.add('단백질을 한 번에 많이 채워줘');
    } else if (f.proteinG >= 15) {
      reasons.add('단백질이 적당히 들어 있어');
    }
    if (f.kcal <= 450) reasons.add('가볍게 먹기 좋아');
    if (f.kcal >= 650 && remainKcal >= 700) reasons.add('든든하게 채워줘');
    if (f.sodiumMg <= 700) {
      reasons.add('짜지 않아');
    } else if (f.sodiumMg > sodiumLeft) {
      reasons.add('대신 국물은 남기면 좋아');
    }
    if (f.category == '샐러드') reasons.add('채소도 같이 챙겨져');
    if (f.category == '편의점') reasons.add('편의점에서 바로 살 수 있어');
    if (reasons.isEmpty) reasons.add('오늘 남은 영양을 골고루 채워줘');
    return reasons.take(2).join(', ');
  }
}
