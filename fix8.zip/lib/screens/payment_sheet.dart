import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../services/payment_service.dart';
import '../theme/app_theme.dart';

/// ═══════════════════════════════════════════════════════════
///  카드 결제 창 (아래에서 올라오는 시트)
///  성공하면 PayResult를 돌려주고, 취소하면 null을 돌려줘요.
/// ═══════════════════════════════════════════════════════════
Future<PayResult?> showPaymentSheet(
  BuildContext context, {
  required int amount,
  required String title, // 예: "백마곱창 예약금"
}) {
  return showModalBottomSheet<PayResult>(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    builder: (_) => _PaymentSheet(amount: amount, title: title),
  );
}

class _PaymentSheet extends StatefulWidget {
  final int amount;
  final String title;
  const _PaymentSheet({required this.amount, required this.title});

  @override
  State<_PaymentSheet> createState() => _PaymentSheetState();
}

class _PaymentSheetState extends State<_PaymentSheet> {
  final _card = TextEditingController();
  final _expiry = TextEditingController();
  final _cvc = TextEditingController();
  bool _paying = false;
  String? _error;

  @override
  void dispose() {
    _card.dispose();
    _expiry.dispose();
    _cvc.dispose();
    super.dispose();
  }

  String _won(int n) {
    final s = n.toString();
    final buf = StringBuffer();
    for (int i = 0; i < s.length; i++) {
      buf.write(s[i]);
      final left = s.length - i - 1;
      if (left > 0 && left % 3 == 0) buf.write(',');
    }
    return '${buf.toString()}원';
  }

  Future<void> _pay() async {
    setState(() {
      _paying = true;
      _error = null;
    });
    try {
      final result = await PaymentService.pay(
        amount: widget.amount,
        cardNumber: _card.text.replaceAll(' ', ''),
        expiry: _expiry.text,
        cvc: _cvc.text,
      );
      if (!mounted) return;
      Navigator.of(context).pop(result); // 성공! 결과를 들고 창 닫기
    } on PayError catch (e) {
      if (!mounted) return;
      setState(() {
        _paying = false;
        _error = e.message;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final bottom = MediaQuery.of(context).viewInsets.bottom;

    return Padding(
      padding: EdgeInsets.only(bottom: bottom),
      child: Container(
        decoration: const BoxDecoration(
          color: AppColors.paper,
          borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
        ),
        padding: const EdgeInsets.fromLTRB(20, 12, 20, 24),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(color: AppColors.line, borderRadius: BorderRadius.circular(2)),
                ),
              ),
              const SizedBox(height: 16),

              // ── 제목 + 연습모드 배지 ──
              Row(
                children: [
                  Expanded(child: Text('카드 결제', style: Theme.of(context).textTheme.titleLarge)),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                    decoration: BoxDecoration(
                      color: AppColors.sun.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(999),
                    ),
                    child: const Text('연습 모드', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w800, color: Color(0xFF8A6D00))),
                  ),
                ],
              ),
              const SizedBox(height: 4),
              Text('실제 돈은 나가지 않아요. 테스트 카드: 4242 4242 4242 4242', style: Theme.of(context).textTheme.bodySmall),
              const SizedBox(height: 16),

              // ── 결제 금액 카드 ──
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(18),
                  boxShadow: AppColors.cardShadow,
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(widget.title, style: Theme.of(context).textTheme.bodyMedium),
                    const SizedBox(height: 4),
                    Text(_won(widget.amount),
                        style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w900, color: AppColors.primary)),
                  ],
                ),
              ),
              const SizedBox(height: 16),

              // ── 카드번호 ──
              TextField(
                controller: _card,
                keyboardType: TextInputType.number,
                inputFormatters: [
                  FilteringTextInputFormatter.digitsOnly,
                  LengthLimitingTextInputFormatter(16),
                  _CardNumberFormatter(), // 4자리마다 자동 띄어쓰기
                ],
                decoration: const InputDecoration(
                  labelText: '카드번호',
                  hintText: '0000 0000 0000 0000',
                  prefixIcon: Icon(Icons.credit_card),
                ),
              ),
              const SizedBox(height: 12),

              // ── 유효기간 + CVC ──
              Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _expiry,
                      keyboardType: TextInputType.number,
                      inputFormatters: [
                        FilteringTextInputFormatter.digitsOnly,
                        LengthLimitingTextInputFormatter(4),
                        _ExpiryFormatter(), // MM/YY 자동 슬래시
                      ],
                      decoration: const InputDecoration(labelText: '유효기간', hintText: 'MM/YY'),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: TextField(
                      controller: _cvc,
                      keyboardType: TextInputType.number,
                      obscureText: true, // 비밀번호처럼 가리기
                      inputFormatters: [
                        FilteringTextInputFormatter.digitsOnly,
                        LengthLimitingTextInputFormatter(3),
                      ],
                      decoration: const InputDecoration(labelText: 'CVC', hintText: '카드 뒷면 3자리'),
                    ),
                  ),
                ],
              ),

              // ── 에러 메시지 ──
              if (_error != null) ...[
                const SizedBox(height: 10),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: AppColors.primary.withOpacity(0.08),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(_error!, style: const TextStyle(color: AppColors.primaryDark, fontSize: 13, fontWeight: FontWeight.w600)),
                ),
              ],
              const SizedBox(height: 16),

              // ── 결제 버튼 ──
              FilledButton(
                onPressed: _paying ? null : _pay,
                child: _paying
                    ? const Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)),
                          SizedBox(width: 10),
                          Text('카드사에 물어보는 중...'),
                        ],
                      )
                    : Text('${_won(widget.amount)} 결제하기'),
              ),
              const SizedBox(height: 8),
              Center(
                child: Text('결제하면 예약이 확정 요청돼요 · 취소 시 전액 환불',
                    style: Theme.of(context).textTheme.bodySmall),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// 카드번호를 "4242 4242 4242 4242" 모양으로 자동으로 띄어써주는 도우미
class _CardNumberFormatter extends TextInputFormatter {
  @override
  TextEditingValue formatEditUpdate(TextEditingValue oldValue, TextEditingValue newValue) {
    final digits = newValue.text.replaceAll(' ', '');
    final buf = StringBuffer();
    for (int i = 0; i < digits.length; i++) {
      buf.write(digits[i]);
      if ((i + 1) % 4 == 0 && i + 1 != digits.length) buf.write(' ');
    }
    final text = buf.toString();
    return TextEditingValue(text: text, selection: TextSelection.collapsed(offset: text.length));
  }
}

/// 유효기간을 "12/28" 모양으로 자동으로 슬래시 넣어주는 도우미
class _ExpiryFormatter extends TextInputFormatter {
  @override
  TextEditingValue formatEditUpdate(TextEditingValue oldValue, TextEditingValue newValue) {
    final digits = newValue.text.replaceAll('/', '');
    String text = digits;
    if (digits.length >= 3) {
      text = '${digits.substring(0, 2)}/${digits.substring(2)}';
    }
    return TextEditingValue(text: text, selection: TextSelection.collapsed(offset: text.length));
  }
}
