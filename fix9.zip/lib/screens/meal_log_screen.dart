import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/nutrition.dart';
import '../state/app_state.dart';
import '../theme/app_theme.dart';
import '../widgets/body_summary_card.dart';
import '../widgets/nutrient_gauge.dart';
import 'body_input_screen.dart';
import 'food_picker_sheet.dart';

/// "홈" 탭 (Grab 스타일)
/// 위에서부터: 초록 그라데이션 헤더(검색) → 서비스 타일 격자 → 환영 배너 → 혜택 쿠폰 → 오늘의 균형 → 끼니 기록
class MealLogScreen extends StatelessWidget {
  final void Function(int tabIndex)? onGoToTab;
  const MealLogScreen({super.key, this.onGoToTab});

  void _openBody(BuildContext context) =>
      Navigator.of(context).push(MaterialPageRoute(builder: (_) => const BodyInputScreen()));

  /// 타일에서 바로 끼니 기록: 지금 시간에 맞는 끼니(아침/점심/저녁)에 넣어줘요
  Future<void> _quickLog(BuildContext context) async {
    final h = DateTime.now().hour;
    final meal = h < 11 ? MealType.breakfast : (h < 16 ? MealType.lunch : MealType.dinner);
    final picked = await showFoodPicker(context);
    if (picked != null && context.mounted) {
      await context.read<AppState>().addEntry(meal, picked.food, picked.servings);
    }
  }

  void _soon(BuildContext context, String what) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$what은(는) 곧 열려요! 🚧')));

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final p = app.profile;
    final t = app.targets;
    final total = app.todayTotals;
    final topPad = MediaQuery.of(context).padding.top; // 폰 상단 노치 높이

    return Scaffold(
      body: ListView(
        padding: EdgeInsets.zero, // 헤더가 맨 위까지 꽉 차게
        children: [
          // ═══════ 1) 초록 그라데이션 헤더 + 검색창 ═══════
          Container(
            padding: EdgeInsets.fromLTRB(16, topPad + 18, 16, 22),
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [AppColors.teal, AppColors.primary],
              ),
              borderRadius: BorderRadius.vertical(bottom: Radius.circular(26)),
            ),
            child: Row(
              children: [
                // 예약번호 스캔 아이콘 (내 예약으로 이동)
                _RoundIcon(icon: Icons.qr_code_scanner_rounded, onTap: () => onGoToTab?.call(3)),
                const SizedBox(width: 10),
                // 검색창 (누르면 식당 찾기 탭으로)
                Expanded(
                  child: InkWell(
                    onTap: () => onGoToTab?.call(2),
                    borderRadius: BorderRadius.circular(999),
                    child: Container(
                      height: 50,
                      padding: const EdgeInsets.symmetric(horizontal: 18),
                      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(999)),
                      child: const Row(
                        children: [
                          Icon(Icons.search_rounded, color: AppColors.muted, size: 26),
                          SizedBox(width: 10),
                          Text('메뉴, 식당 검색', style: TextStyle(color: AppColors.muted, fontSize: 16)),
                        ],
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                // 프로필 동그라미 (인바디 다시 적기)
                InkWell(
                  onTap: () => _openBody(context),
                  borderRadius: BorderRadius.circular(999),
                  child: Container(
                    width: 46,
                    height: 46,
                    decoration: BoxDecoration(color: Colors.white.withOpacity(0.85), shape: BoxShape.circle),
                    alignment: Alignment.center,
                    child: p == null
                        ? const Icon(Icons.person_rounded, color: AppColors.primary, size: 28)
                        : Text(p.nickname.characters.first,
                            style: const TextStyle(color: AppColors.primary, fontWeight: FontWeight.w900, fontSize: 18)),
                  ),
                ),
              ],
            ),
          ),

          // ═══════ 2) 서비스 타일 격자 (3개 + 4개) ═══════
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 18, 16, 0),
            child: Column(
              children: [
                Row(
                  children: [
                    Expanded(child: _ServiceTile(emoji: '✨', label: 'AI 추천', big: true, onTap: () => onGoToTab?.call(1))),
                    const SizedBox(width: 10),
                    Expanded(child: _ServiceTile(emoji: '🍱', label: '식당 찾기', big: true, onTap: () => onGoToTab?.call(2))),
                    const SizedBox(width: 10),
                    Expanded(child: _ServiceTile(emoji: '⚖️', label: '인바디', big: true, onTap: () => _openBody(context))),
                  ],
                ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    Expanded(child: _ServiceTile(emoji: '📝', label: '끼니 기록', onTap: () => _quickLog(context))),
                    const SizedBox(width: 10),
                    Expanded(child: _ServiceTile(emoji: '🎫', label: '내 예약', onTap: () => onGoToTab?.call(3))),
                    const SizedBox(width: 10),
                    Expanded(child: _ServiceTile(emoji: '🛵', label: '주문', onTap: () => _soon(context, '메뉴 주문'))),
                    const SizedBox(width: 10),
                    Expanded(child: _ServiceTile(emoji: '🎁', label: '쿠폰함', onTap: () => _soon(context, '쿠폰함'))),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 18),

          // ═══════ 3) 환영 배너 ═══════
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: _WelcomeBanner(nickname: p?.nickname, onTap: () => onGoToTab?.call(1)),
          ),
          const SizedBox(height: 18),

          // ═══════ 4) 혜택 쿠폰 띠 ═══════
          Container(
            padding: const EdgeInsets.fromLTRB(16, 20, 0, 20),
            decoration: const BoxDecoration(
              gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [AppColors.mint, AppColors.paper]),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('웰컴 혜택 받기', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontSize: 22)),
                const SizedBox(height: 2),
                Text('백마 학원가 제휴 식당 전용', style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: AppColors.muted)),
                const SizedBox(height: 14),
                SizedBox(
                  height: 96,
                  child: ListView(
                    scrollDirection: Axis.horizontal,
                    children: [
                      _CouponCard(big: '1,000원', small: '첫 예약 할인', onTap: () => _soon(context, '쿠폰함')),
                      _CouponCard(big: '음료 1잔', small: '재방문 3회 달성', onTap: () => _soon(context, '쿠폰함')),
                      _CouponCard(big: '10%', small: '오후 2~5시 방문', onTap: () => _soon(context, '쿠폰함')),
                      _CouponCard(big: '곱빼기', small: '단백질 부족한 날', onTap: () => _soon(context, '쿠폰함')),
                      const SizedBox(width: 16),
                    ],
                  ),
                ),
              ],
            ),
          ),

          // ═══════ 5) 아래는 원래 있던 몸 리포트 + 균형 + 끼니 기록 ═══════
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 32),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (p != null) BodySummaryCard(profile: p, compact: true),
                if (p != null) const SizedBox(height: 18),

                _SectionCard(
                  title: '오늘의 균형',
                  trailing: t == null
                      ? null
                      : _Pill(text: '${total.kcal.round()} / ${t.kcal.round()} kcal', color: AppColors.mint, textColor: AppColors.primaryDark),
                  child: t == null
                      ? Text('인바디를 먼저 적으면 목표가 생겨요', style: Theme.of(context).textTheme.bodySmall)
                      : Column(
                          children: [
                            NutrientGauge(label: '에너지', value: total.kcal, target: t.kcal, unit: 'kcal', color: AppColors.primary),
                            NutrientGauge(label: '탄수화물', value: total.carbG, target: t.carbG, unit: 'g', color: AppColors.sun),
                            NutrientGauge(label: '단백질', value: total.proteinG, target: t.proteinG, unit: 'g', color: AppColors.sky),
                            NutrientGauge(label: '지방', value: total.fatG, target: t.fatG, unit: 'g', color: AppColors.green),
                            NutrientGauge(label: '나트륨', value: total.sodiumMg, target: t.sodiumMg, unit: 'mg', color: AppColors.plum, lessIsBetter: true),
                          ],
                        ),
                ),
                const SizedBox(height: 18),

                Padding(
                  padding: const EdgeInsets.only(left: 4, bottom: 10),
                  child: Text('오늘 뭐 먹었어?', style: Theme.of(context).textTheme.titleLarge),
                ),
                ...MealType.values.map((m) => Padding(
                      padding: const EdgeInsets.only(bottom: 12),
                      child: _MealCard(meal: m),
                    )),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

/// 헤더 양옆 동그란 반투명 아이콘 버튼
class _RoundIcon extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  const _RoundIcon({required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) => InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(999),
        child: Container(
          width: 46,
          height: 46,
          decoration: BoxDecoration(color: Colors.white.withOpacity(0.28), shape: BoxShape.circle),
          child: Icon(icon, color: Colors.white, size: 24),
        ),
      );
}

/// Grab처럼 연한 하늘색 배경 + 큰 그림 + 글자 타일
class _ServiceTile extends StatelessWidget {
  final String emoji, label;
  final bool big; // 윗줄 3개는 크게, 아랫줄 4개는 작게
  final VoidCallback onTap;
  const _ServiceTile({required this.emoji, required this.label, required this.onTap, this.big = false});

  @override
  Widget build(BuildContext context) => InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(20),
        child: Container(
          height: big ? 118 : 108,
          decoration: BoxDecoration(color: AppColors.tile, borderRadius: BorderRadius.circular(20)),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(emoji, style: TextStyle(fontSize: big ? 44 : 36)),
              const SizedBox(height: 8),
              Text(label, style: TextStyle(fontWeight: FontWeight.w800, fontSize: big ? 15 : 13, color: AppColors.ink)),
            ],
          ),
        ),
      );
}

/// 초록 배경 환영 배너: 노란 팻말 + 인사말 + 음식 이모지 일러스트
class _WelcomeBanner extends StatelessWidget {
  final String? nickname;
  final VoidCallback onTap;
  const _WelcomeBanner({required this.nickname, required this.onTap});

  @override
  Widget build(BuildContext context) => InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(24),
        child: Container(
          height: 170,
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Color(0xFFD7F5E3), Color(0xFF9EDFB8)],
            ),
            borderRadius: BorderRadius.circular(24),
          ),
          child: Stack(
            children: [
              // 뒤쪽 큰 원 (도시 실루엣 느낌)
              Positioned(right: -30, bottom: -50, child: _Blob(size: 190, color: AppColors.primary.withOpacity(0.18))),
              Positioned(right: 90, top: -40, child: _Blob(size: 120, color: AppColors.primary.withOpacity(0.12))),
              // 오른쪽 음식 일러스트 (이모지)
              const Positioned(right: 22, top: 22, child: Text('🥗', style: TextStyle(fontSize: 64))),
              const Positioned(right: 82, bottom: 14, child: Text('🍙', style: TextStyle(fontSize: 40))),
              const Positioned(right: 12, bottom: 22, child: Text('🥤', style: TextStyle(fontSize: 34))),
              const Positioned(right: 130, top: 16, child: Text('💚', style: TextStyle(fontSize: 18))),
              const Positioned(right: 110, top: 44, child: Text('💚', style: TextStyle(fontSize: 12))),
              // 왼쪽 노란 팻말 + 글
              Positioned(
                left: 18,
                top: 24,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                      decoration: BoxDecoration(
                        color: const Color(0xFFFFF3A6),
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: const Color(0xFFE6D25A), width: 2),
                      ),
                      child: Text(
                        nickname == null ? '환영해요!' : '$nickname, 환영해요!',
                        style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 17, color: AppColors.primaryDark),
                      ),
                    ),
                    const SizedBox(height: 14),
                    const Text('나에게 맞는 한 끼를 켜다', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18, color: AppColors.ink)),
                    const SizedBox(height: 4),
                    const Text('AI 추천 받으러 가기 →', style: TextStyle(fontSize: 13, color: AppColors.primaryDark, fontWeight: FontWeight.w700)),
                  ],
                ),
              ),
            ],
          ),
        ),
      );
}

class _Blob extends StatelessWidget {
  final double size;
  final Color color;
  const _Blob({required this.size, required this.color});
  @override
  Widget build(BuildContext context) =>
      Container(width: size, height: size, decoration: BoxDecoration(color: color, shape: BoxShape.circle));
}

/// 노란 쿠폰 카드 (가로로 넘겨보는 것)
class _CouponCard extends StatelessWidget {
  final String big, small;
  final VoidCallback onTap;
  const _CouponCard({required this.big, required this.small, required this.onTap});

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(right: 10),
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(18),
          child: Container(
            width: 150,
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(color: const Color(0xFFFFF0A3), borderRadius: BorderRadius.circular(18)),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(big, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 22, color: AppColors.ink)),
                const SizedBox(height: 4),
                Text(small, style: const TextStyle(fontSize: 13, color: AppColors.ink, fontWeight: FontWeight.w600)),
              ],
            ),
          ),
        ),
      );
}
/// 흰색 둥근 카드 + 제목
class _SectionCard extends StatelessWidget {
  final String title;
  final Widget? trailing;
  final Widget child;
  const _SectionCard({required this.title, required this.child, this.trailing});

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.fromLTRB(18, 16, 18, 12),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(22), boxShadow: AppColors.cardShadow),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Text(title, style: Theme.of(context).textTheme.titleLarge),
                const Spacer(),
                if (trailing != null) trailing!,
              ],
            ),
            const SizedBox(height: 6),
            child,
          ],
        ),
      );
}

class _Pill extends StatelessWidget {
  final String text;
  final Color color, textColor;
  const _Pill({required this.text, required this.color, required this.textColor});

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
        decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(999)),
        child: Text(text, style: TextStyle(color: textColor, fontWeight: FontWeight.w800, fontSize: 12)),
      );
}

class _MealCard extends StatelessWidget {
  final MealType meal;
  const _MealCard({required this.meal});

  static const _tileColors = {
    MealType.breakfast: Color(0xFFFFF1CC),
    MealType.lunch: Color(0xFFFFE1D6),
    MealType.dinner: Color(0xFFE3EEFF),
    MealType.snack: Color(0xFFEDE9FF),
  };

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final entries = app.entriesFor(meal);
    final kcal = entries.fold<double>(0, (s, e) => s + e.kcal);

    return Container(
      padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(22), boxShadow: AppColors.cardShadow),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(color: _tileColors[meal], borderRadius: BorderRadius.circular(14)),
                alignment: Alignment.center,
                child: Text(meal.emoji, style: const TextStyle(fontSize: 22)),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(meal.label, style: Theme.of(context).textTheme.titleMedium),
                    Text(
                      entries.isEmpty ? '아직 기록이 없어요' : '${entries.length}개 · ${kcal.round()} kcal',
                      style: Theme.of(context).textTheme.bodySmall,
                    ),
                  ],
                ),
              ),
              TextButton.icon(
                onPressed: () async {
                  final picked = await showFoodPicker(context);
                  if (picked != null && context.mounted) {
                    await context.read<AppState>().addEntry(meal, picked.food, picked.servings);
                  }
                },
                style: TextButton.styleFrom(
                  backgroundColor: AppColors.peach,
                  foregroundColor: AppColors.primaryDark,
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(999)),
                  textStyle: const TextStyle(fontWeight: FontWeight.w900, fontSize: 13),
                ),
                icon: const Icon(Icons.add, size: 18),
                label: const Text('추가'),
              ),
            ],
          ),
          if (entries.isNotEmpty) ...[
            const SizedBox(height: 8),
            const Divider(height: 1),
            ...entries.map((e) => Padding(
                  padding: const EdgeInsets.only(top: 10),
                  child: Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(e.food.name, style: const TextStyle(fontWeight: FontWeight.w700)),
                            Text(
                              '${_servingText(e.servings)} · ${e.kcal.round()}kcal · 단백질 ${e.proteinG.round()}g',
                              style: Theme.of(context).textTheme.bodySmall,
                            ),
                          ],
                        ),
                      ),
                      IconButton(
                        icon: const Icon(Icons.close, size: 18, color: AppColors.muted),
                        onPressed: () => context.read<AppState>().removeEntry(e.id),
                      ),
                    ],
                  ),
                )),
          ],
        ],
      ),
    );
  }

  String _servingText(double s) {
    if (s == 0.5) return '반 인분';
    if (s == 1) return '1인분';
    if (s == 1.5) return '1.5인분';
    return '${s.round()}인분';
  }
}
