# 한끼 — 청소년 건강 식단 추천 앱 만들기 설명서

이 폴더 안에는 앱을 만드는 데 필요한 **코드가 전부** 들어 있어요.
아래 순서대로 따라 하면 돼요. 한 단계씩, 천천히.

---

## 앱이 하는 일 (4가지)

| 순서 | 화면 | 하는 일 |
|---|---|---|
| 1 | 인바디 입력 (첫 화면) | 체중계 숫자를 적으면 "내 몸 리포트"가 나와요 |
| 2 | 오늘 | 아침·점심·저녁·간식을 고르면 **하루 권장량 게이지**가 차올라요 |
| 3 | AI 추천 | Claude에게 직접 물어보고 메뉴를 추천받아요 |
| 4 | 식당 찾기 → 내 예약 | 카카오 지도로 1km 안 식당을 찾고, 시간·인원을 적어 예약해요. 사장님은 "사장님 모드"에서 확인해요 |

---

## 0단계. 준비물 확인

맥북 터미널(검은 창)을 열고 아래를 한 줄씩 입력해요.

```bash
flutter --version
```

버전 숫자가 나오면 준비 완료. `command not found`가 나오면 Flutter를 먼저 설치해야 해요 → https://docs.flutter.dev/get-started/install/macos

---

## 1단계. 새 프로젝트 만들고 코드 넣기

1. 터미널에서 프로젝트를 만들 위치로 가요. (예: 바탕화면)
   ```bash
   cd ~/Desktop
   flutter create --org com.hankki hankki
   ```
   → `hankki`라는 폴더가 생겨요. 이게 "빈 앱"이에요.

2. 이 설명서가 들어 있는 폴더(내가 준 코드)에서 **`lib` 폴더와 `pubspec.yaml`**을 복사해서,
   방금 만든 `hankki` 폴더 안에 **덮어쓰기** 해요.
   (기존 `lib/main.dart`는 지워져도 돼요. 새 것으로 바뀌는 거예요.)

3. 패키지(다른 사람이 만든 부품들) 내려받기:
   ```bash
   cd ~/Desktop/hankki
   flutter pub get
   ```

---

## 2단계. 열쇠(API 키) 3개 받아서 넣기

`lib/config/app_keys.dart` 파일을 열면 "여기에-붙여넣기" 라고 쓰인 자리가 3개 있어요.

### ① Claude API 키
1. https://console.anthropic.com 접속 → 로그인
2. 왼쪽 메뉴 **API Keys** → **Create Key** → 이름은 아무거나 (예: hankki)
3. `sk-ant-` 로 시작하는 긴 글자를 복사해서 `claudeApiKey` 자리에 붙여넣기
4. 무료 크레딧이 없으면 **Billing**에서 5달러 정도 충전 (학생 프로젝트면 충분해요)

### ② ③ 카카오 키 2개
1. https://developers.kakao.com 접속 → 카카오 계정으로 로그인
2. **내 애플리케이션** → **애플리케이션 추가하기** → 앱 이름 "한끼", 회사명은 우리 회사 이름
3. 만든 앱 클릭 → **앱 키** 화면에서
   - **JavaScript 키** → `kakaoJavascriptKey` 자리에
   - **REST API 키** → `kakaoRestApiKey` 자리에
4. 같은 화면 왼쪽 **플랫폼** → **Web 플랫폼 등록** → 사이트 도메인에 `http://localhost` 입력 후 저장
5. 왼쪽 **카카오맵** 메뉴(제품 설정) → **활성화 설정 ON**

> 키를 넣은 `app_keys.dart` 파일은 `.gitignore`에 들어 있어서 깃허브에 올라가지 않아요. 발표 자료에도 절대 캡처하지 마세요.

---

## 3단계. 안드로이드 · 아이폰 권한 설정

### 안드로이드
`android/app/src/main/AndroidManifest.xml` 을 열고 `<manifest ...>` 바로 아래에 이 3줄을 넣어요:

```xml
<uses-permission android:name="android.permission.INTERNET" />
<uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />
<uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />
```

그리고 `<application` 이 있는 줄에 `android:usesCleartextTraffic="true"` 를 추가해요:

```xml
<application
    android:label="한끼"
    android:usesCleartextTraffic="true"
    ...
```

`android/app/build.gradle` (또는 `build.gradle.kts`)에서 `minSdk`가 21보다 작으면 **23**으로 바꿔요.

### 아이폰
`ios/Runner/Info.plist` 를 열고 `<dict>` 안 아무 데나 넣어요:

```xml
<key>NSLocationWhenInUseUsageDescription</key>
<string>내 주변 1km 식당을 찾기 위해 위치를 사용해요.</string>
<key>NSAppTransportSecurity</key>
<dict>
  <key>NSAllowsArbitraryLoads</key>
  <true/>
  <key>NSAllowsArbitraryLoadsInWebContent</key>
  <true/>
</dict>
<key>io.flutter.embedded_views_preview</key>
<true/>
```

---

## 4단계. 실행!

폰을 USB로 연결하거나 시뮬레이터를 켜고:

```bash
flutter run
```

첫 화면에 **"인바디 결과를 그대로 적어주세요"** 가 나오면 성공이에요.

> 이 단계에서는 예약이 **연습 모드**(내 폰에만 저장)로 돌아가요. 사장님 폰과 공유하려면 5단계로.

---

## 5단계 (선택). Firebase 연결 — 예약을 사장님과 공유하기

1. https://console.firebase.google.com → **프로젝트 추가** → 이름 "hankki"
2. 왼쪽 **빌드 → Firestore Database → 데이터베이스 만들기** → **테스트 모드**로 시작 → 위치는 asia-northeast3 (서울)
3. 터미널에서:
   ```bash
   dart pub global activate flutterfire_cli
   flutterfire configure
   ```
   → 방향키로 hankki 프로젝트 선택 → 플랫폼은 android, ios 선택 → 엔터
   → `lib/firebase_options.dart` 가 **진짜 파일로 자동 교체**돼요.
4. 다시 `flutter run`. "내 예약" 탭 위의 노란 "연습 모드" 안내가 사라지면 연결된 거예요.

> 테스트 모드는 30일 뒤 잠겨요. 박람회 전에 Firestore **규칙** 탭에서 만료 날짜를 늘려두세요.

---

## 어떤 파일이 무슨 일을 하나요?

```
lib/
├─ main.dart                  앱의 시작점. 열쇠 등록 → Firebase 연결 → 첫 화면 띄우기
├─ config/app_keys.dart       열쇠 보관함 (비밀!)
├─ theme/app_theme.dart       색깔·글꼴·버튼 모양 (여기만 바꾸면 앱 전체가 바뀜)
│
├─ models/                    "데이터 모양" 정의
│   ├─ body_profile.dart      인바디 숫자 + 몸 상태 한 줄 평가
│   ├─ nutrition.dart         음식·식사 기록·하루 권장량 계산
│   └─ reservation.dart       예약 한 건
├─ data/food_database.dart    음식 60여 개 목록 (제휴 식당 메뉴를 여기 추가)
├─ state/app_state.dart       앱의 기억 상자 + Claude에게 보낼 "오늘 상황 설명서"
│
├─ services/                  바깥 세상과 통신
│   ├─ claude_service.dart    Claude API 우체부
│   ├─ kakao_local_service.dart 카카오 "1km 안 음식점" 검색
│   └─ reservation_service.dart 예약 장부 (Firebase 진짜 모드 / 폰 연습 모드)
│
├─ screens/                   화면들
│   ├─ body_input_screen.dart     ① 인바디 입력 (첫 화면)
│   ├─ health_report_screen.dart  ① 내 몸 리포트
│   ├─ home_shell.dart            아래 탭 4개
│   ├─ meal_log_screen.dart       ② 오늘 (게이지 + 끼니 기록)
│   ├─ food_picker_sheet.dart     ② 음식 고르기 창
│   ├─ ai_chat_screen.dart        ③ AI 메뉴 코치 채팅
│   ├─ restaurant_map_screen.dart ④ 카카오 지도 + 식당 목록
│   ├─ reservation_sheet.dart     ④ 예약 창 (시간·인원) → 예약번호
│   ├─ my_reservations_screen.dart ④ 내 예약 목록
│   └─ owner_screen.dart          ④ 사장님 모드 (확정·방문완료·수수료 계산)
└─ widgets/                   여러 화면에서 같이 쓰는 조각
    ├─ nutrient_gauge.dart    캡슐 게이지
    ├─ body_summary_card.dart 초록 몸 정보 카드
    └─ section_title.dart     작은 제목
```

---

## 코드가 어떻게 흘러가는지 (한 바퀴)

1. **앱 켜짐** → `main.dart`가 열쇠를 등록하고 `BodyInputScreen`을 띄워요.
2. **인바디 입력** → 숫자들을 `BodyProfile`이라는 상자에 담아 `AppState`에 저장 → `HealthReportScreen`이 `BodyInsight.from()`으로 한 줄 평가를 만들어 보여줘요.
3. **오늘 탭** → `+`를 누르면 `showFoodPicker()`가 창을 열고, 고른 음식이 `AppState.addEntry()`로 들어가요 → `todayTotals`가 다시 계산되고 → `NutrientGauge`가 `NutritionTargets`(권장량)와 비교해서 차올라요.
4. **AI 추천** → `AppState.buildSystemPrompt()`가 "이 학생은 이런 몸이고, 오늘 이걸 먹었고, 이만큼 남았어요"를 글로 만들어요 → `ClaudeService.ask()`가 그 글 + 학생 질문을 Claude에게 보내고 답을 받아 말풍선으로 띄워요.
5. **식당 찾기** → `Geolocator`로 내 위치 → `KakaoLocalService.searchNearby()`가 1km 안 음식점 15개 → 지도에 핀 + 목록.
6. **예약** → 시간·인원을 적으면 `ReservationService.create()`가 4자리 예약번호를 만들어 장부에 적어요.
7. **사장님 모드** → "내 예약" 탭 오른쪽 위 가게 아이콘 → 비밀번호 1234 → 가게 이름 입력 → 들어온 예약을 **확정 / 방문완료**. 방문완료 때 결제금액을 적으면 **이번 달 수수료 5%**가 자동 계산돼요.

---

## 발표에서 강조할 설계 포인트

- **칼로리 제한이 아니라 "채우기"** — 게이지 문구가 "부족/초과"가 아니라 "조금 더 채워요 / 좋아요 / 충분해요"예요. 성장기 학생에게 안전한 설계라는 근거. (`nutrient_gauge.dart`)
- **AI 규칙** — "굶어라, 살 빼라"를 말하지 못하게 시스템 프롬프트에 규칙을 넣었어요. (`app_state.dart`의 `buildSystemPrompt`)
- **결제 없는 수익 구조** — 앱은 예약번호만 만들고, 결제는 가게에서. 사장님이 "방문완료"를 누른 건만 5%로 계산. 미성년자 계약·전자금융거래법 문제를 피한 설계. (`owner_screen.dart`)
- **지리** — 반경 1km 원이 지도에 그려져요. 백마 학원가 기준 좌표가 기본값. (`restaurant_map_screen.dart`)
- **법** — 위치 권한은 앱이 직접 묻고(위치정보법), 키는 `.gitignore`로 보호.

---

## 자주 나는 오류

| 증상 | 해결 |
|---|---|
| `flutter pub get`에서 버전 충돌 | `flutter pub upgrade --major-versions` 실행 |
| 지도가 하얗게 비어 있음 | 카카오 JavaScript 키 확인 → 플랫폼에 `http://localhost` 등록했는지 → 카카오맵 활성화 ON |
| 식당 검색 오류 401 | REST API 키가 잘못됨 (JavaScript 키와 헷갈리기 쉬움) |
| AI가 "답을 못 받았어요" | Claude 키 확인 → 콘솔 Billing에 크레딧이 있는지 |
| 위치가 "백마 학원가" 기준으로만 나옴 | 폰 설정에서 앱 위치 권한 허용 → 지도 위 과녁 아이콘 눌러 다시 시도 |
| iOS에서 빌드 오류 | `cd ios && pod install && cd ..` 후 다시 `flutter run` |
| `CardThemeData` 오류 | Flutter가 오래된 버전. `flutter upgrade` |

---

## 다음에 추가하면 좋은 것

1. `food_database.dart`에 **제휴 식당 실제 메뉴** 넣기 (메뉴판 사진 찍어서 입력)
2. 회원 등급제 (씨앗 → 새싹 → 나무 → 숲): 기록 일수를 세는 코드만 붙이면 돼요
3. 개인정보 동의 화면 (가입 시 1회)
