// ─────────────────────────────────────────────────────────────
//  이 파일은 "임시" 파일이에요.
//  터미널에서  flutterfire configure  를 실행하면
//  진짜 Firebase 설정 파일로 자동으로 바뀌어요.
//  그 전까지 앱은 "연습 모드"(폰 안에만 저장)로 돌아가요.
// ─────────────────────────────────────────────────────────────
import 'package:firebase_core/firebase_core.dart';

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    throw UnsupportedError(
      '아직 Firebase 설정을 안 했어요. 터미널에서 flutterfire configure 를 실행하세요.',
    );
  }
}
