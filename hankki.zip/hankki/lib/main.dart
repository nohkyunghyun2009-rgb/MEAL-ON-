import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:kakao_map_plugin/kakao_map_plugin.dart';
import 'package:provider/provider.dart';

import 'config/app_keys.dart';
import 'firebase_options.dart';
import 'screens/body_input_screen.dart';
import 'services/reservation_service.dart';
import 'state/app_state.dart';
import 'theme/app_theme.dart';

/// 앱이 켜지면 제일 먼저 실행되는 곳
Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // 1) 카카오 지도에 열쇠 보여주기
  if (AppKeys.kakaoReady) {
    AuthRepository.initialize(appKey: AppKeys.kakaoJavascriptKey);
  }

  // 2) Firebase 연결 시도. 아직 설정 안 했으면 "연습 모드"로 켜요.
  bool firebaseReady = false;
  try {
    await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
    firebaseReady = true;
  } catch (e) {
    debugPrint('Firebase 없이 연습 모드로 시작해요: $e');
  }

  // 3) 폰에 저장된 것 불러오기
  final appState = AppState();
  await appState.load();

  final reservations = ReservationService.create(useFirebase: firebaseReady);
  await reservations.init();

  // 4) 앱 시작! (기억 상자 두 개를 모든 화면에 나눠줘요)
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider<AppState>.value(value: appState),
        ChangeNotifierProvider<ReservationService>.value(value: reservations),
      ],
      child: const HankkiApp(),
    ),
  );
}

class HankkiApp extends StatelessWidget {
  const HankkiApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: '한끼',
      debugShowCheckedModeBanner: false,
      theme: buildAppTheme(),
      // 첫 화면은 항상 인바디 입력 (박람회에서 측정하고 바로 적기)
      home: const BodyInputScreen(),
    );
  }
}
