/// 인바디 체중계에서 나온 숫자들을 담는 "몸 정보 카드"예요.
enum Sex { male, female }

enum ActivityLevel { low, normal, high }

extension ActivityLabel on ActivityLevel {
  String get label => switch (this) {
        ActivityLevel.low => '거의 앉아서',
        ActivityLevel.normal => '보통',
        ActivityLevel.high => '운동 많이',
      };
}

class BodyProfile {
  final String nickname;
  final Sex sex;
  final int age;
  final double heightCm;
  final double weightKg;
  final double bodyFatPercent; // 체지방률 (%)
  final double skeletalMuscleKg; // 골격근량 (kg)
  final double? basalMetabolicRate; // 기초대사량 (kcal) - 인바디가 알려주면 적기 (선택)
  final ActivityLevel activity;
  final DateTime measuredAt;

  const BodyProfile({
    required this.nickname,
    required this.sex,
    required this.age,
    required this.heightCm,
    required this.weightKg,
    required this.bodyFatPercent,
    required this.skeletalMuscleKg,
    required this.activity,
    required this.measuredAt,
    this.basalMetabolicRate,
  });

  // ───── 계산으로 나오는 값들 ─────
  double get bmi => weightKg / ((heightCm / 100) * (heightCm / 100));
  double get fatMassKg => weightKg * bodyFatPercent / 100; // 체지방 무게
  double get leanMassKg => weightKg - fatMassKg; // 지방 뺀 무게
  double get muscleRatioPercent => skeletalMuscleKg / weightKg * 100; // 몸무게 중 근육 비율

  bool get isMale => sex == Sex.male;

  // ───── 저장/불러오기 (폰 안에 글자로 저장했다가 다시 꺼내요) ─────
  Map<String, dynamic> toJson() => {
        'nickname': nickname,
        'sex': sex.name,
        'age': age,
        'heightCm': heightCm,
        'weightKg': weightKg,
        'bodyFatPercent': bodyFatPercent,
        'skeletalMuscleKg': skeletalMuscleKg,
        'basalMetabolicRate': basalMetabolicRate,
        'activity': activity.name,
        'measuredAt': measuredAt.millisecondsSinceEpoch,
      };

  factory BodyProfile.fromJson(Map<String, dynamic> j) => BodyProfile(
        nickname: j['nickname'] as String,
        sex: Sex.values.byName(j['sex'] as String),
        age: (j['age'] as num).toInt(),
        heightCm: (j['heightCm'] as num).toDouble(),
        weightKg: (j['weightKg'] as num).toDouble(),
        bodyFatPercent: (j['bodyFatPercent'] as num).toDouble(),
        skeletalMuscleKg: (j['skeletalMuscleKg'] as num).toDouble(),
        basalMetabolicRate: (j['basalMetabolicRate'] as num?)?.toDouble(),
        activity: ActivityLevel.values.byName(j['activity'] as String),
        measuredAt: DateTime.fromMillisecondsSinceEpoch(j['measuredAt'] as int),
      );
}

/// 몸 상태를 "혼내지 않고" 알려주는 한 줄 메시지들.
/// 성장기 학생에게는 "살 빼라"가 아니라 "무엇을 채우면 좋은지"를 말해줘야 해요.
class BodyInsight {
  final String headline; // 큰 제목 한 줄
  final List<String> points; // 자세한 설명들
  final List<String> focusNutrients; // AI 추천에 쓸 "채우면 좋은 영양소"

  const BodyInsight(this.headline, this.points, this.focusNutrients);

  static BodyInsight from(BodyProfile p) {
    final points = <String>[];
    final focus = <String>[];

    // 1) 체지방률 - 청소년 참고 범위 (대략적인 값이에요)
    final fat = p.bodyFatPercent;
    final (fatLow, fatHigh) = p.isMale ? (10.0, 20.0) : (17.0, 27.0);
    String fatWord;
    if (fat < fatLow) {
      fatWord = '체지방이 적은 편';
      points.add('체지방률 ${fat.toStringAsFixed(1)}% — 참고 범위보다 낮아요. 성장기엔 에너지가 충분해야 하니 끼니를 거르지 않는 게 중요해요.');
      focus.add('에너지(탄수화물)');
    } else if (fat <= fatHigh) {
      fatWord = '체지방 균형이 좋아요';
      points.add('체지방률 ${fat.toStringAsFixed(1)}% — 참고 범위 안이에요. 지금처럼 골고루 먹으면 돼요.');
    } else if (fat <= fatHigh + 5) {
      fatWord = '체지방이 조금 있는 편';
      points.add('체지방률 ${fat.toStringAsFixed(1)}% — 참고 범위보다 살짝 높아요. 튀김·단 음료를 줄이고 채소를 곁들이면 좋아요.');
      focus.add('채소·식이섬유');
    } else {
      fatWord = '체지방이 많은 편';
      points.add('체지방률 ${fat.toStringAsFixed(1)}% — 참고 범위보다 높아요. 굶는 건 금물! 밥은 그대로, 튀김·단 음료를 다른 걸로 바꿔봐요.');
      focus.add('채소·식이섬유');
    }

    // 2) 근육 비율 (골격근량 ÷ 몸무게)
    final mr = p.muscleRatioPercent;
    final (mGood, mOk) = p.isMale ? (40.0, 35.0) : (34.0, 30.0);
    if (mr >= mGood) {
      points.add('골격근 비율 ${mr.toStringAsFixed(0)}% — 근육이 탄탄해요. 단백질을 꾸준히 먹으면 성장에 도움이 돼요.');
    } else if (mr >= mOk) {
      points.add('골격근 비율 ${mr.toStringAsFixed(0)}% — 보통이에요. 단백질(계란·두부·생선·고기)을 매 끼니 조금씩 넣어봐요.');
      focus.add('단백질');
    } else {
      points.add('골격근 비율 ${mr.toStringAsFixed(0)}% — 근육을 더 키우면 좋아요. 단백질 반찬을 한 가지 더 챙기고, 가볍게 몸을 움직여봐요.');
      focus.add('단백질');
    }

    // 3) BMI는 숫자만 부드럽게 (청소년은 나이별 기준이 달라서 진단하지 않아요)
    points.add('BMI ${p.bmi.toStringAsFixed(1)} — 성장기에는 나이마다 기준이 달라요. 이 숫자보다 위의 근육·체지방 균형이 더 중요해요.');

    if (focus.isEmpty) focus.add('골고루');

    final headline = '$fatWord${mr >= mGood ? ', 근육도 든든해요' : ''}';
    return BodyInsight(headline, points, focus);
  }
}
