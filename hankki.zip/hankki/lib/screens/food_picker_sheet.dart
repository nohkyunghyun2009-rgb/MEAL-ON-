import 'package:flutter/material.dart';

import '../data/food_database.dart';
import '../models/nutrition.dart';
import '../theme/app_theme.dart';

/// 음식 고르기 창이 돌려주는 답: "이 음식을, 이만큼"
class PickedFood {
  final FoodItem food;
  final double servings;
  const PickedFood(this.food, this.servings);
}

/// 아래에서 올라오는 음식 고르기 창을 열어요.
Future<PickedFood?> showFoodPicker(BuildContext context) {
  return showModalBottomSheet<PickedFood>(
    context: context,
    isScrollControlled: true, // 화면 높이만큼 크게
    backgroundColor: Colors.transparent,
    builder: (_) => const _FoodPickerSheet(),
  );
}

class _FoodPickerSheet extends StatefulWidget {
  const _FoodPickerSheet();

  @override
  State<_FoodPickerSheet> createState() => _FoodPickerSheetState();
}

class _FoodPickerSheetState extends State<_FoodPickerSheet> {
  final _query = TextEditingController();
  String _category = '전체';

  @override
  void dispose() {
    _query.dispose();
    super.dispose();
  }

  Future<void> _choose(FoodItem food) async {
    // 몇 인분인지 묻기
    final servings = await showDialog<double>(
      context: context,
      builder: (_) => _ServingsDialog(food: food),
    );
    if (servings != null && mounted) {
      Navigator.of(context).pop(PickedFood(food, servings));
    }
  }

  Future<void> _addCustom() async {
    final food = await showDialog<FoodItem>(
      context: context,
      builder: (_) => const _CustomFoodDialog(),
    );
    if (food != null && mounted) _choose(food);
  }

  @override
  Widget build(BuildContext context) {
    final results = FoodDatabase.search(_query.text, category: _category);

    return DraggableScrollableSheet(
      initialChildSize: 0.85,
      minChildSize: 0.5,
      maxChildSize: 0.95,
      builder: (context, scroll) => Container(
        decoration: const BoxDecoration(
          color: AppColors.paper,
          borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
        ),
        child: Column(
          children: [
            const SizedBox(height: 10),
            Container(width: 40, height: 4, decoration: BoxDecoration(color: AppColors.line, borderRadius: BorderRadius.circular(2))),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 14, 20, 8),
              child: Row(
                children: [
                  Text('뭐 먹었어?', style: Theme.of(context).textTheme.titleLarge),
                  const Spacer(),
                  TextButton.icon(
                    onPressed: _addCustom,
                    icon: const Icon(Icons.edit_outlined, size: 18),
                    label: const Text('직접 입력'),
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: TextField(
                controller: _query,
                onChanged: (_) => setState(() {}),
                decoration: InputDecoration(
                  hintText: '음식 이름 검색 (예: 덮밥)',
                  prefixIcon: const Icon(Icons.search),
                  suffixIcon: _query.text.isEmpty
                      ? null
                      : IconButton(
                          icon: const Icon(Icons.clear),
                          onPressed: () => setState(() => _query.clear()),
                        ),
                ),
              ),
            ),
            const SizedBox(height: 10),
            // 카테고리 칩 (옆으로 스크롤)
            SizedBox(
              height: 40,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 20),
                itemCount: FoodDatabase.categories.length,
                separatorBuilder: (_, __) => const SizedBox(width: 8),
                itemBuilder: (_, i) {
                  final c = FoodDatabase.categories[i];
                  return ChoiceChip(
                    label: Text(c),
                    selected: _category == c,
                    onSelected: (_) => setState(() => _category = c),
                  );
                },
              ),
            ),
            const SizedBox(height: 6),
            Expanded(
              child: results.isEmpty
                  ? Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text('목록에 없어요', style: Theme.of(context).textTheme.titleMedium),
                          const SizedBox(height: 6),
                          Text('"직접 입력"으로 추가할 수 있어요', style: Theme.of(context).textTheme.bodySmall),
                        ],
                      ),
                    )
                  : ListView.separated(
                      controller: scroll,
                      padding: const EdgeInsets.fromLTRB(20, 4, 20, 30),
                      itemCount: results.length,
                      separatorBuilder: (_, __) => const SizedBox(height: 8),
                      itemBuilder: (_, i) {
                        final f = results[i];
                        return Card(
                          child: ListTile(
                            onTap: () => _choose(f),
                            title: Text(f.name, style: const TextStyle(fontWeight: FontWeight.w700)),
                            subtitle: Text(
                              '${f.kcal.round()}kcal · 탄 ${f.carbG.round()}g · 단 ${f.proteinG.round()}g · 지 ${f.fatG.round()}g',
                              style: Theme.of(context).textTheme.bodySmall,
                            ),
                            trailing: Container(
                              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                              decoration: BoxDecoration(color: AppColors.mint, borderRadius: BorderRadius.circular(999)),
                              child: Text(f.category, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: AppColors.green)),
                            ),
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }
}

/// "몇 인분 먹었어?" 묻는 작은 창
class _ServingsDialog extends StatefulWidget {
  final FoodItem food;
  const _ServingsDialog({required this.food});

  @override
  State<_ServingsDialog> createState() => _ServingsDialogState();
}

class _ServingsDialogState extends State<_ServingsDialog> {
  double _servings = 1;

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(widget.food.name),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Text('얼마나 먹었어?'),
          const SizedBox(height: 12),
          SegmentedButton<double>(
            segments: const [
              ButtonSegment(value: 0.5, label: Text('반')),
              ButtonSegment(value: 1, label: Text('1')),
              ButtonSegment(value: 1.5, label: Text('1.5')),
              ButtonSegment(value: 2, label: Text('2')),
            ],
            selected: {_servings},
            onSelectionChanged: (s) => setState(() => _servings = s.first),
          ),
          const SizedBox(height: 10),
          Text('${(widget.food.kcal * _servings).round()} kcal', style: Theme.of(context).textTheme.titleMedium),
        ],
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('취소')),
        FilledButton(
          style: FilledButton.styleFrom(minimumSize: const Size(80, 44)),
          onPressed: () => Navigator.pop(context, _servings),
          child: const Text('추가'),
        ),
      ],
    );
  }
}

/// 목록에 없는 음식을 직접 적는 창
class _CustomFoodDialog extends StatefulWidget {
  const _CustomFoodDialog();

  @override
  State<_CustomFoodDialog> createState() => _CustomFoodDialogState();
}

class _CustomFoodDialogState extends State<_CustomFoodDialog> {
  final _name = TextEditingController();
  final _kcal = TextEditingController();
  final _carb = TextEditingController();
  final _protein = TextEditingController();
  final _fat = TextEditingController();

  @override
  void dispose() {
    for (final c in [_name, _kcal, _carb, _protein, _fat]) {
      c.dispose();
    }
    super.dispose();
  }

  double _num(TextEditingController c) => double.tryParse(c.text) ?? 0;

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('직접 입력'),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(controller: _name, decoration: const InputDecoration(labelText: '음식 이름')),
            const SizedBox(height: 10),
            TextField(controller: _kcal, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: '칼로리 (kcal)')),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(child: TextField(controller: _carb, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: '탄수화물 g'))),
                const SizedBox(width: 8),
                Expanded(child: TextField(controller: _protein, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: '단백질 g'))),
                const SizedBox(width: 8),
                Expanded(child: TextField(controller: _fat, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: '지방 g'))),
              ],
            ),
            const SizedBox(height: 8),
            Text('영양 정보는 포장지나 가게 메뉴판에서 찾을 수 있어요. 모르면 칼로리만 적어도 돼요.', style: Theme.of(context).textTheme.bodySmall),
          ],
        ),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('취소')),
        FilledButton(
          style: FilledButton.styleFrom(minimumSize: const Size(80, 44)),
          onPressed: () {
            if (_name.text.trim().isEmpty) return;
            Navigator.pop(
              context,
              FoodItem(
                name: _name.text.trim(),
                category: '직접',
                kcal: _num(_kcal),
                carbG: _num(_carb),
                proteinG: _num(_protein),
                fatG: _num(_fat),
                sodiumMg: 0,
              ),
            );
          },
          child: const Text('다음'),
        ),
      ],
    );
  }
}
