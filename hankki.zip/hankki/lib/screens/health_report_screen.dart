import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../state/app_state.dart';
import '../theme/app_theme.dart';
import '../widgets/body_summary_card.dart';
import '../widgets/section_title.dart';
import 'home_shell.dart';

/// 인바디를 적은 직후에 보는 "내 몸 리포트"
class HealthReportScreen extends StatelessWidget {
  const HealthReportScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final p = app.profile!;
    final insight = app.insight!;
    final t = app.targets!;

    return Scaffold(
      appBar: AppBar(title: const Text('내 몸 리포트')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(20, 8, 20, 32),
        children: [
          BodySummaryCard(profile: p),
          const SizedBox(height: 24),

          // ───── 한 줄 결론 ─────
          Text(insight.headline, style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontSize: 24)),
          const SizedBox(height: 12),
          ...insight.points.map((text) => Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      margin: const EdgeInsets.only(top: 7, right: 10),
                      width: 8,
                      height: 8,
                      decoration: const BoxDecoration(color: AppColors.green, shape: BoxShape.circle),
                    ),
                    Expanded(child: Text(text, style: Theme.of(context).textTheme.bodyLarge)),
                  ],
                ),
              )),
          const SizedBox(height: 24),

          // ───── 오늘 목표 ─────
          const SectionTitle('오늘 이만큼 채우면 좋아요', subtitle: '청소년 영양소 섭취기준 + 인바디 결과로 계산했어요'),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  _TargetRow('에너지', '${t.kcal.round()} kcal', AppColors.green),
                  _TargetRow('탄수화물', '${t.carbG.round()} g', AppColors.sun),
                  _TargetRow('단백질', '${t.proteinG.round()} g', AppColors.sky),
                  _TargetRow('지방', '${t.fatG.round()} g', AppColors.coral),
                  _TargetRow('나트륨', '${t.sodiumMg.round()} mg 이하', AppColors.plum),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          Text(
            '이 리포트는 참고용이에요. 몸이 아프거나 걱정되는 게 있으면 보건 선생님이나 병원에 이야기해요.',
            style: Theme.of(context).textTheme.bodySmall,
          ),
          const SizedBox(height: 28),

          FilledButton(
            onPressed: () => Navigator.of(context).pushReplacement(
              MaterialPageRoute(builder: (_) => const HomeShell()),
            ),
            child: const Text('오늘 먹은 것 기록하러 가기'),
          ),
        ],
      ),
    );
  }
}

class _TargetRow extends StatelessWidget {
  final String label, value;
  final Color color;
  const _TargetRow(this.label, this.value, this.color);

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 6),
        child: Row(
          children: [
            Container(width: 10, height: 10, decoration: BoxDecoration(color: color, shape: BoxShape.circle)),
            const SizedBox(width: 10),
            Text(label, style: Theme.of(context).textTheme.bodyLarge),
            const Spacer(),
            Text(value, style: Theme.of(context).textTheme.titleMedium),
          ],
        ),
      );
}
