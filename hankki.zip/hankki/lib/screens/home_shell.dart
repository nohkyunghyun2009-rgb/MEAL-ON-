import 'package:flutter/material.dart';

import 'ai_chat_screen.dart';
import 'meal_log_screen.dart';
import 'my_reservations_screen.dart';
import 'restaurant_map_screen.dart';

/// 아래 탭 4개를 가진 "집" 화면.
/// IndexedStack을 쓰면 탭을 옮겨도 각 화면이 기억을 잃지 않아요.
class HomeShell extends StatefulWidget {
  const HomeShell({super.key});

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _index = 0;

  final _pages = const [
    MealLogScreen(),
    AiChatScreen(),
    RestaurantMapScreen(),
    MyReservationsScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(index: _index, children: _pages),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (i) => setState(() => _index = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.restaurant_outlined), selectedIcon: Icon(Icons.restaurant), label: '오늘'),
          NavigationDestination(icon: Icon(Icons.auto_awesome_outlined), selectedIcon: Icon(Icons.auto_awesome), label: 'AI 추천'),
          NavigationDestination(icon: Icon(Icons.map_outlined), selectedIcon: Icon(Icons.map), label: '식당 찾기'),
          NavigationDestination(icon: Icon(Icons.confirmation_number_outlined), selectedIcon: Icon(Icons.confirmation_number), label: '내 예약'),
        ],
      ),
    );
  }
}
