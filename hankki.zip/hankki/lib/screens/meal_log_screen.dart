import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/nutrition.dart';
import '../state/app_state.dart';
import '../theme/app_theme.dart';
import '../widgets/body_summary_card.dart';
import '../widgets/nutrient_gauge.dart';
import '../widgets/section_title.dart';
import 'body_input_screen.dart';
import 'food_picker_sheet.dart';

/// "오늘" 탭: 게이지 + 아침/점심/저녁/간식 기록
class MealLogScreen extends StatelessWidget {
  const MealLogScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final p = app.profile;
    final t = app.targets;
    final total = app.todayTotals;

    return Scaffold(
      appBar: AppBar(
        title: const Text('오늘 한 끼'),
        actions: [
          IconButton(
            tooltip: '인바디 다시 재기',
            icon: const Icon(Icons.monitor_weight_outlined),
            onPressed: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const BodyInputScreen()),
            ),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(20, 4, 20, 32),
        children: [
          if (p != null) BodySummaryCard(profile: p, compact: true),
          const SizedBox(height: 24),

          // ───── 게이지 ─────
          SectionTitle(
            '오늘의 균형',
            subtitle: t == null ? '인바디를 먼저 적으면 목표가 생겨요' : '하루 권장량을 얼마나 채웠는지 봐요',
          ),
          if (t != null)
            Card(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
                child: Column(
                  children: [
                    NutrientGauge(label: '에너지', value: total.kcal, target: t.kcal, unit: 'kcal', color: AppColors.green),
                    NutrientGauge(label: '탄수화물', value: total.carbG, target: t.carbG, unit: 'g', color: AppColors.sun),
                    NutrientGauge(label: '단백질', value: total.proteinG, target: t.proteinG, unit: 'g', color: AppColors.sky),
                    NutrientGauge(label: '지방', value: total.fatG, target: t.fatG, unit: 'g', color: AppColors.coral),
                    NutrientGauge(label: '나트륨', value: total.sodiumMg, target: t.sodiumMg, unit: 'mg', color: AppColors.plum, lessIsBetter: true),
                  ],
                ),
              ),
            ),
          const SizedBox(height: 24),

          // ───── 끼니별 카드 ─────
          const SectionTitle('오늘 뭐 먹었어?', subtitle: '+ 를 눌러서 먹은 걸 골라요'),
          ...MealType.values.map((m) => Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: _MealCard(meal: m),
              )),
        ],
      ),
    );
  }
}

class _MealCard extends StatelessWidget {
  final MealType meal;
  const _MealCard({required this.meal});

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final entries = app.entriesFor(meal);
    final kcal = entries.fold<double>(0, (s, e) => s + e.kcal);

    return Card(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 12, 8, 12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Text(meal.emoji, style: const TextStyle(fontSize: 20)),
                const SizedBox(width: 8),
                Text(meal.label, style: Theme.of(context).textTheme.titleMedium),
                const SizedBox(width: 8),
                if (entries.isNotEmpty)
                  Text('${kcal.round()} kcal', style: Theme.of(context).textTheme.bodySmall),
                const Spacer(),
                IconButton.filledTonal(
                  onPressed: () async {
                    // 음식 고르는 창을 열고, 골라오면 기록에 추가
                    final picked = await showFoodPicker(context);
                    if (picked != null && context.mounted) {
                      await context.read<AppState>().addEntry(meal, picked.food, picked.servings);
                    }
                  },
                  icon: const Icon(Icons.add),
                ),
              ],
            ),
            if (entries.isEmpty)
              Padding(
                padding: const EdgeInsets.only(top: 4, bottom: 4),
                child: Text('아직 기록이 없어요', style: Theme.of(context).textTheme.bodySmall),
              ),
            ...entries.map((e) => ListTile(
                  contentPadding: EdgeInsets.zero,
                  dense: true,
                  title: Text(e.food.name),
                  subtitle: Text(
                    '${_servingText(e.servings)} · ${e.kcal.round()}kcal · 단백질 ${e.proteinG.round()}g',
                    style: Theme.of(context).textTheme.bodySmall,
                  ),
                  trailing: IconButton(
                    icon: const Icon(Icons.close, size: 18, color: AppColors.muted),
                    onPressed: () => context.read<AppState>().removeEntry(e.id),
                  ),
                )),
          ],
        ),
      ),
    );
  }

  String _servingText(double s) {
    if (s == 0.5) return '반 인분';
    if (s == 1) return '1인분';
    if (s == 1.5) return '1.5인분';
    return '${s.round()}인분';
  }
}
