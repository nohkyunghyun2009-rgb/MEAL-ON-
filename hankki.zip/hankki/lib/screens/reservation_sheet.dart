import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/reservation.dart';
import '../services/kakao_local_service.dart';
import '../services/reservation_service.dart';
import '../state/app_state.dart';
import '../theme/app_theme.dart';

/// 식당을 누르면 아래에서 올라오는 예약 창
Future<void> showReservationSheet(BuildContext context, Place place) {
  return showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    builder: (_) => _ReservationSheet(place: place),
  );
}

class _ReservationSheet extends StatefulWidget {
  final Place place;
  const _ReservationSheet({required this.place});

  @override
  State<_ReservationSheet> createState() => _ReservationSheetState();
}

class _ReservationSheetState extends State<_ReservationSheet> {
  late DateTime _visitAt;
  int _people = 2;
  final _note = TextEditingController();
  bool _sending = false;

  @override
  void initState() {
    super.initState();
    // 기본값: 지금부터 1시간 뒤, 분은 0 또는 30으로 맞춤
    final now = DateTime.now().add(const Duration(hours: 1));
    _visitAt = DateTime(now.year, now.month, now.day, now.hour, now.minute < 30 ? 0 : 30);
  }

  @override
  void dispose() {
    _note.dispose();
    super.dispose();
  }

  Future<void> _pickDate() async {
    final d = await showDatePicker(
      context: context,
      initialDate: _visitAt,
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(const Duration(days: 30)),
    );
    if (d != null) {
      setState(() => _visitAt = DateTime(d.year, d.month, d.day, _visitAt.hour, _visitAt.minute));
    }
  }

  Future<void> _pickTime() async {
    final t = await showTimePicker(
      context: context,
      initialTime: TimeOfDay(hour: _visitAt.hour, minute: _visitAt.minute),
    );
    if (t != null) {
      setState(() => _visitAt = DateTime(_visitAt.year, _visitAt.month, _visitAt.day, t.hour, t.minute));
    }
  }

  Future<void> _submit() async {
    final app = context.read<AppState>();
    final service = context.read<ReservationService>();
    final nickname = app.profile?.nickname ?? '손님';

    setState(() => _sending = true);
    try {
      final r = await service.create(
        restaurantId: widget.place.id,
        restaurantName: widget.place.name,
        restaurantAddress: widget.place.address,
        userNickname: nickname,
        visitAt: _visitAt,
        people: _people,
        note: _note.text.trim(),
      );
      if (!mounted) return;
      Navigator.of(context).pop(); // 예약 창 닫기
      await showDialog<void>(
        context: context,
        builder: (_) => _CodeDialog(reservation: r, online: service.isOnline),
      );
    } catch (e) {
      if (!mounted) return;
      setState(() => _sending = false);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('예약을 못 보냈어요: $e')));
    }
  }

  @override
  Widget build(BuildContext context) {
    final p = widget.place;
    final bottom = MediaQuery.of(context).viewInsets.bottom; // 키보드 높이

    return Padding(
      padding: EdgeInsets.only(bottom: bottom),
      child: Container(
        decoration: const BoxDecoration(
          color: AppColors.paper,
          borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
        ),
        padding: const EdgeInsets.fromLTRB(20, 12, 20, 24),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(width: 40, height: 4, decoration: BoxDecoration(color: AppColors.line, borderRadius: BorderRadius.circular(2))),
              ),
              const SizedBox(height: 16),
              Text(p.name, style: Theme.of(context).textTheme.titleLarge),
              const SizedBox(height: 4),
              Text('${p.shortCategory} · ${p.distanceText} · ${p.address}', style: Theme.of(context).textTheme.bodySmall),
              if (p.phone.isNotEmpty) Text(p.phone, style: Theme.of(context).textTheme.bodySmall),
              const SizedBox(height: 20),

              // ───── 방문 시간 ─────
              Text('언제 갈 거야?', style: Theme.of(context).textTheme.titleMedium),
              const SizedBox(height: 8),
              Row(
                children: [
                  Expanded(
                    child: _PickBox(
                      icon: Icons.calendar_today_outlined,
                      text: '${_visitAt.month}월 ${_visitAt.day}일',
                      onTap: _pickDate,
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: _PickBox(
                      icon: Icons.schedule,
                      text: '${_visitAt.hour.toString().padLeft(2, '0')}:${_visitAt.minute.toString().padLeft(2, '0')}',
                      onTap: _pickTime,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 18),

              // ───── 인원 ─────
              Row(
                children: [
                  Text('몇 명이야?', style: Theme.of(context).textTheme.titleMedium),
                  const Spacer(),
                  IconButton.outlined(
                    onPressed: _people > 1 ? () => setState(() => _people--) : null,
                    icon: const Icon(Icons.remove),
                  ),
                  SizedBox(
                    width: 48,
                    child: Text('$_people명', textAlign: TextAlign.center, style: Theme.of(context).textTheme.titleMedium),
                  ),
                  IconButton.outlined(
                    onPressed: _people < 10 ? () => setState(() => _people++) : null,
                    icon: const Icon(Icons.add),
                  ),
                ],
              ),
              const SizedBox(height: 14),

              // ───── 요청사항 ─────
              TextField(
                controller: _note,
                maxLines: 2,
                decoration: const InputDecoration(hintText: '요청사항 (예: 창가 자리, 덜 맵게)'),
              ),
              const SizedBox(height: 10),
              Text(
                '결제는 가게에서 직접 해요. 앱은 예약번호만 만들어줘요.',
                style: Theme.of(context).textTheme.bodySmall,
              ),
              const SizedBox(height: 16),

              FilledButton(
                onPressed: _sending ? null : _submit,
                child: _sending
                    ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                    : const Text('예약 요청 보내기'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _PickBox extends StatelessWidget {
  final IconData icon;
  final String text;
  final VoidCallback onTap;
  const _PickBox({required this.icon, required this.text, required this.onTap});

  @override
  Widget build(BuildContext context) => InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(14),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: AppColors.line),
          ),
          child: Row(
            children: [
              Icon(icon, size: 18, color: AppColors.green),
              const SizedBox(width: 8),
              Text(text, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
            ],
          ),
        ),
      );
}

/// 예약이 끝나면 크게 보여주는 "예약번호" 창
class _CodeDialog extends StatelessWidget {
  final Reservation reservation;
  final bool online;
  const _CodeDialog({required this.reservation, required this.online});

  @override
  Widget build(BuildContext context) {
    final r = reservation;
    return AlertDialog(
      title: const Text('예약 요청 완료'),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            padding: const EdgeInsets.symmetric(vertical: 18),
            width: double.infinity,
            decoration: BoxDecoration(color: AppColors.mint, borderRadius: BorderRadius.circular(18)),
            child: Column(
              children: [
                const Text('예약번호', style: TextStyle(color: AppColors.muted, fontSize: 12)),
                Text(r.code, style: const TextStyle(fontSize: 40, fontWeight: FontWeight.w900, color: AppColors.green, letterSpacing: 6)),
              ],
            ),
          ),
          const SizedBox(height: 14),
          Text('${r.restaurantName}\n${formatVisitTime(r.visitAt)} · ${r.people}명', textAlign: TextAlign.center),
          const SizedBox(height: 10),
          Text(
            online
                ? '가게에 가서 이 번호를 보여주면 돼요. 사장님이 확인하면 "내 예약"에서 상태가 바뀌어요.'
                : '지금은 연습 모드라 내 폰에만 저장돼요. Firebase를 연결하면 사장님 폰에서도 보여요.',
            style: Theme.of(context).textTheme.bodySmall,
            textAlign: TextAlign.center,
          ),
        ],
      ),
      actions: [
        FilledButton(
          style: FilledButton.styleFrom(minimumSize: const Size(100, 44)),
          onPressed: () => Navigator.pop(context),
          child: const Text('확인'),
        ),
      ],
    );
  }
}
