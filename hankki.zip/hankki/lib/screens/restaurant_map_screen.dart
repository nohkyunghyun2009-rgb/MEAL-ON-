import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:kakao_map_plugin/kakao_map_plugin.dart';

import '../config/app_keys.dart';
import '../services/kakao_local_service.dart';
import '../theme/app_theme.dart';
import 'reservation_sheet.dart';

/// "식당 찾기" 탭: 내 위치 반경 1km 안의 식당을 카카오 지도에 표시
class RestaurantMapScreen extends StatefulWidget {
  const RestaurantMapScreen({super.key});

  @override
  State<RestaurantMapScreen> createState() => _RestaurantMapScreenState();
}

class _RestaurantMapScreenState extends State<RestaurantMapScreen> {
  final _local = KakaoLocalService();
  final _keyword = TextEditingController();

  KakaoMapController? _map;

  // GPS를 못 받으면 여기(백마 학원가 근처)를 기준으로 찾아요
  static const _fallbackLat = 37.6595;
  static const _fallbackLng = 126.7855;
  static const _radiusM = 1000;

  double _lat = _fallbackLat;
  double _lng = _fallbackLng;
  bool _usingFallback = true;

  List<Place> _places = [];
  bool _loading = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _locateThenSearch();
  }

  @override
  void dispose() {
    _keyword.dispose();
    super.dispose();
  }

  /// 1) 내 위치 알아내기 → 2) 그 주변 식당 검색
  Future<void> _locateThenSearch() async {
    setState(() => _loading = true);
    try {
      var permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
      }
      if (permission == LocationPermission.always || permission == LocationPermission.whileInUse) {
        final pos = await Geolocator.getCurrentPosition().timeout(const Duration(seconds: 10));
        _lat = pos.latitude;
        _lng = pos.longitude;
        _usingFallback = false;
      }
    } catch (_) {
      // 위치를 못 받아도 괜찮아요. 기본 위치로 계속 진행.
    }
    await _search();
  }

  Future<void> _search() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final places = await _local.searchNearby(
        lat: _lat,
        lng: _lng,
        keyword: _keyword.text,
        radiusM: _radiusM,
      );
      setState(() => _places = places);
      _drawOnMap();
    } catch (e) {
      setState(() => _error = e.toString());
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  // 지도에 찍을 핀들
  List<Marker> get _markers => _places
      .map((p) => Marker(markerId: p.id, latLng: LatLng(p.lat, p.lng)))
      .toList();

  // 반경 1km 동그라미
  List<Circle> get _circles => [
        Circle(
          circleId: 'radius',
          center: LatLng(_lat, _lng),
          radius: _radiusM.toDouble(),
          strokeWidth: 2,
          strokeColor: AppColors.green,
          strokeOpacity: 0.8,
          fillColor: AppColors.green,
          fillOpacity: 0.08,
        ),
      ];

  /// 지도 위의 핀과 동그라미를 지우고 다시 그려요
  void _drawOnMap() {
    final map = _map;
    if (map == null) return;
    map.setCenter(LatLng(_lat, _lng));
    map.clearMarker();
    map.clearCircle();
    map.addCircle(circles: _circles);
    map.addMarker(markers: _markers);
  }

  void _openReservation(Place place) {
    showReservationSheet(context, place);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('내 주변 1km 식당')),
      body: Column(
        children: [
          // ───── 검색창 ─────
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 0, 20, 10),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _keyword,
                    textInputAction: TextInputAction.search,
                    onSubmitted: (_) => _search(),
                    decoration: InputDecoration(
                      hintText: '덮밥, 국수, 샐러드...',
                      prefixIcon: const Icon(Icons.search),
                      suffixIcon: IconButton(
                        tooltip: '내 위치로',
                        icon: const Icon(Icons.my_location),
                        onPressed: _locateThenSearch,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),

          // ───── 지도 ─────
          SizedBox(
            height: 260,
            child: Stack(
              children: [
                AppKeys.kakaoReady
                    ? KakaoMap(
                        center: LatLng(_lat, _lng),
                        currentLevel: 5, // 숫자가 클수록 멀리서 봐요 (1km가 다 보이게)
                        onMapCreated: (controller) {
                          _map = controller;
                          _drawOnMap();
                        },
                        onMarkerTap: (markerId, latLng, zoomLevel) {
                          // 핀의 id와 같은 식당을 목록에서 찾기
                          for (final p in _places) {
                            if (p.id == markerId) {
                              _openReservation(p);
                              break;
                            }
                          }
                        },
                      )
                    : Container(
                        color: AppColors.mint,
                        alignment: Alignment.center,
                        padding: const EdgeInsets.all(20),
                        child: const Text('카카오 키를 넣으면 여기에 지도가 나와요\n(lib/config/app_keys.dart)', textAlign: TextAlign.center),
                      ),
                if (_usingFallback)
                  Positioned(
                    left: 12,
                    top: 12,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(999), border: Border.all(color: AppColors.line)),
                      child: const Text('기준: 백마 학원가', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700)),
                    ),
                  ),
              ],
            ),
          ),

          // ───── 목록 ─────
          Expanded(
            child: _loading
                ? const Center(child: CircularProgressIndicator())
                : _error != null
                    ? _Message(icon: Icons.wifi_off, text: _error!)
                    : _places.isEmpty
                        ? const _Message(icon: Icons.search_off, text: '1km 안에서 못 찾았어요.\n다른 말로 검색해봐요.')
                        : ListView.separated(
                            padding: const EdgeInsets.fromLTRB(20, 12, 20, 24),
                            itemCount: _places.length,
                            separatorBuilder: (_, __) => const SizedBox(height: 8),
                            itemBuilder: (_, i) {
                              final p = _places[i];
                              return Card(
                                child: ListTile(
                                  onTap: () => _openReservation(p),
                                  leading: CircleAvatar(
                                    backgroundColor: AppColors.mint,
                                    child: Text('${i + 1}', style: const TextStyle(color: AppColors.green, fontWeight: FontWeight.w800)),
                                  ),
                                  title: Text(p.name, style: const TextStyle(fontWeight: FontWeight.w700)),
                                  subtitle: Text('${p.shortCategory} · ${p.address}', maxLines: 1, overflow: TextOverflow.ellipsis),
                                  trailing: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    crossAxisAlignment: CrossAxisAlignment.end,
                                    children: [
                                      Text(p.distanceText, style: const TextStyle(fontWeight: FontWeight.w800, color: AppColors.green)),
                                      const Text('예약', style: TextStyle(fontSize: 12, color: AppColors.muted)),
                                    ],
                                  ),
                                ),
                              );
                            },
                          ),
          ),
        ],
      ),
    );
  }
}

class _Message extends StatelessWidget {
  final IconData icon;
  final String text;
  const _Message({required this.icon, required this.text});

  @override
  Widget build(BuildContext context) => Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon, size: 36, color: AppColors.muted),
              const SizedBox(height: 10),
              Text(text, textAlign: TextAlign.center, style: Theme.of(context).textTheme.bodyMedium),
            ],
          ),
        ),
      );
}
