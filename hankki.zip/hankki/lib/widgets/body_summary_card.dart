import 'package:flutter/material.dart';

import '../models/body_profile.dart';
import '../theme/app_theme.dart';

/// 인바디 숫자 4개를 한눈에 보여주는 카드
class BodySummaryCard extends StatelessWidget {
  final BodyProfile profile;
  final bool compact; // 홈 화면에서는 작게

  const BodySummaryCard({super.key, required this.profile, this.compact = false});

  @override
  Widget build(BuildContext context) {
    final p = profile;
    final tiles = [
      _Stat('몸무게', '${p.weightKg.toStringAsFixed(1)}', 'kg'),
      _Stat('골격근량', '${p.skeletalMuscleKg.toStringAsFixed(1)}', 'kg'),
      _Stat('체지방률', '${p.bodyFatPercent.toStringAsFixed(1)}', '%'),
      _Stat('BMI', p.bmi.toStringAsFixed(1), ''),
    ];

    return Container(
      padding: EdgeInsets.all(compact ? 16 : 20),
      decoration: BoxDecoration(
        color: AppColors.green,
        borderRadius: BorderRadius.circular(24),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(
                '${p.nickname}의 몸',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: compact ? 15 : 18,
                  fontWeight: FontWeight.w800,
                ),
              ),
              const Spacer(),
              Text(
                '${p.isMale ? '남' : '여'} · ${p.age}세 · ${p.heightCm.round()}cm',
                style: const TextStyle(color: Colors.white70, fontSize: 13),
              ),
            ],
          ),
          SizedBox(height: compact ? 12 : 18),
          Row(
            children: tiles
                .map((t) => Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(t.label, style: const TextStyle(color: Colors.white70, fontSize: 12)),
                          const SizedBox(height: 4),
                          RichText(
                            text: TextSpan(
                              text: t.value,
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: compact ? 20 : 26,
                                fontWeight: FontWeight.w800,
                              ),
                              children: [
                                TextSpan(
                                  text: t.unit.isEmpty ? '' : ' ${t.unit}',
                                  style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: Colors.white70),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ))
                .toList(),
          ),
        ],
      ),
    );
  }
}

class _Stat {
  final String label, value, unit;
  const _Stat(this.label, this.value, this.unit);
}
