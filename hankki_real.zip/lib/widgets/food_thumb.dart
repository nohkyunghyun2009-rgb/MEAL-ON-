import 'package:flutter/material.dart';

/// 사진 대신 쓰는 "이모지 썸네일". 가게 종류에 따라 이모지와 색이 정해져요.
class FoodThumb extends StatelessWidget {
  final String category; // 예: "음식점 > 한식 > 덮밥", "샐러드", "패스트푸드"
  final double size;
  final double radius;

  const FoodThumb({super.key, required this.category, this.size = 64, this.radius = 18});

  static (String, Color) lookFor(String category) {
    final c = category;
    if (c.contains('샐러드') || c.contains('포케')) return ('🥗', const Color(0xFFDDF5E3));
    if (c.contains('치킨')) return ('🍗', const Color(0xFFFFE8C7));
    if (c.contains('피자')) return ('🍕', const Color(0xFFFFE1D6));
    if (c.contains('버거') || c.contains('햄버거') || c.contains('패스트')) return ('🍔', const Color(0xFFFFE5C2));
    if (c.contains('분식') || c.contains('떡볶이')) return ('🍢', const Color(0xFFFFDCE0));
    if (c.contains('중식') || c.contains('중국')) return ('🥡', const Color(0xFFFFE3D1));
    if (c.contains('일식') || c.contains('초밥') || c.contains('돈까스') || c.contains('돈가스')) return ('🍱', const Color(0xFFE3EEFF));
    if (c.contains('국수') || c.contains('면') || c.contains('우동') || c.contains('냉면')) return ('🍜', const Color(0xFFFFF1CC));
    if (c.contains('카페') || c.contains('커피') || c.contains('디저트') || c.contains('베이커리')) return ('☕', const Color(0xFFEFE6DC));
    if (c.contains('고기') || c.contains('육류') || c.contains('구이')) return ('🥩', const Color(0xFFFFD9D9));
    if (c.contains('국밥') || c.contains('찌개') || c.contains('탕')) return ('🍲', const Color(0xFFFFE9D6));
    if (c.contains('양식') || c.contains('파스타')) return ('🍝', const Color(0xFFFFE6E1));
    if (c.contains('편의점')) return ('🏪', const Color(0xFFE6F0FF));
    if (c.contains('밥') || c.contains('한식') || c.contains('덮밥')) return ('🍚', const Color(0xFFFFEFD5));
    if (c.contains('음료')) return ('🥤', const Color(0xFFE3F6FF));
    if (c.contains('간식')) return ('🍪', const Color(0xFFFFF0D9));
    return ('🍽️', const Color(0xFFECEFF4));
  }

  @override
  Widget build(BuildContext context) {
    final (emoji, color) = lookFor(category);
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(radius)),
      alignment: Alignment.center,
      child: Text(emoji, style: TextStyle(fontSize: size * 0.48)),
    );
  }
}
