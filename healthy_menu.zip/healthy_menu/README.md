# Healthy Menu 🍱
고등학생을 위한 AI 건강 식단 추천 + 근처 가맹점 예약 앱 (Flutter)

## 기능
| # | 기능 | 파일 |
|---|------|------|
| 1 | AI 메뉴 추천 (Claude) | `lib/services/claude_service.dart`, `lib/screens/home_screen.dart` |
| 2 | 반경 1km 식당 지도 (카카오 로컬 API) | `lib/services/restaurant_service.dart`, `lib/screens/restaurant_map_screen.dart` |
| 3 | 가맹점 예약 + 5% 수수료 계산 | `lib/services/reservation_service.dart`, `lib/screens/reservation_*.dart` |
| 4 | 건강 식생활 홍보 숏폼 | `lib/screens/shorts_screen.dart` |

## 실행 방법 (맥북 기준)
```bash
# 1. 새 Flutter 프로젝트 만들기 (android/ios 폴더 자동 생성)
flutter create healthy_menu
cd healthy_menu

# 2. 이 압축의 lib/ 폴더와 pubspec.yaml 로 덮어쓰기

# 3. 패키지 설치
flutter pub get

# 4. lib/config.dart 에 API 키 2개 입력
#    - Claude: https://console.anthropic.com
#    - Kakao REST API: https://developers.kakao.com

# 5. 실행
flutter run
```

## 권한 설정 (위치 기능 때문에 꼭 필요)
**iOS** – `ios/Runner/Info.plist` 에 추가:
```xml
<key>NSLocationWhenInUseUsageDescription</key>
<string>근처 1km 식당을 찾기 위해 위치가 필요해요.</string>
```

**Android** – `android/app/src/main/AndroidManifest.xml` 의 `<manifest>` 안에 추가:
```xml
<uses-permission android:name="android.permission.INTERNET"/>
<uses-permission android:name="android.permission.ACCESS_FINE_LOCATION"/>
```

## 다음 단계 (실제 서비스로 만들려면)
- 예약/수수료 데이터를 폰이 아니라 **서버(Firebase, Supabase)** 에 저장
- 가맹점 사장님용 앱(예약 확정 버튼) 만들기
- `RestaurantService.partnerIds` 를 서버에서 불러오기
- 숏폼 영상을 실제 홍보 영상으로 교체
