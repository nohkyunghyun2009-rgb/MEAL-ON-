/// API 키를 한 곳에 모아두는 파일입니다.
/// 실제 배포할 때는 이 파일을 git에 올리지 말고(.gitignore),
/// 서버에서 키를 관리하는 방식으로 바꾸는 게 안전합니다.
class AppConfig {
  /// Anthropic Console(https://console.anthropic.com) → API Keys 에서 발급
  static const String claudeApiKey = 'YOUR_CLAUDE_API_KEY';

  /// 사용할 Claude 모델. 비용이 부담되면 'claude-haiku-4-5-20251001' 로 바꿔도 됩니다.
  static const String claudeModel = 'claude-sonnet-5';

  /// Kakao Developers(https://developers.kakao.com) → 내 애플리케이션 → REST API 키
  static const String kakaoRestApiKey = 'YOUR_KAKAO_REST_API_KEY';

  /// 가맹점에서 받는 수수료 비율 (5%)
  static const double commissionRate = 0.05;

  /// 식당 검색 반경 (미터)
  static const int searchRadiusMeters = 1000;
}
