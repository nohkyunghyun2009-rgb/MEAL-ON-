import 'package:flutter/material.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'models/models.dart';
import 'screens/home_screen.dart';
import 'screens/onboarding_screen.dart';
import 'screens/reservation_list_screen.dart';
import 'screens/restaurant_map_screen.dart';
import 'screens/shorts_screen.dart';
import 'services/storage_service.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await initializeDateFormatting('ko'); // 날짜를 한국어로 표시하기 위해
  runApp(const HealthyMenuApp());
}

class HealthyMenuApp extends StatelessWidget {
  const HealthyMenuApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Healthy Menu',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorSchemeSeed: Colors.green,
        useMaterial3: true,
      ),
      home: const _Root(),
    );
  }
}

/// 프로필이 저장돼 있으면 메인 화면, 없으면 온보딩으로 보내는 "문지기"
class _Root extends StatefulWidget {
  const _Root();

  @override
  State<_Root> createState() => _RootState();
}

class _RootState extends State<_Root> {
  UserProfile? _profile;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final p = await StorageService.loadProfile();
    setState(() {
      _profile = p;
      _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    if (_profile == null) {
      return OnboardingScreen(onDone: _load);
    }
    return MainShell(profile: _profile!);
  }
}

/// 하단 탭 4개: 홈 / 근처 식당 / 예약 / 숏폼
class MainShell extends StatefulWidget {
  final UserProfile profile;
  const MainShell({super.key, required this.profile});

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int _index = 0;

  @override
  Widget build(BuildContext context) {
    final pages = [
      HomeScreen(profile: widget.profile),
      const RestaurantMapScreen(),
      const ReservationListScreen(),
      const ShortsScreen(),
    ];

    return Scaffold(
      body: IndexedStack(index: _index, children: pages),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (i) => setState(() => _index = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home), label: '홈'),
          NavigationDestination(icon: Icon(Icons.map), label: '근처 식당'),
          NavigationDestination(icon: Icon(Icons.event_available), label: '예약'),
          NavigationDestination(icon: Icon(Icons.play_circle), label: '숏폼'),
        ],
      ),
    );
  }
}
