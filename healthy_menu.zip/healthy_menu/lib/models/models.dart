/// 앱에서 다루는 "데이터의 모양"을 정의하는 파일입니다.
/// (사용자 프로필, 음식, 식당, 예약)
/// toJson / fromJson 은 폰에 저장하거나 불러올 때 Map ↔ 객체 변환용입니다.

// ───────────────────────── 1. 사용자 프로필 ─────────────────────────
class UserProfile {
  final String name;
  final int age;
  final double heightCm;
  final double weightKg;
  final String gender; // 'male' / 'female'
  final String healthNote; // 예: "알레르기: 땅콩, 목표: 체중 감량"
  final int dailyCalorieGoal;

  UserProfile({
    required this.name,
    required this.age,
    required this.heightCm,
    required this.weightKg,
    required this.gender,
    required this.healthNote,
    required this.dailyCalorieGoal,
  });

  /// BMI = 체중(kg) / 키(m)^2
  double get bmi => weightKg / ((heightCm / 100) * (heightCm / 100));

  String get bmiLabel {
    if (bmi < 18.5) return '저체중';
    if (bmi < 23) return '정상';
    if (bmi < 25) return '과체중';
    return '비만';
  }

  /// 청소년 하루 권장 칼로리를 대략 계산 (Mifflin-St Jeor 공식 × 활동계수 1.5)
  static int estimateCalorieGoal({
    required int age,
    required double heightCm,
    required double weightKg,
    required String gender,
  }) {
    double bmr = 10 * weightKg + 6.25 * heightCm - 5 * age;
    bmr += (gender == 'male') ? 5 : -161;
    return (bmr * 1.5).round();
  }

  Map<String, dynamic> toJson() => {
        'name': name,
        'age': age,
        'heightCm': heightCm,
        'weightKg': weightKg,
        'gender': gender,
        'healthNote': healthNote,
        'dailyCalorieGoal': dailyCalorieGoal,
      };

  factory UserProfile.fromJson(Map<String, dynamic> j) => UserProfile(
        name: j['name'],
        age: j['age'],
        heightCm: (j['heightCm'] as num).toDouble(),
        weightKg: (j['weightKg'] as num).toDouble(),
        gender: j['gender'],
        healthNote: j['healthNote'] ?? '',
        dailyCalorieGoal: j['dailyCalorieGoal'],
      );
}

// ───────────────────────── 2. 음식 ─────────────────────────
class FoodItem {
  final String name;
  final int calories;
  final String category; // 한식/분식/패스트푸드/편의점/음료 등
  final String reason; // AI가 추천한 이유 (AI 추천일 때만 채워짐)

  const FoodItem({
    required this.name,
    required this.calories,
    required this.category,
    this.reason = '',
  });

  Map<String, dynamic> toJson() =>
      {'name': name, 'calories': calories, 'category': category, 'reason': reason};

  factory FoodItem.fromJson(Map<String, dynamic> j) => FoodItem(
        name: j['name'] ?? '',
        calories: (j['calories'] as num?)?.toInt() ?? 0,
        category: j['category'] ?? '',
        reason: j['reason'] ?? '',
      );
}

/// 아침 메뉴 선택용 간단한 로컬 DB (학생들이 실제로 많이 먹는 것 위주)
const List<FoodItem> breakfastMenuDb = [
  FoodItem(name: '안 먹음', calories: 0, category: '없음'),
  FoodItem(name: '흰밥 + 김치 + 계란후라이', calories: 480, category: '한식'),
  FoodItem(name: '시리얼 + 우유', calories: 350, category: '간편식'),
  FoodItem(name: '토스트 + 딸기잼', calories: 320, category: '빵'),
  FoodItem(name: '편의점 삼각김밥 2개', calories: 400, category: '편의점'),
  FoodItem(name: '편의점 샌드위치', calories: 380, category: '편의점'),
  FoodItem(name: '햄버거 세트', calories: 850, category: '패스트푸드'),
  FoodItem(name: '바나나 1개 + 두유', calories: 200, category: '간편식'),
  FoodItem(name: '컵라면', calories: 420, category: '편의점'),
  FoodItem(name: '탄산음료 500ml', calories: 210, category: '음료'),
];

// ───────────────────────── 3. 식당 ─────────────────────────
class Restaurant {
  final String id;
  final String name;
  final String category;
  final String address;
  final String phone;
  final double lat;
  final double lng;
  final int distanceMeters;
  final String placeUrl;
  final bool isPartner; // 가맹점 여부 (수수료 계약이 된 식당)

  Restaurant({
    required this.id,
    required this.name,
    required this.category,
    required this.address,
    required this.phone,
    required this.lat,
    required this.lng,
    required this.distanceMeters,
    required this.placeUrl,
    this.isPartner = false,
  });

  /// 카카오 로컬 API 응답(JSON) → Restaurant 객체
  factory Restaurant.fromKakao(Map<String, dynamic> d, {required bool isPartner}) =>
      Restaurant(
        id: d['id'],
        name: d['place_name'],
        category: d['category_name'] ?? '',
        address: d['road_address_name'] ?? d['address_name'] ?? '',
        phone: d['phone'] ?? '',
        lat: double.parse(d['y']),
        lng: double.parse(d['x']),
        distanceMeters: int.tryParse(d['distance'] ?? '0') ?? 0,
        placeUrl: d['place_url'] ?? '',
        isPartner: isPartner,
      );
}

// ───────────────────────── 4. 예약 ─────────────────────────
class Reservation {
  final String id;
  final String restaurantId;
  final String restaurantName;
  final DateTime dateTime;
  final int people;
  final String menu;
  final int totalPrice; // 예상 음식값(원)
  final String status; // 'pending' | 'confirmed' | 'done' | 'cancelled'

  Reservation({
    required this.id,
    required this.restaurantId,
    required this.restaurantName,
    required this.dateTime,
    required this.people,
    required this.menu,
    required this.totalPrice,
    this.status = 'pending',
  });

  /// 우리 회사가 가맹점에서 받는 수수료 (음식값의 5%)
  int commissionFor(double rate) => (totalPrice * rate).round();

  Reservation copyWith({String? status}) => Reservation(
        id: id,
        restaurantId: restaurantId,
        restaurantName: restaurantName,
        dateTime: dateTime,
        people: people,
        menu: menu,
        totalPrice: totalPrice,
        status: status ?? this.status,
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'restaurantId': restaurantId,
        'restaurantName': restaurantName,
        'dateTime': dateTime.toIso8601String(),
        'people': people,
        'menu': menu,
        'totalPrice': totalPrice,
        'status': status,
      };

  factory Reservation.fromJson(Map<String, dynamic> j) => Reservation(
        id: j['id'],
        restaurantId: j['restaurantId'],
        restaurantName: j['restaurantName'],
        dateTime: DateTime.parse(j['dateTime']),
        people: j['people'],
        menu: j['menu'],
        totalPrice: j['totalPrice'],
        status: j['status'],
      );
}
