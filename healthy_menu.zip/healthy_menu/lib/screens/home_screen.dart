import 'package:flutter/material.dart';
import '../models/models.dart';
import '../services/claude_service.dart';
import '../services/restaurant_service.dart';
import '../services/storage_service.dart';
import '../widgets/capsule_progress_bar.dart';
import 'restaurant_map_screen.dart';

/// 홈: 오늘 먹은 것 기록 → 칼로리 진행률 → AI 추천
class HomeScreen extends StatefulWidget {
  final UserProfile profile;
  const HomeScreen({super.key, required this.profile});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List<FoodItem> _eaten = [];
  List<FoodItem> _recommended = [];
  bool _loadingAi = false;
  String? _aiError;

  int get _eatenCal => _eaten.fold(0, (s, f) => s + f.calories);

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final foods = await StorageService.loadTodayFoods();
    setState(() => _eaten = foods);
    // 오늘 아무것도 기록 안 했으면 아침 메뉴 물어보기
    if (foods.isEmpty && mounted) {
      WidgetsBinding.instance.addPostFrameCallback((_) => _askBreakfast());
    }
  }

  /// 앱 진입 시 "오늘 아침 뭐 먹었어?" 다이얼로그
  Future<void> _askBreakfast() async {
    final picked = await showModalBottomSheet<FoodItem>(
      context: context,
      builder: (_) => ListView(
        children: [
          const Padding(
            padding: EdgeInsets.all(16),
            child: Text('오늘 아침 뭐 먹었어? 🍳',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          ),
          ...breakfastMenuDb.map((f) => ListTile(
                title: Text(f.name),
                subtitle: Text(f.category),
                trailing: Text('${f.calories} kcal'),
                onTap: () => Navigator.pop(context, f),
              )),
        ],
      ),
    );
    if (picked != null && picked.calories > 0) _addFood(picked);
  }

  Future<void> _addFood(FoodItem f) async {
    setState(() => _eaten.add(f));
    await StorageService.saveTodayFoods(_eaten);
  }

  /// AI 추천 버튼
  Future<void> _recommend() async {
    setState(() {
      _loadingAi = true;
      _aiError = null;
    });
    try {
      // 근처 식당 종류를 같이 넘기면 "실제로 갈 수 있는" 메뉴를 추천해줌
      List<String> categories = [];
      try {
        final rs = RestaurantService();
        final pos = await rs.getCurrentPosition();
        final list = await rs.searchNearby(lat: pos.latitude, lng: pos.longitude);
        categories = rs.extractCategories(list);
      } catch (_) {
        // 위치를 못 가져와도 추천은 되게 그냥 넘어감
      }

      final hour = DateTime.now().hour;
      final result = await ClaudeService().recommendMenus(
        profile: widget.profile,
        eatenToday: _eaten,
        mealType: hour < 15 ? '점심' : '저녁',
        nearbyCategories: categories,
      );
      setState(() => _recommended = result);
    } catch (e) {
      setState(() => _aiError = 'AI 추천 실패: $e');
    } finally {
      setState(() => _loadingAi = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final p = widget.profile;
    return Scaffold(
      appBar: AppBar(title: Text('안녕, ${p.name}! 👋')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // ── 오늘 칼로리 카드 ──
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('오늘 섭취 칼로리',
                      style: TextStyle(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  CapsuleProgressBar(
                    value: _eatenCal / p.dailyCalorieGoal,
                    label: '$_eatenCal / ${p.dailyCalorieGoal} kcal',
                  ),
                  const SizedBox(height: 8),
                  Text('BMI ${p.bmi.toStringAsFixed(1)} (${p.bmiLabel})',
                      style: TextStyle(color: Colors.grey[700])),
                ],
              ),
            ),
          ),

          // ── 오늘 먹은 것 ──
          const SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('오늘 먹은 것', style: TextStyle(fontWeight: FontWeight.bold)),
              TextButton.icon(
                onPressed: _askBreakfast,
                icon: const Icon(Icons.add),
                label: const Text('추가'),
              ),
            ],
          ),
          if (_eaten.isEmpty) const Text('아직 기록이 없어요'),
          ..._eaten.map((f) => ListTile(
                dense: true,
                leading: const Icon(Icons.restaurant),
                title: Text(f.name),
                trailing: Text('${f.calories} kcal'),
              )),

          // ── AI 추천 ──
          const SizedBox(height: 16),
          FilledButton.icon(
            onPressed: _loadingAi ? null : _recommend,
            icon: _loadingAi
                ? const SizedBox(
                    width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                : const Icon(Icons.auto_awesome),
            label: Text(_loadingAi ? 'AI가 고민 중...' : 'AI에게 메뉴 추천받기'),
          ),
          if (_aiError != null)
            Padding(
              padding: const EdgeInsets.only(top: 8),
              child: Text(_aiError!, style: const TextStyle(color: Colors.red)),
            ),
          ..._recommended.map((f) => Card(
                color: Colors.green[50],
                child: ListTile(
                  title: Text('${f.name}  ·  ${f.calories} kcal'),
                  subtitle: Text(f.reason),
                  trailing: const Icon(Icons.map),
                  onTap: () {
                    // 추천 메뉴를 키워드로 근처 식당 찾기 화면으로 이동
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => RestaurantMapScreen(initialKeyword: f.name),
                      ),
                    );
                  },
                ),
              )),
        ],
      ),
    );
  }
}
