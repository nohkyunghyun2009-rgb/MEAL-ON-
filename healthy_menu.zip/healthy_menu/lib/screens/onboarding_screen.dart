import 'package:flutter/material.dart';
import '../models/models.dart';
import '../services/storage_service.dart';

/// 첫 실행 시 학생의 건강 정보를 입력받는 화면.
/// 여기서 입력한 값이 AI 추천의 기준이 됩니다.
class OnboardingScreen extends StatefulWidget {
  final VoidCallback onDone;
  const OnboardingScreen({super.key, required this.onDone});

  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  final _formKey = GlobalKey<FormState>();
  final _name = TextEditingController();
  final _age = TextEditingController(text: '17');
  final _height = TextEditingController();
  final _weight = TextEditingController();
  final _note = TextEditingController();
  String _gender = 'male';

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;

    final age = int.parse(_age.text);
    final h = double.parse(_height.text);
    final w = double.parse(_weight.text);

    final profile = UserProfile(
      name: _name.text.trim(),
      age: age,
      heightCm: h,
      weightKg: w,
      gender: _gender,
      healthNote: _note.text.trim(),
      dailyCalorieGoal: UserProfile.estimateCalorieGoal(
          age: age, heightCm: h, weightKg: w, gender: _gender),
    );
    await StorageService.saveProfile(profile);
    widget.onDone();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('내 건강 정보 입력')),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              const Text(
                'AI가 너에게 맞는 메뉴를 추천하려면\n기본 정보가 필요해요 🍱',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 24),
              TextFormField(
                controller: _name,
                decoration: const InputDecoration(labelText: '이름(닉네임)'),
                validator: (v) => v == null || v.isEmpty ? '입력해주세요' : null,
              ),
              TextFormField(
                controller: _age,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: '나이'),
                validator: (v) => int.tryParse(v ?? '') == null ? '숫자로 입력' : null,
              ),
              Row(
                children: [
                  Expanded(
                    child: TextFormField(
                      controller: _height,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(labelText: '키 (cm)'),
                      validator: (v) =>
                          double.tryParse(v ?? '') == null ? '숫자로 입력' : null,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: TextFormField(
                      controller: _weight,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(labelText: '몸무게 (kg)'),
                      validator: (v) =>
                          double.tryParse(v ?? '') == null ? '숫자로 입력' : null,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              SegmentedButton<String>(
                segments: const [
                  ButtonSegment(value: 'male', label: Text('남')),
                  ButtonSegment(value: 'female', label: Text('여')),
                ],
                selected: {_gender},
                onSelectionChanged: (s) => setState(() => _gender = s.first),
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _note,
                maxLines: 3,
                decoration: const InputDecoration(
                  labelText: '건강 메모 (선택)',
                  hintText: '예: 땅콩 알레르기, 체중 감량 목표, 요즘 피곤함',
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 24),
              FilledButton(
                onPressed: _submit,
                child: const Padding(
                  padding: EdgeInsets.all(12),
                  child: Text('시작하기', style: TextStyle(fontSize: 16)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
