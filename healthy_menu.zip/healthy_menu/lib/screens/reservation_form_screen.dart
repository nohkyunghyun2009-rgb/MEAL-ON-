import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../config.dart';
import '../models/models.dart';
import '../services/reservation_service.dart';

/// 기능 3: "몇 시에, 몇 명이, 뭘 먹을지" 정해서 가맹점에 예약
class ReservationFormScreen extends StatefulWidget {
  final Restaurant restaurant;
  const ReservationFormScreen({super.key, required this.restaurant});

  @override
  State<ReservationFormScreen> createState() => _ReservationFormScreenState();
}

class _ReservationFormScreenState extends State<ReservationFormScreen> {
  DateTime _dateTime = DateTime.now().add(const Duration(hours: 1));
  int _people = 2;
  final _menu = TextEditingController();
  final _price = TextEditingController(text: '9000');
  bool _saving = false;

  final _won = NumberFormat('#,###');

  Future<void> _pickDateTime() async {
    final d = await showDatePicker(
      context: context,
      initialDate: _dateTime,
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(const Duration(days: 30)),
    );
    if (d == null || !mounted) return;
    final t = await showTimePicker(
        context: context, initialTime: TimeOfDay.fromDateTime(_dateTime));
    if (t == null) return;
    setState(() => _dateTime = DateTime(d.year, d.month, d.day, t.hour, t.minute));
  }

  Future<void> _submit() async {
    if (_menu.text.trim().isEmpty) {
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('메뉴를 입력해주세요')));
      return;
    }
    setState(() => _saving = true);
    await ReservationService().getAll(); // 캐시 불러오기
    await ReservationService().create(
      restaurant: widget.restaurant,
      dateTime: _dateTime,
      people: _people,
      menu: _menu.text.trim(),
      pricePerPerson: int.tryParse(_price.text) ?? 0,
    );
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('예약 요청 완료! 가맹점 확인을 기다려주세요 🙌')));
    Navigator.popUntil(context, (route) => route.isFirst);
  }

  @override
  Widget build(BuildContext context) {
    final r = widget.restaurant;
    final total = (int.tryParse(_price.text) ?? 0) * _people;
    final commission = (total * AppConfig.commissionRate).round();

    return Scaffold(
      appBar: AppBar(title: const Text('예약하기')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text(r.name, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          Text(r.address, style: TextStyle(color: Colors.grey[700])),
          if (!r.isPartner)
            const Padding(
              padding: EdgeInsets.only(top: 8),
              child: Text('⚠️ 아직 가맹점이 아니에요. 예약 요청만 남겨둘게요.',
                  style: TextStyle(color: Colors.orange)),
            ),
          const Divider(height: 32),

          // 날짜/시간
          ListTile(
            leading: const Icon(Icons.schedule),
            title: Text(DateFormat('M월 d일 (E) HH:mm', 'ko').format(_dateTime)),
            trailing: const Icon(Icons.edit),
            onTap: _pickDateTime,
          ),

          // 인원
          ListTile(
            leading: const Icon(Icons.people),
            title: Text('$_people명'),
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                IconButton(
                    onPressed: () => setState(() => _people = (_people - 1).clamp(1, 20)),
                    icon: const Icon(Icons.remove)),
                IconButton(
                    onPressed: () => setState(() => _people = (_people + 1).clamp(1, 20)),
                    icon: const Icon(Icons.add)),
              ],
            ),
          ),

          // 메뉴
          TextField(
            controller: _menu,
            decoration: const InputDecoration(
                labelText: '먹을 메뉴', hintText: '예: 닭가슴살 샐러드 2개'),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _price,
            keyboardType: TextInputType.number,
            onChanged: (_) => setState(() {}),
            decoration: const InputDecoration(labelText: '1인당 예상 금액 (원)'),
          ),

          const SizedBox(height: 24),
          Card(
            color: Colors.grey[100],
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('예상 음식값: ${_won.format(total)}원'),
                  Text(
                    '가맹점 수수료(${(AppConfig.commissionRate * 100).toInt()}%): ${_won.format(commission)}원',
                    style: TextStyle(color: Colors.grey[600], fontSize: 12),
                  ),
                  const Text('* 수수료는 가맹점이 부담해요. 학생은 추가 비용 없음!',
                      style: TextStyle(fontSize: 11, color: Colors.grey)),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          FilledButton(
            onPressed: _saving ? null : _submit,
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Text(_saving ? '전송 중...' : '예약 요청 보내기'),
            ),
          ),
        ],
      ),
    );
  }
}
