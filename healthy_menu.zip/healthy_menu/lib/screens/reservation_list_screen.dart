import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../config.dart';
import '../models/models.dart';
import '../services/reservation_service.dart';

/// 내 예약 목록 + (관리자용) 수수료 수익 요약
class ReservationListScreen extends StatefulWidget {
  const ReservationListScreen({super.key});

  @override
  State<ReservationListScreen> createState() => _ReservationListScreenState();
}

class _ReservationListScreenState extends State<ReservationListScreen> {
  final _service = ReservationService();
  List<Reservation> _list = [];
  final _won = NumberFormat('#,###');

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final l = await _service.getAll();
    setState(() => _list = l);
  }

  Color _statusColor(String s) => switch (s) {
        'confirmed' => Colors.blue,
        'done' => Colors.green,
        'cancelled' => Colors.grey,
        _ => Colors.orange,
      };

  String _statusText(String s) => switch (s) {
        'confirmed' => '확정',
        'done' => '식사 완료',
        'cancelled' => '취소',
        _ => '가맹점 확인 중',
      };

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('내 예약')),
      body: RefreshIndicator(
        onRefresh: _load,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            // ── 수익 요약 (실제 앱에선 관리자/가맹점 화면에만 보여줌) ──
            Card(
              color: Colors.green[50],
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('💰 수익 요약 (관리자 데모)',
                        style: TextStyle(fontWeight: FontWeight.bold)),
                    const SizedBox(height: 4),
                    Text('완료된 예약 매출: ${_won.format(_service.totalSales())}원'),
                    Text(
                      '수수료 수익(${(AppConfig.commissionRate * 100).toInt()}%): ${_won.format(_service.totalCommission())}원',
                      style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 12),
            if (_list.isEmpty)
              const Padding(
                padding: EdgeInsets.all(32),
                child: Center(child: Text('아직 예약이 없어요.\n근처 식당에서 예약해보세요!',
                    textAlign: TextAlign.center)),
              ),
            ..._list.map((r) => Card(
                  child: ListTile(
                    title: Text(r.restaurantName),
                    subtitle: Text(
                      '${DateFormat('M/d HH:mm').format(r.dateTime)} · ${r.people}명 · ${r.menu}\n'
                      '${_won.format(r.totalPrice)}원 (수수료 ${_won.format(r.commissionFor(AppConfig.commissionRate))}원)',
                    ),
                    isThreeLine: true,
                    trailing: Chip(
                      label: Text(_statusText(r.status),
                          style: const TextStyle(color: Colors.white, fontSize: 11)),
                      backgroundColor: _statusColor(r.status),
                    ),
                    // 데모용: 탭하면 상태를 다음 단계로 (실제로는 가맹점이 바꿈)
                    onTap: () async {
                      final next = switch (r.status) {
                        'pending' => 'confirmed',
                        'confirmed' => 'done',
                        _ => r.status,
                      };
                      await _service.updateStatus(r.id, next);
                      _load();
                    },
                  ),
                )),
          ],
        ),
      ),
    );
  }
}
