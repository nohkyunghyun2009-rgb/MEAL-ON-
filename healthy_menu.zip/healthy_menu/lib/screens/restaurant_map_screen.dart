import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:url_launcher/url_launcher.dart';
import '../models/models.dart';
import '../services/restaurant_service.dart';
import 'reservation_form_screen.dart';

/// 기능 2: 반경 1km 식당을 지도 + 리스트로 보여주는 화면
class RestaurantMapScreen extends StatefulWidget {
  final String initialKeyword;
  const RestaurantMapScreen({super.key, this.initialKeyword = '음식점'});

  @override
  State<RestaurantMapScreen> createState() => _RestaurantMapScreenState();
}

class _RestaurantMapScreenState extends State<RestaurantMapScreen> {
  final _service = RestaurantService();
  final _mapController = MapController();
  late final TextEditingController _keyword;

  LatLng? _me;
  List<Restaurant> _list = [];
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _keyword = TextEditingController(text: widget.initialKeyword);
    _search();
  }

  Future<void> _search() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final pos = await _service.getCurrentPosition();
      _me = LatLng(pos.latitude, pos.longitude);
      final list = await _service.searchNearby(
        lat: pos.latitude,
        lng: pos.longitude,
        keyword: _keyword.text.trim().isEmpty ? '음식점' : _keyword.text.trim(),
      );
      setState(() => _list = list);
      _mapController.move(_me!, 15);
    } catch (e) {
      setState(() => _error = e.toString());
    } finally {
      setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('내 주변 1km 식당')),
      body: Column(
        children: [
          // ── 검색창 ──
          Padding(
            padding: const EdgeInsets.all(8),
            child: TextField(
              controller: _keyword,
              onSubmitted: (_) => _search(),
              decoration: InputDecoration(
                hintText: '메뉴/식당 검색 (예: 국밥, 샐러드)',
                prefixIcon: const Icon(Icons.search),
                suffixIcon: IconButton(icon: const Icon(Icons.refresh), onPressed: _search),
                border: const OutlineInputBorder(),
              ),
            ),
          ),

          // ── 지도 ──
          SizedBox(
            height: 260,
            child: FlutterMap(
              mapController: _mapController,
              options: MapOptions(
                initialCenter: _me ?? const LatLng(37.5665, 126.9780), // 기본: 서울
                initialZoom: 15,
              ),
              children: [
                TileLayer(
                  urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                  userAgentPackageName: 'com.example.healthy_menu',
                ),
                if (_me != null)
                  CircleLayer(circles: [
                    CircleMarker(
                      point: _me!,
                      radius: 1000, // 1km 반경 원
                      useRadiusInMeter: true,
                      color: Colors.blue.withOpacity(0.1),
                      borderColor: Colors.blue,
                      borderStrokeWidth: 1,
                    ),
                  ]),
                MarkerLayer(markers: [
                  if (_me != null)
                    Marker(
                      point: _me!,
                      child: const Icon(Icons.my_location, color: Colors.blue),
                    ),
                  ..._list.map((r) => Marker(
                        point: LatLng(r.lat, r.lng),
                        width: 40,
                        height: 40,
                        child: Icon(
                          Icons.location_on,
                          color: r.isPartner ? Colors.green : Colors.red,
                          size: 32,
                        ),
                      )),
                ]),
              ],
            ),
          ),

          // ── 식당 리스트 ──
          Expanded(
            child: _loading
                ? const Center(child: CircularProgressIndicator())
                : _error != null
                    ? Center(child: Text(_error!, textAlign: TextAlign.center))
                    : ListView.builder(
                        itemCount: _list.length,
                        itemBuilder: (_, i) {
                          final r = _list[i];
                          return ListTile(
                            leading: Icon(Icons.storefront,
                                color: r.isPartner ? Colors.green : Colors.grey),
                            title: Row(
                              children: [
                                Expanded(child: Text(r.name)),
                                if (r.isPartner)
                                  const Chip(
                                    label: Text('가맹점', style: TextStyle(fontSize: 11)),
                                    backgroundColor: Colors.greenAccent,
                                    padding: EdgeInsets.zero,
                                  ),
                              ],
                            ),
                            subtitle: Text('${r.category.split('>').last.trim()} · ${r.distanceMeters}m\n${r.address}'),
                            isThreeLine: true,
                            trailing: IconButton(
                              icon: const Icon(Icons.open_in_new),
                              onPressed: () => launchUrl(Uri.parse(r.placeUrl),
                                  mode: LaunchMode.externalApplication),
                            ),
                            onTap: () {
                              _mapController.move(LatLng(r.lat, r.lng), 17);
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (_) => ReservationFormScreen(restaurant: r)),
                              );
                            },
                          );
                        },
                      ),
          ),
        ],
      ),
    );
  }
}
