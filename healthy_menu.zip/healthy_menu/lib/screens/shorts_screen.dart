import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';

/// 기능 4: 건강한 식생활 홍보 숏폼 (세로로 넘기는 영상 피드)
/// 지금은 샘플 영상 URL. 실제로는 서버/유튜브에 올린 회사 홍보 영상 링크로 교체.
class ShortsScreen extends StatelessWidget {
  const ShortsScreen({super.key});

  static const _videos = [
    _Short(
      url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
      title: '편의점 음료 대신 이거 어때? 🥤',
      caption: '탄산음료 1캔 = 각설탕 10개. 오늘은 무가당 탄산수로!',
    ),
    _Short(
      url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4',
      title: '학원 가기 전 10분 건강 한 끼 🍱',
      caption: '삼각김밥+컵라면 말고, 닭가슴살 샐러드 + 바나나.',
    ),
    _Short(
      url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4',
      title: '우리가 이 앱을 만든 이유 💚',
      caption: '오래 사는 것보다 건강하게 사는 것. 10대의 식습관이 평생을 결정해요.',
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return PageView.builder(
      scrollDirection: Axis.vertical, // 틱톡/쇼츠처럼 위아래로 넘김
      itemCount: _videos.length,
      itemBuilder: (_, i) => _ShortPlayer(short: _videos[i]),
    );
  }
}

class _Short {
  final String url, title, caption;
  const _Short({required this.url, required this.title, required this.caption});
}

class _ShortPlayer extends StatefulWidget {
  final _Short short;
  const _ShortPlayer({required this.short});

  @override
  State<_ShortPlayer> createState() => _ShortPlayerState();
}

class _ShortPlayerState extends State<_ShortPlayer> {
  late final VideoPlayerController _c;

  @override
  void initState() {
    super.initState();
    _c = VideoPlayerController.networkUrl(Uri.parse(widget.short.url))
      ..initialize().then((_) {
        _c.setLooping(true);
        _c.play();
        setState(() {});
      });
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => setState(() => _c.value.isPlaying ? _c.pause() : _c.play()),
      child: Stack(
        fit: StackFit.expand,
        children: [
          Container(color: Colors.black),
          if (_c.value.isInitialized)
            FittedBox(
              fit: BoxFit.cover,
              child: SizedBox(
                width: _c.value.size.width,
                height: _c.value.size.height,
                child: VideoPlayer(_c),
              ),
            )
          else
            const Center(child: CircularProgressIndicator(color: Colors.white)),
          // 하단 자막
          Positioned(
            left: 16,
            right: 16,
            bottom: 40,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(widget.short.title,
                    style: const TextStyle(
                        color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold)),
                const SizedBox(height: 6),
                Text(widget.short.caption,
                    style: const TextStyle(color: Colors.white70, fontSize: 14)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
