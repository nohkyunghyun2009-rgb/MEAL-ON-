import 'dart:convert';
import 'package:http/http.dart' as http;
import '../config.dart';
import '../models/models.dart';

/// 기능 1: Claude AI가 사용자의 건강 상태 + 오늘 먹은 것을 보고 메뉴를 추천
///
/// Flutter용 공식 Anthropic SDK는 없어서, 이미 pubspec에 있는 http 패키지로
/// Anthropic Messages API(https://api.anthropic.com/v1/messages)를 직접 호출합니다.
/// 문서: https://docs.claude.com/en/api/messages
class ClaudeService {
  static const _endpoint = 'https://api.anthropic.com/v1/messages';

  /// [nearbyCategories]: 근처 식당 종류 목록(있으면 실제로 갈 수 있는 메뉴를 추천하도록 유도)
  Future<List<FoodItem>> recommendMenus({
    required UserProfile profile,
    required List<FoodItem> eatenToday,
    required String mealType, // '점심' 또는 '저녁'
    List<String> nearbyCategories = const [],
  }) async {
    final eatenCal = eatenToday.fold<int>(0, (sum, f) => sum + f.calories);
    final remaining = profile.dailyCalorieGoal - eatenCal;
    final eatenText = eatenToday.isEmpty
        ? '아직 아무것도 안 먹음'
        : eatenToday.map((f) => '${f.name}(${f.calories}kcal)').join(', ');

    // ── 1) system: Claude의 "역할"과 출력 규칙 ──
    const systemPrompt = '''
너는 고등학생 전용 건강 식단 코치야. 편의점/패스트푸드/당분 음료 위주의 식습관을
건강하게 바꾸는 게 목표야.

규칙:
- 남은 칼로리의 40~60% 정도에 맞는 메뉴로.
- 당분 많은 음료, 튀김 위주 메뉴는 피하고, 단백질/채소가 있는 메뉴 우선.
- 알레르기 메모가 있으면 절대 그 재료를 넣지 마.
- 학원가/동네 식당에서 실제로 살 수 있는 현실적인 메뉴로.
- reason은 학생이 이해하기 쉽게 한 문장으로.

반드시 아래 JSON 배열 형식으로만 답해. 설명, 인사, 마크다운(```)은 절대 붙이지 마:
[
  {"name": "메뉴 이름", "calories": 숫자, "category": "한식", "reason": "추천 이유"}
]
''';

    // ── 2) user: 이 학생의 실제 데이터 ──
    final userPrompt = '''
$mealType 메뉴 3개를 추천해줘.

[학생 정보]
- 나이: ${profile.age}세, 성별: ${profile.gender == 'male' ? '남' : '여'}
- 키/체중: ${profile.heightCm}cm / ${profile.weightKg}kg (BMI ${profile.bmi.toStringAsFixed(1)}, ${profile.bmiLabel})
- 건강 메모: ${profile.healthNote.isEmpty ? '없음' : profile.healthNote}
- 하루 목표 칼로리: ${profile.dailyCalorieGoal}kcal
- 오늘 먹은 것: $eatenText (총 ${eatenCal}kcal)
- 남은 칼로리: ${remaining}kcal
${nearbyCategories.isEmpty ? '' : '- 근처 식당 종류: ${nearbyCategories.join(', ')}'}
''';

    // ── 3) API 호출 ──
    final res = await http.post(
      Uri.parse(_endpoint),
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': AppConfig.claudeApiKey,
        'anthropic-version': '2023-06-01', // 필수 헤더
      },
      body: jsonEncode({
        'model': AppConfig.claudeModel,
        'max_tokens': 1024,
        'system': systemPrompt,
        'messages': [
          {'role': 'user', 'content': userPrompt},
        ],
      }),
    );

    if (res.statusCode != 200) {
      throw Exception('Claude API 오류 (${res.statusCode}): ${res.body}');
    }

    // ── 4) 응답 파싱 ──
    // 응답 모양: {"content": [{"type": "text", "text": "..."}], ...}
    // content 배열에서 type == "text" 인 블록의 text만 모아 붙입니다.
    final data = jsonDecode(utf8.decode(res.bodyBytes)); // 한글 깨짐 방지
    final List content = data['content'];
    final text = content
        .where((b) => b['type'] == 'text')
        .map((b) => b['text'] as String)
        .join();

    // 혹시 ```json ``` 으로 감싸서 오면 벗겨냄
    final clean = text.replaceAll(RegExp(r'```json|```'), '').trim();
    final List parsed = jsonDecode(clean);
    return parsed.map((e) => FoodItem.fromJson(e)).toList();
  }
}
