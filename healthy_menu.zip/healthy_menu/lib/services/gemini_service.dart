import 'dart:convert';
import 'package:google_generative_ai/google_generative_ai.dart';
import '../config.dart';
import '../models/models.dart';

/// 기능 1: AI(Gemini)가 사용자의 건강 상태 + 오늘 먹은 것을 보고 메뉴를 추천
class GeminiService {
  final _model = GenerativeModel(
    model: 'gemini-1.5-flash',
    apiKey: AppConfig.geminiApiKey,
    // JSON만 돌려달라고 강제 → 파싱이 쉬워짐
    generationConfig: GenerationConfig(responseMimeType: 'application/json'),
  );

  /// [nearbyCategories]: 근처 식당 종류 목록(있으면 실제로 갈 수 있는 메뉴를 추천하도록 유도)
  Future<List<FoodItem>> recommendMenus({
    required UserProfile profile,
    required List<FoodItem> eatenToday,
    required String mealType, // '점심' 또는 '저녁'
    List<String> nearbyCategories = const [],
  }) async {
    final eatenCal = eatenToday.fold<int>(0, (sum, f) => sum + f.calories);
    final remaining = profile.dailyCalorieGoal - eatenCal;
    final eatenText = eatenToday.isEmpty
        ? '아직 아무것도 안 먹음'
        : eatenToday.map((f) => '${f.name}(${f.calories}kcal)').join(', ');

    final prompt = '''
너는 고등학생 전용 건강 식단 코치야. 편의점/패스트푸드/당분 음료 위주의 식습관을
건강하게 바꾸는 게 목표야. 아래 정보를 보고 $mealType 메뉴 3개를 추천해줘.

[학생 정보]
- 나이: ${profile.age}세, 성별: ${profile.gender == 'male' ? '남' : '여'}
- 키/체중: ${profile.heightCm}cm / ${profile.weightKg}kg (BMI ${profile.bmi.toStringAsFixed(1)}, ${profile.bmiLabel})
- 건강 메모: ${profile.healthNote.isEmpty ? '없음' : profile.healthNote}
- 하루 목표 칼로리: ${profile.dailyCalorieGoal}kcal
- 오늘 먹은 것: $eatenText (총 ${eatenCal}kcal)
- 남은 칼로리: ${remaining}kcal
${nearbyCategories.isEmpty ? '' : '- 근처 식당 종류: ${nearbyCategories.join(', ')}'}

[규칙]
- 남은 칼로리의 40~60% 정도에 맞는 메뉴로.
- 당분 많은 음료, 튀김 위주 메뉴는 피하고, 단백질/채소가 있는 메뉴 우선.
- 알레르기 메모가 있으면 절대 그 재료를 넣지 마.
- 학원가/동네 식당에서 실제로 살 수 있는 현실적인 메뉴로.
- reason은 학생이 이해하기 쉽게 한 문장으로.

반드시 아래 JSON 배열 형식으로만 답해:
[
  {"name": "메뉴 이름", "calories": 숫자, "category": "한식", "reason": "추천 이유"}
]
''';

    final response = await _model.generateContent([Content.text(prompt)]);
    final text = response.text ?? '[]';

    // 혹시 ```json ``` 으로 감싸서 오면 벗겨냄
    final clean = text.replaceAll(RegExp(r'```json|```'), '').trim();
    final List parsed = jsonDecode(clean);
    return parsed.map((e) => FoodItem.fromJson(e)).toList();
  }
}
