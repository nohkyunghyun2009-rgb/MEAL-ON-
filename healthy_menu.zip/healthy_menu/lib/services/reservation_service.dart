import '../config.dart';
import '../models/models.dart';
import 'storage_service.dart';

/// 기능 3: 가맹점 예약 + 5% 수수료 계산 (수익화)
/// 지금은 폰 안에만 저장하지만, 실제로는 서버로 예약 요청을 보내고
/// 가맹점 사장님 앱에서 "확정" 버튼을 눌러야 상태가 바뀌는 구조가 됩니다.
class ReservationService {
  List<Reservation> _cache = [];

  Future<List<Reservation>> getAll() async {
    _cache = await StorageService.loadReservations();
    // 최신 예약이 위로
    _cache.sort((a, b) => b.dateTime.compareTo(a.dateTime));
    return _cache;
  }

  Future<Reservation> create({
    required Restaurant restaurant,
    required DateTime dateTime,
    required int people,
    required String menu,
    required int pricePerPerson,
  }) async {
    final r = Reservation(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      restaurantId: restaurant.id,
      restaurantName: restaurant.name,
      dateTime: dateTime,
      people: people,
      menu: menu,
      totalPrice: pricePerPerson * people,
    );
    _cache.add(r);
    await StorageService.saveReservations(_cache);
    // TODO: 여기서 서버 API / 가맹점 알림(카카오 알림톡 등) 호출
    return r;
  }

  Future<void> updateStatus(String id, String status) async {
    _cache = _cache.map((r) => r.id == id ? r.copyWith(status: status) : r).toList();
    await StorageService.saveReservations(_cache);
  }

  /// 완료(done)된 예약들의 수수료 합계 = 우리 회사 매출
  int totalCommission() => _cache
      .where((r) => r.status == 'done')
      .fold(0, (sum, r) => sum + r.commissionFor(AppConfig.commissionRate));

  int totalSales() => _cache
      .where((r) => r.status == 'done')
      .fold(0, (sum, r) => sum + r.totalPrice);
}
