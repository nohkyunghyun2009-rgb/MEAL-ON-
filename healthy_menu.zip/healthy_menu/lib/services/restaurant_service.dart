import 'dart:convert';
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;
import '../config.dart';
import '../models/models.dart';

/// 기능 2: 현재 위치 기준 반경 1km 식당 찾기 (카카오 로컬 API 사용)
class RestaurantService {
  /// 우리 회사와 수수료 계약을 맺은 가맹점 ID 목록.
  /// 실제로는 서버 DB에서 받아와야 하지만, 지금은 예시로 하드코딩.
  /// (카카오 place id를 여기에 넣으면 "가맹점" 뱃지가 붙습니다)
  static const Set<String> partnerIds = {
    // '12345678', '87654321',
  };

  /// 1) 위치 권한 요청 → 2) 현재 좌표 반환
  Future<Position> getCurrentPosition() async {
    bool enabled = await Geolocator.isLocationServiceEnabled();
    if (!enabled) throw Exception('위치 서비스(GPS)가 꺼져 있어요.');

    LocationPermission perm = await Geolocator.checkPermission();
    if (perm == LocationPermission.denied) {
      perm = await Geolocator.requestPermission();
    }
    if (perm == LocationPermission.denied ||
        perm == LocationPermission.deniedForever) {
      throw Exception('위치 권한이 필요해요. 설정에서 허용해주세요.');
    }
    return Geolocator.getCurrentPosition();
  }

  /// 카카오 로컬 API "키워드로 장소 검색"
  /// 문서: https://developers.kakao.com/docs/latest/ko/local/dev-guide#search-by-keyword
  Future<List<Restaurant>> searchNearby({
    required double lat,
    required double lng,
    String keyword = '음식점',
  }) async {
    final uri = Uri.https('dapi.kakao.com', '/v2/local/search/keyword.json', {
      'query': keyword,
      'x': lng.toString(), // 카카오는 x=경도, y=위도 순서 주의!
      'y': lat.toString(),
      'radius': AppConfig.searchRadiusMeters.toString(),
      'category_group_code': 'FD6', // FD6 = 음식점 카테고리
      'sort': 'distance', // 가까운 순
      'size': '15',
    });

    final res = await http.get(uri, headers: {
      'Authorization': 'KakaoAK ${AppConfig.kakaoRestApiKey}',
    });

    if (res.statusCode != 200) {
      throw Exception('카카오 API 오류 (${res.statusCode}): ${res.body}');
    }

    final data = jsonDecode(res.body);
    final List docs = data['documents'];
    return docs
        .map((d) => Restaurant.fromKakao(d, isPartner: partnerIds.contains(d['id'])))
        .toList();
  }

  /// 식당 목록에서 "종류"만 뽑아서 AI에게 넘길 때 사용
  /// 예: "음식점 > 한식 > 국밥" → "국밥"
  List<String> extractCategories(List<Restaurant> list) {
    return list
        .map((r) => r.category.split('>').last.trim())
        .where((c) => c.isNotEmpty)
        .toSet()
        .toList();
  }
}
