import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/models.dart';

/// 폰 내부 저장소(SharedPreferences)에 데이터를 저장/불러오는 클래스.
/// 실제 서비스에서는 이 부분을 서버(Firebase, Supabase 등)로 바꾸면 됩니다.
class StorageService {
  static const _keyProfile = 'user_profile';
  static const _keyReservations = 'reservations';
  static const _keyTodayFoods = 'today_foods';

  // ── 프로필 ──
  static Future<void> saveProfile(UserProfile p) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_keyProfile, jsonEncode(p.toJson()));
  }

  static Future<UserProfile?> loadProfile() async {
    final prefs = await SharedPreferences.getInstance();
    final s = prefs.getString(_keyProfile);
    if (s == null) return null;
    return UserProfile.fromJson(jsonDecode(s));
  }

  // ── 오늘 먹은 음식 (날짜가 바뀌면 자동 초기화) ──
  static Future<void> saveTodayFoods(List<FoodItem> foods) async {
    final prefs = await SharedPreferences.getInstance();
    final data = {
      'date': _todayKey(),
      'foods': foods.map((f) => f.toJson()).toList(),
    };
    await prefs.setString(_keyTodayFoods, jsonEncode(data));
  }

  static Future<List<FoodItem>> loadTodayFoods() async {
    final prefs = await SharedPreferences.getInstance();
    final s = prefs.getString(_keyTodayFoods);
    if (s == null) return [];
    final data = jsonDecode(s);
    if (data['date'] != _todayKey()) return []; // 어제 데이터면 버림
    return (data['foods'] as List).map((e) => FoodItem.fromJson(e)).toList();
  }

  // ── 예약 목록 ──
  static Future<void> saveReservations(List<Reservation> list) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
        _keyReservations, jsonEncode(list.map((r) => r.toJson()).toList()));
  }

  static Future<List<Reservation>> loadReservations() async {
    final prefs = await SharedPreferences.getInstance();
    final s = prefs.getString(_keyReservations);
    if (s == null) return [];
    return (jsonDecode(s) as List).map((e) => Reservation.fromJson(e)).toList();
  }

  static String _todayKey() {
    final n = DateTime.now();
    return '${n.year}-${n.month}-${n.day}';
  }
}
