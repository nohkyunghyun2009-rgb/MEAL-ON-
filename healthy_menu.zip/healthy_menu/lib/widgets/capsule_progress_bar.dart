import 'package:flutter/material.dart';

/// 원통(캡슐) 모양 진행률 바. value 는 0.0 ~ 1.0 (1 넘으면 빨간색으로 경고)
class CapsuleProgressBar extends StatelessWidget {
  final double value;
  final String label;
  const CapsuleProgressBar({super.key, required this.value, required this.label});

  @override
  Widget build(BuildContext context) {
    final over = value > 1.0;
    final clamped = value.clamp(0.0, 1.0);
    final color = over
        ? Colors.red
        : value > 0.8
            ? Colors.orange
            : Colors.green;

    return Stack(
      alignment: Alignment.center,
      children: [
        Container(
          height: 36,
          decoration: BoxDecoration(
            color: Colors.grey[300],
            borderRadius: BorderRadius.circular(18),
          ),
        ),
        Align(
          alignment: Alignment.centerLeft,
          child: FractionallySizedBox(
            widthFactor: clamped,
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 500),
              height: 36,
              decoration: BoxDecoration(
                color: color,
                borderRadius: BorderRadius.circular(18),
              ),
            ),
          ),
        ),
        Text(
          over ? '$label (초과!)' : label,
          style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.black87),
        ),
      ],
    );
  }
}
